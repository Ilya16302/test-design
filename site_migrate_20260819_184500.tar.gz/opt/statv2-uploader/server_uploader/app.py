#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import gzip
import json
import os
import shutil
import tempfile
import zipfile
from copy import copy
from datetime import datetime
from pathlib import Path

from flask import Flask, after_this_request, jsonify, request, send_file, session, g
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, PatternFill, Side

APP = Flask(__name__)
APP.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("STATV2_MAX_UPLOAD_MB", "250")) * 1024 * 1024

SITE_ROOT = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2")).resolve()
DB_TARGET = SITE_ROOT / "db"
BACKUP_ROOT = SITE_ROOT / "uploads_backup"
IDCARDS_ROOT     = SITE_ROOT / "id_cards"
IDCARDS_MANIFEST = IDCARDS_ROOT / "manifest.json"
TEMPLATE_PATH = SITE_ROOT / "templates" / "statistika_template.xlsm"
MATERIAL_TEMPLATE_PATH = SITE_ROOT / "templates" / "statistika_template_material.xlsm"
UPLOAD_USER = os.environ.get("STATV2_UPLOAD_USER", "admin_update")
UPLOAD_PASS = os.environ.get("STATV2_UPLOAD_PASS", "")

STAT_ADMIN_LOGIN = os.environ.get("STATV2_STAT_ADMIN_LOGIN", "admin_stat")
STAT_ADMIN_PASS = os.environ.get("STATV2_STAT_ADMIN_PASS", "")
DYNAMIC_ORG_ACCOUNTS_PATH = Path(os.environ.get("STATV2_ORG_ACCOUNTS_PATH", "/opt/statv2-auth/org_accounts.json"))
SPK_CONTRACTORS_PATH = Path(os.environ.get("STATV2_SPK_CONTRACTORS_PATH", "/opt/statv2-auth/spk_contractors.json"))
SPK_BACKLOG_HISTORY_PATH = Path(os.environ.get("STATV2_SPK_BACKLOG_HISTORY_PATH", "/opt/statv2-auth/spk_daily_backlog.json"))
SPK_OBJECTS_PATH = Path(os.environ.get("STATV2_SPK_OBJECTS_PATH", "/opt/statv2-auth/spk_objects.json"))
SPK_DAILY_EXCEL_TEMPLATE = Path(__file__).resolve().parent / "templates" / "SPK_everyday.xlsx"
SPK_DYNAMIC_EXCEL_TEMPLATE = Path(__file__).resolve().parent / "templates" / "SPK-dinam.xlsx"

# Организационные админки. Живут на сервере и не зависят от обновления базы.
ORG_ADMIN_ACCOUNTS = {
    "NGTS_01": {"password": "ddyvxyhi", "org_filter": "НГТС", "title": "НГТС"},
    "NOVA_01": {"password": "tvixwowc", "org_filter": "НОВА", "title": "НОВА"},
    "GALA_01": {"password": "uvnxebih", "org_filter": "ГАЛА", "title": "ГАЛА"},
    "SSPI_01": {"password": "fzzfdxzr", "org_filter": "ССПИ", "title": "ССПИ"},
}

# STATV2_HYBRID_AUTH_ROUTES_V1
PRIVATE_AUTH_ROOT = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
PRIVATE_AUTH_PATH = PRIVATE_AUTH_ROOT / "auth.json.gz"
SECRET_PATH = PRIVATE_AUTH_ROOT / "flask_secret_key.txt"

PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)

if not SECRET_PATH.exists():
    SECRET_PATH.write_text(secrets.token_hex(32), encoding="utf-8")
    SECRET_PATH.chmod(0o600)

APP.secret_key = os.environ.get("STATV2_SECRET_KEY") or SECRET_PATH.read_text(encoding="utf-8").strip()
APP.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("STATV2_COOKIE_SECURE", "1") != "0",
)

# STATV2_AUTH_PATCH_V1
PRIVATE_AUTH_ROOT = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
PRIVATE_AUTH_PATH = PRIVATE_AUTH_ROOT / "auth.json.gz"
SECRET_PATH = PRIVATE_AUTH_ROOT / "flask_secret_key.txt"

PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
if not SECRET_PATH.exists():
    SECRET_PATH.write_text(secrets.token_hex(32), encoding="utf-8")
    SECRET_PATH.chmod(0o600)

APP.secret_key = os.environ.get("STATV2_SECRET_KEY") or SECRET_PATH.read_text(encoding="utf-8").strip()
APP.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("STATV2_COOKIE_SECURE", "1") != "0",
)

REQUIRED = [
    "manifest.json",
    "auth.json.gz",
    "admin_summary.json.gz",
    "welders/shard_00.json.gz",
    "welders/shard_01.json.gz",
    "welders/shard_02.json.gz",
    "welders/shard_03.json.gz",
    "welders/shard_04.json.gz",
    "welders/shard_05.json.gz",
    "welders/shard_06.json.gz",
    "welders/shard_07.json.gz",
]


def error(message, code=400):
    return jsonify({"ok": False, "error": message}), code


AUDIT_LOG = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))


def client_ip():
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",", 1)[0].strip()
    return request.headers.get("X-Real-IP") or request.remote_addr or ""


def audit_event(event, login="", role="", ok=False, extra=None):
    try:
        AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        now = datetime.now()
        ip = client_ip()
        login_s = str(login or "")

        # Дедуп: тот же логин+событие+IP за последние 5 секунд считаем повторным
        # сабмитом (двойной тап / Enter+клик / ретрай мобильной сети), а не новым визитом.
        try:
            if AUDIT_LOG.exists():
                with AUDIT_LOG.open("rb") as f:
                    f.seek(0, 2)
                    size = f.tell()
                    f.seek(max(0, size - 8192))
                    tail = f.read().decode("utf-8", errors="ignore")
                for line in reversed(tail.splitlines()):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        last = json.loads(line)
                        last_ts = datetime.fromisoformat(last.get("ts", ""))
                    except Exception:
                        continue
                    if (now - last_ts).total_seconds() > 5:
                        break
                    if last.get("event") == event and last.get("login") == login_s and last.get("ip") == ip:
                        return
        except Exception:
            pass

        row = {
            "ts": now.isoformat(timespec="seconds"),
            "event": event,
            "ok": bool(ok),
            "login": login_s,
            "role": str(role or ""),
            "ip": ip,
            "user_agent": request.headers.get("User-Agent", ""),
        }
        if extra:
            row.update(extra)
        with AUDIT_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception:
        pass


def authorized() -> bool:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
        user, password = raw.split(":", 1)
    except Exception:
        return False
    return user == UPLOAD_USER and password == UPLOAD_PASS


def read_json_gz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def write_json_gz(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))


def norm_login(value: str) -> str:
    return str(value or "").strip().lower().replace("ё", "е")


def password_sha256(password: str) -> str:
    return hashlib.sha256(str(password or "").encode("utf-8")).hexdigest()


def verify_password(password: str, password_hash: str = "", password_plain: str = "") -> bool:
    password = str(password or "")
    password_hash = str(password_hash or "")
    password_plain = str(password_plain or "")

    if password_hash and hmac.compare_digest(password_sha256(password), password_hash):
        return True
    if password_plain and hmac.compare_digest(password, password_plain):
        return True
    return False


def load_private_auth():
    if PRIVATE_AUTH_PATH.exists():
        return read_json_gz(PRIVATE_AUTH_PATH)

    fallback = DB_TARGET / "auth.json.gz"
    if fallback.exists():
        PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
        shutil.copy2(fallback, PRIVATE_AUTH_PATH)
        PRIVATE_AUTH_PATH.chmod(0o600)
        return read_json_gz(PRIVATE_AUTH_PATH)

    raise FileNotFoundError("Не найден закрытый auth.json.gz")


def save_private_auth_from_db(db_dir: Path):
    auth = db_dir / "auth.json.gz"
    if auth.exists():
        PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
        shutil.copy2(auth, PRIVATE_AUTH_PATH)
        PRIVATE_AUTH_PATH.chmod(0o600)


def strip_secrets_obj(obj):
    if isinstance(obj, dict):
        for k in ("password_plain", "password_hash", "admin_password_hash"):
            obj.pop(k, None)
        if isinstance(obj.get("auth"), dict):
            obj["auth"] = {
                k: v for k, v in obj["auth"].items()
                if k not in ("admin_password_hash", "password_hash", "password_plain")
            }
        for v in obj.values():
            strip_secrets_obj(v)
    elif isinstance(obj, list):
        for v in obj:
            strip_secrets_obj(v)


def sanitize_public_db(db_dir: Path):
    for gz in db_dir.rglob("*.json.gz"):
        data = read_json_gz(gz)
        strip_secrets_obj(data)
        write_json_gz(gz, data)


def is_role(*roles: str) -> bool:
    return str(session.get("role") or "") in roles


def basic_authorized() -> bool:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
        user, password = raw.split(":", 1)
    except Exception:
        return False
    return hmac.compare_digest(user, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS)


def public_meta():
    manifest = DB_TARGET / "manifest.json"
    if not manifest.exists():
        return {}
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        return {
            "generated_at": data.get("generated_at", ""),
            "period_start": data.get("period_start", ""),
            "period_end": data.get("period_end", ""),
            "counts": data.get("counts", {}),
        }
    except Exception:
        return {}


def find_auth_welder_by_login(login: str):
    login_n = norm_login(login)
    auth_db = load_private_auth()
    for w in auth_db.get("welders", []):
        if norm_login(w.get("login")) == login_n:
            return w
    return None




def safe_public_meta():
    # Универсальная безопасная обёртка, чтобы логин не падал из-за разных имён функций meta.
    for name in ("_public_meta", "public_meta", "db_public_meta"):
        fn = globals().get(name)
        if callable(fn):
            try:
                return fn()
            except Exception:
                pass

    try:
        manifest = DB_TARGET / "manifest.json"
        if manifest.exists():
            data = json.loads(manifest.read_text(encoding="utf-8"))
            return {
                "generated_at": data.get("generated_at", ""),
                "period_start": data.get("period_start", ""),
                "period_end": data.get("period_end", ""),
                "counts": data.get("counts", {}),
            }
    except Exception:
        pass

    return {}

@APP.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or request.form
    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "")

    if not login or not password:
        return error("Введите логин и пароль", 400)

    org_cfg = ORG_ADMIN_ACCOUNTS.get(login.strip().upper())
    if org_cfg and hmac.compare_digest(password, org_cfg["password"]):
        session.clear()
        session["role"] = "admin"
        session["login"] = login.strip()
        session["org_filter"] = org_cfg["org_filter"]
        session["org_title"] = org_cfg["title"]
        try:
            audit_event("org_admin_login_success", login=login, role="admin", ok=True, extra={
                "org_filter": org_cfg["org_filter"],
                "org_title": org_cfg["title"],
            })
        except Exception:
            pass
        return jsonify({
            "ok": True,
            "role": "admin",
            "org_filter": org_cfg["org_filter"],
            "org_title": org_cfg["title"],
            "meta": safe_public_meta(),
        })

    if hmac.compare_digest(login, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS):
        session.clear()
        session["role"] = "updater"
        session["login"] = UPLOAD_USER
        return jsonify({"ok": True, "role": "updater", "meta": safe_public_meta()})

    try:
        auth_db = load_private_auth()
    except Exception as exc:
        return error(str(exc), 500)

    auth = auth_db.get("auth", {})
    admin_login = str(auth.get("admin_login") or "admin")

    if norm_login(login) == norm_login(admin_login):
        if verify_password(password, auth.get("admin_password_hash", "")):
            session.clear()
            session["role"] = "admin"
            session["login"] = admin_login
            return jsonify({"ok": True, "role": "admin", "meta": safe_public_meta()})

    w = find_auth_welder_by_login(login)
    if w and verify_password(password, w.get("password_hash", ""), w.get("password_plain", "")):
        session.clear()
        session["role"] = "welder"
        session["login"] = w.get("login", login)
        session["welder_id"] = w.get("id", "")
        return jsonify({
            "ok": True,
            "role": "welder",
            "welder_id": w.get("id", ""),
            "shard": w.get("shard", ""),
            "name": w.get("name", ""),
            "meta": safe_public_meta(),
        })

    audit_event("login_failed", login=login, role="", ok=False)
    return error("Логин или пароль не подошли", 401)


@APP.get("/api/session")
def api_session():
    role = str(session.get("role") or "")
    if not role:
        return jsonify({"ok": True, "authenticated": False, "meta": safe_public_meta()})

    result = {
        "ok": True,
        "authenticated": True,
        "role": role,
        "login": session.get("login", ""),
        "welder_id": session.get("welder_id", ""),
        "meta": safe_public_meta(),
    }

    if session.get("org_filter"):
        result["org_filter"] = session.get("org_filter", "")
        result["org_title"] = session.get("org_title", "")

    if role == "welder":
        w = None
        try:
            auth_db = load_private_auth()
            for item in auth_db.get("welders", []):
                if str(item.get("id") or "") == str(session.get("welder_id") or ""):
                    w = item
                    break
        except Exception:
            w = None
        if w:
            result["shard"] = w.get("shard", "")

    return jsonify(result)


@APP.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify({"ok": True})


def safe_extract_zip(zip_path: Path, dest: Path) -> None:
    dest_resolved = dest.resolve()
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            name = member.filename.replace("\\", "/")
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"Запрещённый путь в архиве: {member.filename}")
            target = (dest / name).resolve()
            if not str(target).startswith(str(dest_resolved)):
                raise ValueError(f"Запрещённый путь в архиве: {member.filename}")
        z.extractall(dest)


def find_db_dir(extracted: Path) -> Path:
    candidate = extracted / "db"
    if candidate.is_dir():
        return candidate
    if (extracted / "manifest.json").exists():
        return extracted
    raise ValueError("В архиве не найдена папка db или manifest.json")


def validate_db_dir(db_dir: Path) -> None:
    missing = [name for name in REQUIRED if not (db_dir / name).is_file()]
    if missing:
        raise ValueError("В архиве не хватает файлов: " + ", ".join(missing))


def chmod_tree(path: Path) -> None:
    for p in path.rglob("*"):
        try:
            if p.is_dir():
                p.chmod(0o755)
            else:
                p.chmod(0o644)
        except Exception:
            pass
    try:
        path.chmod(0o755)
    except Exception:
        pass


@APP.get("/health")
def health():
    return jsonify({"ok": True, "site_root": str(SITE_ROOT), "template": str(TEMPLATE_PATH)})



@APP.post("/api/upload_db")
def upload_db():
    # Разрешаем загрузку только пользователю admin_update через серверную сессию.
    # Старый Basic-режим оставляем как аварийный запас.
    allowed = str(session.get("role") or "") in ("updater", "stat_admin")

    if not allowed:
        header = request.headers.get("Authorization", "")
        if header.startswith("Basic "):
            try:
                raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
                user, password = raw.split(":", 1)
                allowed = hmac.compare_digest(user, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS)
            except Exception:
                allowed = False

    if not allowed:
        return error("Нет доступа", 401)

    file = request.files.get("file")
    if not file or not file.filename:
        return error("Файл не выбран")

    if not file.filename.lower().endswith(".zip"):
        return error("Нужен zip-архив")

    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    SITE_ROOT.mkdir(parents=True, exist_ok=True)

    def _read_gz(path):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)

    def _write_gz(path, data):
        with gzip.open(path, "wt", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))

    def _strip_secrets(obj):
        if isinstance(obj, dict):
            # В публичной базе не должно быть логинов, паролей и хэшей.
            for key in ("login", "password_plain", "password_hash", "admin_password_hash"):
                obj.pop(key, None)

            if isinstance(obj.get("auth"), dict):
                obj["auth"] = {}

            for value in obj.values():
                _strip_secrets(value)

        elif isinstance(obj, list):
            for value in obj:
                _strip_secrets(value)

    def _save_private_auth(db_dir):
        auth_file = db_dir / "auth.json.gz"
        if not auth_file.exists():
            raise ValueError("В архиве нет auth.json.gz — без него сервер не сможет проверять вход")

        private_root = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
        private_root.mkdir(parents=True, exist_ok=True)

        private_auth = private_root / "auth.json.gz"
        shutil.copy2(auth_file, private_auth)
        private_auth.chmod(0o600)

    def _sanitize_public_db(db_dir):
        for gz in db_dir.rglob("*.json.gz"):
            data = _read_gz(gz)
            _strip_secrets(data)
            _write_gz(gz, data)

    with tempfile.TemporaryDirectory(prefix="statv2_upload_") as tmp_name:
        tmp = Path(tmp_name)
        zip_path = tmp / "upload.zip"
        extracted = tmp / "extracted"
        new_db_tmp = tmp / "db_new"
        spk_snapshot = None

        extracted.mkdir()
        file.save(zip_path)

        try:
            safe_extract_zip(zip_path, extracted)
            db_dir = find_db_dir(extracted)
            validate_db_dir(db_dir)

            shutil.copytree(db_dir, new_db_tmp)

            snapshot_path = new_db_tmp / "spk_backlog_snapshot.json"
            if snapshot_path.exists():
                spk_snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
                if not isinstance(spk_snapshot, dict):
                    raise ValueError("Некорректный spk_backlog_snapshot.json")

            # 1. Сначала сохраняем закрытую базу входа.
            _save_private_auth(new_db_tmp)

            # 2. Потом чистим публичную базу.
            _sanitize_public_db(new_db_tmp)

            chmod_tree(new_db_tmp)

        except Exception as exc:
            return error(str(exc), 400)

        backup_path = None

        if DB_TARGET.exists():
            backup_path = BACKUP_ROOT / ("db_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
            shutil.move(str(DB_TARGET), str(backup_path))

        try:
            shutil.move(str(new_db_tmp), str(DB_TARGET))

            manifest_path = DB_TARGET / "manifest.json"
            manifest_data = json.loads(
                manifest_path.read_text(
                    encoding="utf-8"
                )
            )

            manifest_data["base_version"] = (
                datetime.utcnow().strftime(
                    "%Y%m%d%H%M%S"
                )
            )

            try:
                objects_payload = statv2_read_spk_objects()
                materials_obj = objects_payload.get("objects", {}).get(SPK_DEFAULT_OBJECT_ID)
                if isinstance(materials_obj, dict):
                    manifest_data["material_groups"] = materials_obj.get("material_groups") or []
                    manifest_data["base_ranges"] = materials_obj.get("base_ranges") or dict(DEFAULT_MATERIAL_RANGE_CONFIG)
            except Exception:
                pass

            manifest_path.write_text(
                json.dumps(
                    manifest_data,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
                encoding="utf-8",
            )

            if spk_snapshot:
                statv2_merge_spk_backlog_snapshot(spk_snapshot)
        except Exception as exc:
            if DB_TARGET.exists():
                shutil.rmtree(DB_TARGET, ignore_errors=True)
            if backup_path and backup_path.exists():
                shutil.move(str(backup_path), str(DB_TARGET))
            return error("Не удалось заменить db или сохранить снимок СПК: " + str(exc), 500)

    snapshot_date = str((spk_snapshot or {}).get("date") or "")
    return jsonify({
        "ok": True,
        "message": "База обновлена. Закрытый auth сохранён, публичная db очищена от логинов и паролей.",
        "backup": str(backup_path) if backup_path else "",
        "spk_snapshot_date": snapshot_date,
    })


# ---------------- Excel export ----------------

def read_json_gz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def load_sharded_database(include_joints=False):
    manifest_path = DB_TARGET / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError("Не найден db/manifest.json")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    shard_paths = manifest.get("shards") or [f"welders/shard_{i:02d}.json.gz" for i in range(8)]

    welders = []
    welder_events = {}
    joints_by_id = {}

    for rel in shard_paths:
        shard = read_json_gz(DB_TARGET / rel)
        welders.extend(shard.get("welders", []))
        welder_events.update(shard.get("welder_events", {}))
        if include_joints:
            for joint in shard.get("joints", []):
                joint_id = str(joint.get("id") or joint.get("key") or "")
                if joint_id:
                    joints_by_id[joint_id] = joint

    welders.sort(key=lambda w: str(w.get("name") or "").casefold())
    joints = list(joints_by_id.values())
    return manifest, welders, welder_events, joints


def empty_stats():
    return {
        "total_welded": 0,
        "production": 0.0,
        "submitted_control": 0,
        "accepted": 0,
        "rejected": 0,
        "wait": 0,
        "not_required": 0,
        "reject_rate": None,
    }


def add_stat(s, e):
    s["total_welded"] += 1
    try:
        s["production"] += float(e.get("inch") or 0)
    except Exception:
        pass

    result = e.get("result") or ""
    if result == "Годен":
        s["submitted_control"] += 1
        s["accepted"] += 1
    elif result == "Не годен":
        s["submitted_control"] += 1
        s["rejected"] += 1
    elif result == "Ожидание контроля":
        s["submitted_control"] += 1
        s["wait"] += 1
    elif result == "Контроль РК/УЗК не требуется":
        s["not_required"] += 1


def finalize(s):
    controlled = s["accepted"] + s["rejected"]
    s["reject_rate"] = (s["rejected"] / controlled) if controlled else None
    return s


def calc_stats(events, scope, start="", end=""):
    s = empty_stats()
    for e in events:
        if scope == "primary" and e.get("stage_type") != "primary":
            continue
        if scope == "repairs" and e.get("stage_type") != "repair":
            continue
        d = str(e.get("weld_date") or "")[:10]
        if start and d < start:
            continue
        if end and d > end:
            continue
        add_stat(s, e)
    return finalize(s)


MATERIAL_GROUPS = ("LTCS", "SS", "LOAS")
MATERIAL_GROUP_RAW = {
    "LTCS": (
        "LTCS", "09G2S", "СТ20", "09G2S/09G2S(K48)", "STS410-S",
        "A333-6/A671-CC60", "ASTMA333-6", "ASTMA350-LF2CL.1",
        "ASTMA420-WPL6",
    ),
    "SS": (
        "304/304L", "316/316L", "12Х18Н10Т",
        "A312-TP304/304L/A358-304/304L", "304L", "304/304", "316L",
        "304/316L", "ASTMA312-TP304/304L", "ASTMA182-F304/304L", "316",
    ),
    "LOAS": ("1.25CR-0.5MO", "ASTMA335-P11"),
}
DEFAULT_MATERIAL_RANGE_CONFIG = {
    "diam": ["0-50", "50-109", "109-выше"],
    "thick": [
        ["0-4", "4-выше"],
        ["0-4", "4-выше"],
        ["0-4", "4-выше"],
    ],
}


def norm_material_key(value):
    return "".join(str(value or "").upper().split()).replace("–", "-").replace("—", "-").replace("?", "-")


MATERIAL_GROUP_LOOKUP = {
    norm_material_key(code): group
    for group, codes in MATERIAL_GROUP_RAW.items()
    for code in codes
}
MATERIAL_GROUP_COLORS = {g: "#6ab3ff" for g in MATERIAL_GROUPS}


def refresh_material_groups_from_object():
    global MATERIAL_GROUPS, MATERIAL_GROUP_RAW, MATERIAL_GROUP_LOOKUP, MATERIAL_GROUP_COLORS

    try:
        payload = statv2_read_spk_objects()
        obj = payload.get("objects", {}).get(SPK_DEFAULT_OBJECT_ID)
        groups = obj.get("material_groups") if isinstance(obj, dict) else None
    except Exception:
        groups = None

    if not groups:
        return

    new_groups = []
    new_raw = {}
    new_colors = {}

    for g in groups:
        if not isinstance(g, dict):
            continue
        key = str(g.get("key") or g.get("name") or "").strip()
        if not key:
            continue
        new_groups.append(key)
        new_raw[key] = list(g.get("codes") or [])
        new_colors[key] = str(g.get("color") or "#6ab3ff")

    if not new_groups:
        return

    MATERIAL_GROUPS = tuple(new_groups)
    MATERIAL_GROUP_RAW = new_raw
    MATERIAL_GROUP_COLORS = new_colors
    MATERIAL_GROUP_LOOKUP = {
        norm_material_key(code): group
        for group, codes in MATERIAL_GROUP_RAW.items()
        for code in codes
    }


def material_group_of(value):
    return MATERIAL_GROUP_LOOKUP.get(norm_material_key(value), "")


def parse_number(value):
    try:
        return float(str(value or "").strip().replace(",", "."))
    except Exception:
        return None


def parse_range_spec(raw):
    text = str(raw or "").strip().lower().replace("–", "-").replace("—", "-")
    if "-" not in text:
        return None
    left, right = text.split("-", 1)
    minimum = parse_number(left)
    if minimum is None:
        return None
    right = right.strip()
    maximum = parse_number(right)
    if right in ("выше", "больше") or maximum is None:
        maximum = None
    return {"min": minimum, "max": maximum}


def normalize_material_range_config(raw):
    source = raw if isinstance(raw, dict) else {}
    diam = source.get("diam")
    thick = source.get("thick")

    if not isinstance(diam, list) or len(diam) != 3:
        diam = list(DEFAULT_MATERIAL_RANGE_CONFIG["diam"])
    else:
        diam = [str(value or "").strip() for value in diam]

    if not isinstance(thick, list) or len(thick) != 3:
        thick = [list(pair) for pair in DEFAULT_MATERIAL_RANGE_CONFIG["thick"]]
    else:
        normalized_thick = []
        for index, pair in enumerate(thick):
            if not isinstance(pair, list) or len(pair) != 2:
                normalized_thick.append(list(DEFAULT_MATERIAL_RANGE_CONFIG["thick"][index]))
            else:
                normalized_thick.append([str(value or "").strip() for value in pair])
        thick = normalized_thick

    for label in diam:
        if parse_range_spec(label) is None:
            raise ValueError(f"Некорректный диапазон диаметра: {label}")
    for pair in thick:
        for label in pair:
            if parse_range_spec(label) is None:
                raise ValueError(f"Некорректный диапазон толщины: {label}")

    return {"diam": diam, "thick": thick}


def in_material_range(value, range_info):
    if value is None or value < range_info["min"]:
        return False
    maximum = range_info["max"]
    return maximum is None or value < maximum


def material_bucket_index(diameter, thickness, range_config):
    diameter_ranges = [parse_range_spec(spec) for spec in range_config["diam"]]
    diameter_index = next(
        (index for index, item in enumerate(diameter_ranges) if in_material_range(diameter, item)),
        -1,
    )
    if diameter_index < 0:
        return -1

    thickness_ranges = [
        parse_range_spec(spec)
        for spec in range_config["thick"][diameter_index]
    ]
    thickness_index = next(
        (index for index, item in enumerate(thickness_ranges) if in_material_range(thickness, item)),
        -1,
    )
    if thickness_index < 0:
        return -1
    return diameter_index * 2 + thickness_index


def empty_material_bucket():
    return {"controlled": 0, "good": 0, "bad": 0}


def empty_material_groups():
    return {
        group: {
            "overall": empty_material_bucket(),
            "buckets": [empty_material_bucket() for _ in range(6)],
        }
        for group in MATERIAL_GROUPS
    }


def add_material_result(groups, material, diameter, thickness, result, range_config):
    if result not in ("Годен", "Не годен"):
        return
    group = material_group_of(material)
    if not group:
        return

    is_good = result == "Годен"
    record = groups[group]
    record["overall"]["controlled"] += 1
    record["overall"]["good" if is_good else "bad"] += 1

    diameter_value = parse_number(diameter)
    thickness_value = parse_number(thickness)
    if diameter_value is None or thickness_value is None:
        return

    bucket_index = material_bucket_index(diameter_value, thickness_value, range_config)
    if bucket_index < 0:
        return

    bucket = record["buckets"][bucket_index]
    bucket["controlled"] += 1
    bucket["good" if is_good else "bad"] += 1


def event_matches_scope_and_period(event, scope, start, end):
    if scope == "primary" and event.get("stage_type") != "primary":
        return False
    if scope == "repairs" and event.get("stage_type") != "repair":
        return False
    event_date = str(event.get("weld_date") or "")[:10]
    if start and event_date < start:
        return False
    if end and event_date > end:
        return False
    return True


def calc_material_stats(events, scope, start, end, range_config):
    groups = empty_material_groups()
    for event in events:
        if not event_matches_scope_and_period(event, scope, start, end):
            continue
        add_material_result(
            groups,
            event.get("material"),
            event.get("diameter"),
            event.get("thickness"),
            event.get("result"),
            range_config,
        )
    return groups


def joint_action_allowed(action, allowed_welder_ids):
    if allowed_welder_ids is None:
        return True
    action_welder_ids = {
        str(value or "")
        for value in action.get("welder_ids", [])
        if str(value or "")
    }
    return bool(action_welder_ids & allowed_welder_ids)


def calc_stats_from_joints(joints, scope, start, end, allowed_welder_ids=None):
    stats = empty_stats()
    for joint in joints:
        for action in joint.get("actions", []):
            event = {
                "stage_type": action.get("stage_type"),
                "weld_date": action.get("weld_date"),
            }
            if not event_matches_scope_and_period(event, scope, start, end):
                continue
            if not joint_action_allowed(action, allowed_welder_ids):
                continue
            add_stat(stats, {
                "inch": joint.get("inch"),
                "result": action.get("result"),
            })
    return finalize(stats)


def calc_material_stats_from_joints(joints, scope, start, end, range_config, allowed_welder_ids=None):
    groups = empty_material_groups()
    for joint in joints:
        for action in joint.get("actions", []):
            event = {
                "stage_type": action.get("stage_type"),
                "weld_date": action.get("weld_date"),
            }
            if not event_matches_scope_and_period(event, scope, start, end):
                continue
            if not joint_action_allowed(action, allowed_welder_ids):
                continue
            add_material_result(
                groups,
                joint.get("material"),
                joint.get("diameter"),
                joint.get("thickness"),
                action.get("result"),
                range_config,
            )
    return groups


def controlled_count(s):
    return int(s.get("accepted") or 0) + int(s.get("rejected") or 0)


def reject_rate_value(s):
    return "нет рк/узк" if s.get("reject_rate") is None else s.get("reject_rate")


def parse_iso_date(value: str):
    value = (value or "").strip()
    if not value:
        return None
    return datetime.strptime(value[:10], "%Y-%m-%d").date()


def dash(value):
    return value if value not in (None, "") else "—"


THIN_SIDE = Side(style="thin", color="000000")
DATA_BORDER = Border(left=THIN_SIDE, right=THIN_SIDE, top=THIN_SIDE, bottom=THIN_SIDE)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)


def copy_row_style(ws, source_row: int, target_row: int, col_start: int, col_end: int):
    for col in range(col_start, col_end + 1):
        src = ws.cell(source_row, col)
        dst = ws.cell(target_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        dst.alignment = CENTER
        dst.border = DATA_BORDER
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height or 15.75


def clear_range(ws, row_start, row_end, col_start, col_end):
    for row in range(row_start, row_end + 1):
        for col in range(col_start, col_end + 1):
            cell = ws.cell(row, col)
            cell.value = None


def prepare_sheet(ws, max_row, data_col_start, data_col_end, data_start_row=4, style_source_row=3, clear_floor=5000):
    clear_to = max(ws.max_row, max_row, clear_floor)
    clear_range(ws, data_start_row, clear_to, data_col_start, data_col_end)
    for row in range(data_start_row, max_row + 1):
        copy_row_style(ws, style_source_row, row, data_col_start, data_col_end)


def write_period_cells(ws, start_cell, end_cell, start, end):
    ws[start_cell].value = parse_iso_date(start)
    ws[end_cell].value = parse_iso_date(end)
    ws[start_cell].number_format = "dd.mm.yyyy"
    ws[end_cell].number_format = "dd.mm.yyyy"
    ws[start_cell].alignment = CENTER
    ws[end_cell].alignment = CENTER


def write_full_or_repairs(ws, rows, start, end):
    last_row = 3 + len(rows)
    prepare_sheet(ws, last_row, 3, 18)  # C:R
    write_period_cells(ws, "T3", "U3", start, end)

    for idx, row in enumerate(rows, start=4):
        all_s = row["all"]
        per_s = row["period"]
        values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            controlled_count(all_s), all_s["accepted"], all_s["rejected"], reject_rate_value(all_s),
            controlled_count(per_s), per_s["accepted"], per_s["rejected"], reject_rate_value(per_s),
        ]
        for col, value in enumerate(values, start=3):
            cell = ws.cell(idx, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (14, 18):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col >= 11:
                cell.number_format = "0"


def write_primary(ws, rows, start, end):
    last_row = 3 + len(rows)
    prepare_sheet(ws, last_row, 3, 22)  # C:V
    write_period_cells(ws, "X3", "Y3", start, end)

    for idx, row in enumerate(rows, start=4):
        all_s = row["all"]
        per_s = row["period"]
        values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            all_s["total_welded"], all_s["production"], all_s["submitted_control"], all_s["accepted"], all_s["rejected"], reject_rate_value(all_s),
            per_s["total_welded"], per_s["production"], per_s["submitted_control"], per_s["accepted"], per_s["rejected"], reject_rate_value(per_s),
        ]
        for col, value in enumerate(values, start=3):
            cell = ws.cell(idx, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (16, 22):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col in (12, 18):
                cell.number_format = "0.00"
            elif col >= 11:
                cell.number_format = "0"




def material_rate_value(bucket):
    controlled = int(bucket.get("controlled") or 0)
    return (int(bucket.get("bad") or 0) / controlled) if controlled else "—"


def material_bucket_values(bucket):
    return [
        int(bucket.get("controlled") or 0),
        int(bucket.get("good") or 0),
        int(bucket.get("bad") or 0),
        material_rate_value(bucket),
    ]


def flatten_material_groups(groups):
    values = []
    for group in MATERIAL_GROUPS:
        record = groups[group]
        values.extend(material_bucket_values(record["overall"]))
        for bucket in record["buckets"]:
            values.extend(material_bucket_values(bucket))
    return values


def rebuild_material_header_block(ws, material_start_col, range_config, headroom_groups=12):
    """Полностью пересобирает заголовок (строки 2-5) под текущее число MATERIAL_GROUPS.
    Строки: 2=название группы, 3=Общий+диаметры, 4=толщины, 5=подписи метрик (без объединения).
    Возвращает колонку сразу после последней группы."""
    ref_col = material_start_col
    header_rows = (2, 3, 4, 5)

    style_cache = {}
    for row in header_rows:
        for rel in range(28):
            src = ws.cell(row, ref_col + rel)
            style_cache[(row, rel)] = {
                "font": copy(src.font),
                "border": copy(src.border),
                "alignment": copy(src.alignment),
                "number_format": src.number_format,
            }

    max_headroom_col = material_start_col + headroom_groups * 28
    to_unmerge = []
    for mc in list(ws.merged_cells.ranges):
        if mc.min_row <= 5 and mc.max_row >= 2 and mc.min_col >= material_start_col and mc.min_col <= max_headroom_col:
            to_unmerge.append(str(mc))
    for rng in to_unmerge:
        ws.unmerge_cells(rng)

    for row in header_rows:
        for col in range(material_start_col, max_headroom_col + 1):
            cell = ws.cell(row, col)
            cell.value = None
            cell.fill = PatternFill(fill_type=None)

    diam_labels = range_config["diam"]
    thick_labels = range_config["thick"]
    metric_labels = ["Проконтроллировано", "Годен", "Не годен", "% брака"]

    for gi, group in enumerate(MATERIAL_GROUPS):
        base_col = material_start_col + gi * 28
        color_hex = (MATERIAL_GROUP_COLORS.get(group) or "#6ab3ff").lstrip("#")
        if len(color_hex) == 3:
            color_hex = "".join(c * 2 for c in color_hex)
        fill = PatternFill(fill_type="solid", fgColor="FF" + color_hex.upper())

        for row in header_rows:
            for rel in range(28):
                cell = ws.cell(row, base_col + rel)
                st = style_cache[(row, rel)]
                cell.font = st["font"]
                cell.border = st["border"]
                cell.alignment = st["alignment"]
                cell.number_format = st["number_format"]
                cell.fill = fill

        ws.merge_cells(start_row=2, start_column=base_col, end_row=2, end_column=base_col + 27)
        ws.cell(2, base_col).value = group

        ws.merge_cells(start_row=3, start_column=base_col, end_row=4, end_column=base_col + 3)
        ws.cell(3, base_col).value = "Общий"

        for di in range(3):
            d_col = base_col + 4 + di * 8
            label = diam_labels[di] if di < len(diam_labels) else ""
            t0 = thick_labels[di][0] if di < len(thick_labels) else ""
            t1 = thick_labels[di][1] if di < len(thick_labels) else ""

            ws.merge_cells(start_row=3, start_column=d_col, end_row=3, end_column=d_col + 7)
            ws.cell(3, d_col).value = label

            ws.merge_cells(start_row=4, start_column=d_col, end_row=4, end_column=d_col + 3)
            ws.cell(4, d_col).value = t0

            ws.merge_cells(start_row=4, start_column=d_col + 4, end_row=4, end_column=d_col + 7)
            ws.cell(4, d_col + 4).value = t1

        for bucket_i in range(7):
            for j, label in enumerate(metric_labels):
                ws.cell(5, base_col + bucket_i * 4 + j).value = label

    return material_start_col + len(MATERIAL_GROUPS) * 28


def add_percent_conditional_formatting(ws, col_letter, first_row, last_row, priority_start):
    from openpyxl.formatting.rule import FormulaRule
    from openpyxl.styles import Font

    rng = f"{col_letter}{first_row}:{col_letter}{last_row}"
    cell_ref = f"${col_letter}{first_row}"

    rules = [
        (f'OR({cell_ref}="—",{cell_ref}="нет рк/узк")', "00B0F0", None),
        (f'AND(ISNUMBER({cell_ref}),{cell_ref}>=0,{cell_ref}<=0.15)', "A9D08E", None),
        (f'AND(ISNUMBER({cell_ref}),{cell_ref}>0.15,{cell_ref}<=0.25)', "FFD966", None),
        (f'AND(ISNUMBER({cell_ref}),{cell_ref}>0.25,{cell_ref}<=1)', "FF5353", None),
    ]

    for i, (formula, color, font_color) in enumerate(rules):
        rule = FormulaRule(
            formula=[formula],
            fill=PatternFill(start_color=color, end_color=color, fill_type="solid"),
            font=Font(color=font_color) if font_color else None,
        )
        rule.priority = priority_start + i
        ws.conditional_formatting.add(rng, rule)


def whiten_font_on_red_rule(ws):
    from openpyxl.styles import Font

    for cf_range in ws.conditional_formatting:
        for rule in cf_range.rules:
            if rule.dxf and rule.dxf.fill and rule.dxf.fill.bgColor and rule.dxf.fill.bgColor.rgb == "FFFF5353":
                rule.dxf.font = Font(color="FFFFFFFF")


def bump_existing_conditional_formatting_priority(ws, bump=1000):
    for cf_range in ws.conditional_formatting:
        for rule in cf_range.rules:
            rule.priority += bump


def add_solid_conditional_fill(ws, col_letter, first_row, last_row, priority, color_hex):
    from openpyxl.formatting.rule import FormulaRule

    rng = f"{col_letter}{first_row}:{col_letter}{last_row}"
    rule = FormulaRule(
        formula=["TRUE()"],
        fill=PatternFill(start_color=color_hex, end_color=color_hex, fill_type="solid"),
    )
    rule.priority = priority
    ws.conditional_formatting.add(rng, rule)


def write_material_values(ws, row_index, start_col, values):
    for offset, value in enumerate(values):
        col = start_col + offset
        cell = ws.cell(row_index, col)
        cell.value = value
        cell.alignment = CENTER
        cell.border = DATA_BORDER
        if offset % 4 == 3:
            cell.number_format = "@" if isinstance(value, str) else "0.00%"
        else:
            cell.number_format = "0"


def write_material_full_or_repairs(ws, rows, start, end, range_config):
    from openpyxl.utils import get_column_letter

    data_start_row = 7
    last_row = data_start_row - 1 + len(rows)

    material_start_col = 19  # S
    data_end_col = material_start_col + len(MATERIAL_GROUPS) * 28 - 1

    prepare_sheet(ws, last_row, 3, data_end_col, data_start_row=data_start_row, style_source_row=6, clear_floor=0)
    rebuild_material_header_block(ws, material_start_col, range_config)
    bump_existing_conditional_formatting_priority(ws)

    group_fills = {}
    for group in MATERIAL_GROUPS:
        color_hex = (MATERIAL_GROUP_COLORS.get(group) or "#6ab3ff").lstrip("#")
        if len(color_hex) == 3:
            color_hex = "".join(c * 2 for c in color_hex)
        group_fills[group] = PatternFill(fill_type="solid", fgColor="FF" + color_hex.upper())

    for gi, group in enumerate(MATERIAL_GROUPS):
        base_col = material_start_col + gi * 28
        fill = group_fills[group]
        for rel in range(28):
            ws.cell(6, base_col + rel).fill = fill

    for row_index, row in enumerate(rows, start=data_start_row):
        ws.row_dimensions[row_index].height = 31.5
        all_stats = row["all"]
        period_stats = row["period"]
        base_values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            controlled_count(all_stats), all_stats["accepted"], all_stats["rejected"], reject_rate_value(all_stats),
            controlled_count(period_stats), period_stats["accepted"], period_stats["rejected"], reject_rate_value(period_stats),
        ]
        for col, value in enumerate(base_values, start=3):
            cell = ws.cell(row_index, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (14, 18):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col >= 11:
                cell.number_format = "0"
        write_material_values(ws, row_index, material_start_col, flatten_material_groups(row["materials"]))

        for gi, group in enumerate(MATERIAL_GROUPS):
            base_col = material_start_col + gi * 28
            fill = group_fills[group]
            for rel in range(28):
                ws.cell(row_index, base_col + rel).fill = fill

    ws.auto_filter.ref = f"C6:{get_column_letter(data_end_col)}{max(6, last_row)}"

    add_percent_conditional_formatting(ws, "N", data_start_row, last_row, 1)
    add_percent_conditional_formatting(ws, "R", data_start_row, last_row, 5)

    cf_priority = 100
    for gi in range(len(MATERIAL_GROUPS)):
        base_col = material_start_col + gi * 28
        for bucket_i in range(7):
            pct_col = base_col + bucket_i * 4 + 3
            add_percent_conditional_formatting(ws, get_column_letter(pct_col), data_start_row, last_row, cf_priority)
            cf_priority += 4


def write_material_primary(ws, rows, start, end, range_config):
    from openpyxl.utils import get_column_letter

    data_start_row = 7
    last_row = data_start_row - 1 + len(rows)

    material_start_col = 23  # W
    data_end_col = material_start_col + len(MATERIAL_GROUPS) * 28 - 1

    prepare_sheet(ws, last_row, 3, data_end_col, data_start_row=data_start_row, style_source_row=6, clear_floor=0)
    rebuild_material_header_block(ws, material_start_col, range_config)
    bump_existing_conditional_formatting_priority(ws)

    group_fills = {}
    for group in MATERIAL_GROUPS:
        color_hex = (MATERIAL_GROUP_COLORS.get(group) or "#6ab3ff").lstrip("#")
        if len(color_hex) == 3:
            color_hex = "".join(c * 2 for c in color_hex)
        group_fills[group] = PatternFill(fill_type="solid", fgColor="FF" + color_hex.upper())

    for gi, group in enumerate(MATERIAL_GROUPS):
        base_col = material_start_col + gi * 28
        fill = group_fills[group]
        for rel in range(28):
            ws.cell(6, base_col + rel).fill = fill

    for row_index, row in enumerate(rows, start=data_start_row):
        ws.row_dimensions[row_index].height = 31.5
        all_stats = row["all"]
        period_stats = row["period"]
        base_values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            all_stats["total_welded"], all_stats["production"], all_stats["submitted_control"], all_stats["accepted"], all_stats["rejected"], reject_rate_value(all_stats),
            period_stats["total_welded"], period_stats["production"], period_stats["submitted_control"], period_stats["accepted"], period_stats["rejected"], reject_rate_value(period_stats),
        ]
        for col, value in enumerate(base_values, start=3):
            cell = ws.cell(row_index, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (16, 22):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col in (12, 18):
                cell.number_format = "0.00"
            elif col >= 11:
                cell.number_format = "0"
        write_material_values(ws, row_index, material_start_col, flatten_material_groups(row["materials"]))

        for gi, group in enumerate(MATERIAL_GROUPS):
            base_col = material_start_col + gi * 28
            fill = group_fills[group]
            for rel in range(28):
                ws.cell(row_index, base_col + rel).fill = fill

    ws.auto_filter.ref = f"C6:{get_column_letter(data_end_col)}{max(6, last_row)}"

    add_percent_conditional_formatting(ws, "P", data_start_row, last_row, 1)
    add_percent_conditional_formatting(ws, "V", data_start_row, last_row, 5)
    add_solid_conditional_fill(ws, "L", data_start_row, last_row, 20, "00B050")
    add_solid_conditional_fill(ws, "R", data_start_row, last_row, 21, "00B050")

    cf_priority = 100
    for gi in range(len(MATERIAL_GROUPS)):
        base_col = material_start_col + gi * 28
        for bucket_i in range(7):
            pct_col = base_col + bucket_i * 4 + 3
            add_percent_conditional_formatting(ws, get_column_letter(pct_col), data_start_row, last_row, cf_priority)
            cf_priority += 4


def write_material_summary_row(ws, row_index, stats):
    values = [
        controlled_count(stats),
        int(stats.get("accepted") or 0),
        int(stats.get("rejected") or 0),
        reject_rate_value(stats),
    ]
    for offset, value in enumerate(values):
        cell = ws.cell(row_index, 2 + offset)
        cell.value = value
        cell.alignment = CENTER
        cell.border = DATA_BORDER
        cell.number_format = ("@" if isinstance(value, str) else "0.00%") if offset == 3 else "0"


MATERIALS_SCOPE_LABELS = {"repairs": "Ремонты", "primary": "Первичка", "total": "Общая"}


def write_materials_sheet(ws, start, end, scope_stats, scope_materials, range_config):
    from openpyxl.styles import Border

    whiten_font_on_red_rule(ws)

    start_date = parse_iso_date(start)
    end_date = parse_iso_date(end)
    ws["P1"].value = f"с {start_date.strftime('%d.%m.%Y')} по {end_date.strftime('%d.%m.%Y')}"
    ws["P1"].alignment = CENTER

    scopes = ("repairs", "primary", "total")
    group_count = len(MATERIAL_GROUPS)
    ref_row = 4

    style_cache = {}
    for rel in range(4):
        row = ref_row + rel
        for col in range(7, 35):
            src = ws.cell(row, col)
            style_cache[(rel, col)] = {
                "font": copy(src.font),
                "border": copy(src.border),
                "alignment": copy(src.alignment),
                "number_format": src.number_format,
            }
    q_style = {
        "font": copy(ws.cell(3, 17).font),
        "border": copy(ws.cell(3, 17).border),
        "alignment": copy(ws.cell(3, 17).alignment),
        "number_format": ws.cell(3, 17).number_format,
    }
    summary_style = {}
    for rel in range(5):
        row = ref_row + rel
        for col in range(2, 6):
            src = ws.cell(row, col)
            summary_style[(rel, col)] = {
                "font": copy(src.font),
                "border": copy(src.border),
                "alignment": copy(src.alignment),
                "fill": copy(src.fill),
                "number_format": src.number_format,
            }

    headroom_blocks = max(len(scopes) * group_count, 9) + 6
    last_headroom_row = ref_row + headroom_blocks * 7 + 6

    to_unmerge = [
        str(mc) for mc in list(ws.merged_cells.ranges)
        if mc.min_row >= 3 and mc.min_row <= last_headroom_row and mc.min_col <= 34
    ]
    for rng in to_unmerge:
        ws.unmerge_cells(rng)

    for row in range(ref_row - 1, last_headroom_row + 1):
        for col in range(2, 35):
            cell = ws.cell(row, col)
            cell.value = None
            cell.fill = PatternFill(fill_type=None)
            cell.border = Border()

    diam_cols = (11, 19, 27)
    thick_cols = ((11, 15), (19, 23), (27, 31))
    metric_labels = ["Проконтроллировано", "Годен", "Не годен", "% брака"]
    summary_labels = ["Проконтро-лировано", "Годные за период", "Не годные за период", "% брака за период"]

    block_rows = {}
    summary_rows = {}

    for si, scope in enumerate(scopes):
        for gi, group in enumerate(MATERIAL_GROUPS):
            global_index = si * group_count + gi
            header_row = ref_row + global_index * 7
            values_row = header_row + 4
            block_rows[(scope, group)] = (header_row, values_row)

            color_hex = (MATERIAL_GROUP_COLORS.get(group) or "#6ab3ff").lstrip("#")
            if len(color_hex) == 3:
                color_hex = "".join(c * 2 for c in color_hex)
            fill = PatternFill(fill_type="solid", fgColor="FF" + color_hex.upper())

            for rel in range(4):
                row = header_row + rel
                for col in range(7, 35):
                    cell = ws.cell(row, col)
                    st = style_cache[(rel, col)]
                    cell.font = st["font"]
                    cell.border = st["border"]
                    cell.alignment = st["alignment"]
                    cell.number_format = st["number_format"]
                    cell.fill = fill

            ws.merge_cells(start_row=header_row, start_column=7, end_row=header_row, end_column=34)
            ws.cell(header_row, 7).value = group

            ws.merge_cells(start_row=header_row + 1, start_column=7, end_row=header_row + 2, end_column=10)
            ws.cell(header_row + 1, 7).value = "Общий"

            for di in range(3):
                dcol = diam_cols[di]
                label = range_config["diam"][di] if di < len(range_config["diam"]) else ""
                ws.merge_cells(start_row=header_row + 1, start_column=dcol, end_row=header_row + 1, end_column=dcol + 7)
                ws.cell(header_row + 1, dcol).value = label

                t0, t1 = thick_cols[di]
                v0 = range_config["thick"][di][0] if di < len(range_config["thick"]) else ""
                v1 = range_config["thick"][di][1] if di < len(range_config["thick"]) else ""
                ws.merge_cells(start_row=header_row + 2, start_column=t0, end_row=header_row + 2, end_column=t0 + 3)
                ws.cell(header_row + 2, t0).value = v0
                ws.merge_cells(start_row=header_row + 2, start_column=t1, end_row=header_row + 2, end_column=t1 + 3)
                ws.cell(header_row + 2, t1).value = v1

            sub_row = header_row + 3
            for i in range(7):
                for j, label in enumerate(metric_labels):
                    ws.cell(sub_row, 7 + i * 4 + j).value = label

            label_row = header_row - 1
            ws.merge_cells(start_row=label_row, start_column=17, end_row=label_row, end_column=18)
            q_cell = ws.cell(label_row, 17)
            q_cell.value = f"{MATERIALS_SCOPE_LABELS.get(scope, scope)} {group}"
            q_cell.font = q_style["font"]
            q_cell.border = q_style["border"]
            q_cell.alignment = q_style["alignment"]
            q_cell.number_format = q_style["number_format"]

        if MATERIAL_GROUPS:
            summary_rows[scope] = block_rows[(scope, MATERIAL_GROUPS[0])][1]

        scope_header_row = ref_row + si * group_count * 7

        for col in range(2, 6):
            for rel in range(4):
                row = scope_header_row + rel
                cell = ws.cell(row, col)
                st = summary_style[(rel, col)]
                cell.font = st["font"]
                cell.border = st["border"]
                cell.alignment = st["alignment"]
                cell.number_format = st["number_format"]
                cell.fill = st["fill"]

            values_row = scope_header_row + 4
            vcell = ws.cell(values_row, col)
            st = summary_style[(4, col)]
            vcell.font = st["font"]
            vcell.border = st["border"]
            vcell.alignment = st["alignment"]
            vcell.number_format = st["number_format"]
            vcell.fill = st["fill"]

        for j, col in enumerate(range(2, 6)):
            ws.merge_cells(start_row=scope_header_row, start_column=col, end_row=scope_header_row + 3, end_column=col)
            ws.cell(scope_header_row, col).value = summary_labels[j]

    for scope, row_index in summary_rows.items():
        write_material_summary_row(ws, row_index, scope_stats[scope])

    for (scope, group), (header_start_row, values_row) in block_rows.items():
        record = scope_materials[scope][group]
        values = material_bucket_values(record["overall"])
        for bucket in record["buckets"]:
            values.extend(material_bucket_values(bucket))
        write_material_values(ws, values_row, 7, values)  # G:AH
        ws.row_dimensions[values_row].height = ws.row_dimensions[values_row].height or 18


def build_export_workbook(start: str, end: str, org_filter: str = "", include_materials=False, material_range_config=None) -> Path:
    if include_materials:
        refresh_material_groups_from_object()
    range_config = normalize_material_range_config(material_range_config)
    template_path = MATERIAL_TEMPLATE_PATH if include_materials else TEMPLATE_PATH
    if not template_path.exists():
        raise FileNotFoundError(f"Не найден шаблон: {template_path}")

    _manifest, welders, welder_events, joints = load_sharded_database(include_joints=include_materials)

    org_filter_n = str(org_filter or "").casefold().replace("ё", "е").strip()
    if org_filter_n:
        welders = [
            w for w in welders
            if org_filter_n in str(w.get("organization") or "").casefold().replace("ё", "е")
        ]

    allowed_welder_ids = None if not org_filter_n else {
        str(w.get("id") or "") for w in welders if str(w.get("id") or "")
    }

    def row_common(w):
        return {
            "shift": w.get("shift"),
            "position": w.get("position"),
            "responsible": w.get("responsible"),
            "name": w.get("name"),
            "stamp": w.get("stamp"),
            "status": w.get("status"),
            "organization": w.get("organization"),
        }

    rows_by_scope = {"total": [], "primary": [], "repairs": []}
    for w in welders:
        events = welder_events.get(w.get("id"), [])
        for scope in rows_by_scope:
            item = row_common(w)
            item["all"] = calc_stats(events, scope)
            item["period"] = calc_stats(events, scope, start, end)
            if include_materials:
                item["materials"] = calc_material_stats(events, scope, start, end, range_config)
            rows_by_scope[scope].append(item)

    # STATV2 MATERIAL EXPORT TOTAL ROW START
    if include_materials:
        for scope in rows_by_scope:
            total_item = {
                "shift": "—",
                "position": "—",
                "responsible": "—",
                "name": "# ИТОГО",
                "stamp": "—",
                "status": "—",
                "organization": "—",
            }

            # Статистика за всё время.
            # Считаем непосредственно по стыкам, а не суммой сварщиков.
            total_item["all"] = calc_stats_from_joints(
                joints,
                scope,
                "",
                "",
                allowed_welder_ids,
            )

            # Статистика за выбранный период.
            total_item["period"] = calc_stats_from_joints(
                joints,
                scope,
                start,
                end,
                allowed_welder_ids,
            )

            # Итоговые 84 столбца материалов за выбранный период.
            total_item["materials"] = calc_material_stats_from_joints(
                joints,
                scope,
                start,
                end,
                range_config,
                allowed_welder_ids,
            )

            rows_by_scope[scope].append(total_item)
    # STATV2 MATERIAL EXPORT TOTAL ROW END

    wb = load_workbook(template_path, keep_vba=True)

    if include_materials:
        required_sheets = [
            "Полная с разбивкой",
            "Первичка с разбивкой",
            "Ремонты с разбивкой",
            "Материалы",
            "Период",
        ]
        for name in required_sheets:
            if name not in wb.sheetnames:
                raise ValueError(f"В шаблоне нет листа: {name}")

        write_period_cells(wb["Период"], "C5", "D5", start, end)
        write_material_full_or_repairs(wb["Полная с разбивкой"], rows_by_scope["total"], start, end, range_config)
        write_material_primary(wb["Первичка с разбивкой"], rows_by_scope["primary"], start, end, range_config)
        write_material_full_or_repairs(wb["Ремонты с разбивкой"], rows_by_scope["repairs"], start, end, range_config)

        scope_stats = {
            scope: calc_stats_from_joints(joints, scope, start, end, allowed_welder_ids)
            for scope in rows_by_scope
        }
        scope_materials = {
            scope: calc_material_stats_from_joints(
                joints,
                scope,
                start,
                end,
                range_config,
                allowed_welder_ids,
            )
            for scope in rows_by_scope
        }
        write_materials_sheet(
            wb["Материалы"],
            start,
            end,
            scope_stats,
            scope_materials,
            range_config,
        )
    else:
        required_sheets = ["Полная статистика", "Первичка", "Ремонты"]
        for name in required_sheets:
            if name not in wb.sheetnames:
                raise ValueError(f"В шаблоне нет листа: {name}")

        write_full_or_repairs(wb["Полная статистика"], rows_by_scope["total"], start, end)
        write_primary(wb["Первичка"], rows_by_scope["primary"], start, end)
        write_full_or_repairs(wb["Ремонты"], rows_by_scope["repairs"], start, end)

    prefix = "statv2_export_materials_" if include_materials else "statv2_export_"
    tmp = tempfile.NamedTemporaryFile(prefix=prefix, suffix=".xlsm", delete=False)
    tmp_path = Path(tmp.name)
    tmp.close()
    wb.save(tmp_path)
    return tmp_path


@APP.get("/api/export_stats_excel")
def export_stats_excel():
    if not (is_role("admin") or basic_authorized()):
        return error("Нет доступа", 401)

    start = (request.args.get("start") or "").strip()
    end = (request.args.get("end") or "").strip()
    if not start or not end:
        return error("Нужны параметры start и end")
    try:
        parse_iso_date(start)
        parse_iso_date(end)
    except Exception:
        return error("Дата должна быть в формате YYYY-MM-DD")

    mode = (request.args.get("mode") or "normal").strip().lower()
    include_materials = mode == "materials"
    material_range_config = None
    if include_materials:
        raw_ranges = (request.args.get("ranges") or "").strip()
        if raw_ranges:
            try:
                material_range_config = json.loads(raw_ranges)
            except Exception:
                return error("Некорректные настройки диапазонов материалов")

    try:
        output_path = build_export_workbook(
            start,
            end,
            str(session.get("org_filter") or ""),
            include_materials=include_materials,
            material_range_config=material_range_config,
        )
    except ValueError as exc:
        return error(str(exc), 400)
    except Exception as exc:
        return error(str(exc), 500)

    export_stamp = datetime.now().strftime("%d.%m.%Y %H.%M.%S")
    name_suffix = "_materials" if include_materials else ""
    filename = f"statv2_stats{name_suffix}_{export_stamp}.xlsm"

    @after_this_request
    def cleanup(response):
        try:
            output_path.unlink(missing_ok=True)
        except Exception:
            pass
        return response

    return send_file(
        output_path,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.ms-excel.sheet.macroEnabled.12",
        max_age=0,
    )




# SPK CONTRACTORS EXCEL EXPORT START

from pathlib import Path as _SpkExcelPath

SPK_CONTRACTORS_EXCEL_TEMPLATE = (
    _SpkExcelPath(__file__).resolve().parent
    / "templates"
    / "SPK_podryad.xlsx"
)


def _spk_excel_text(value, max_len=500):
    value = str(value or "").strip()
    return value[:max_len]


def _spk_excel_int(value):
    try:
        return max(0, int(round(float(value or 0))))
    except Exception:
        return 0


def _spk_excel_rate(value):
    """
    JS передаёт процент как 3.2.
    Excel должен получить 0.032 с форматом 0.0%.
    """
    if value is None:
        return None

    raw = str(value).strip().replace(",", ".")

    if not raw or raw in {"—", "-"}:
        return None

    try:
        return float(raw) / 100.0
    except Exception:
        return None


def _spk_excel_clone_contractor_block(ws, target_start_row):
    """
    В шаблоне строки 5:7 — один подрядчик.
    Копируем их оформление для следующего подрядчика.
    """
    from copy import copy
    from openpyxl.cell.cell import MergedCell

    source_start_row = 5

    for offset in range(3):
        source_row = source_start_row + offset
        target_row = target_start_row + offset

        src_dim = ws.row_dimensions[source_row]
        dst_dim = ws.row_dimensions[target_row]

        dst_dim.height = src_dim.height
        dst_dim.hidden = src_dim.hidden
        dst_dim.outlineLevel = src_dim.outlineLevel

        for col in range(1, 34):  # A:AG
            source_cell = ws._cells.get((source_row, col))
            target_cell = ws.cell(target_row, col)

            if source_cell is None:
                continue

            if not isinstance(source_cell, MergedCell):
                target_cell.value = source_cell.value

            style = getattr(source_cell, "_style", None)

            if style is not None:
                target_cell._style = copy(style)

            if getattr(source_cell, "alignment", None) is not None:
                target_cell.alignment = copy(source_cell.alignment)

            if getattr(source_cell, "protection", None) is not None:
                target_cell.protection = copy(source_cell.protection)

    # Такие же объединения, как у первого подрядчика.
    for column in ("A", "B", "C", "D", "O", "X", "AG"):
        ws.merge_cells(
            f"{column}{target_start_row}:"
            f"{column}{target_start_row + 2}"
        )


def _spk_excel_write_total_rate(cell, stats):
    from openpyxl.styles import Font

    stats = stats if isinstance(stats, dict) else {}
    rate = _spk_excel_rate(stats.get("totalRate"))

    if rate is None:
        cell.value = "—"
    else:
        cell.value = rate
        cell.number_format = "0.0%"

    old_font = cell.font
    cell.font = Font(
        name=old_font.name,
        size=old_font.size,
        bold=old_font.bold,
        italic=old_font.italic,
        color="FF9C0006",
    )


def _spk_excel_write_period(ws, row, first_col, stats):
    stats = stats if isinstance(stats, dict) else {}

    # 1. Сварено
    ws.cell(row, first_col).value = _spk_excel_int(
        stats.get("welded")
    )

    # 2. Проконтролировано
    ws.cell(row, first_col + 1).value = _spk_excel_int(
        stats.get("controlled")
    )

    # 3. Ремонт / вырез
    ws.cell(row, first_col + 2).value = _spk_excel_int(
        stats.get("bad")
    )

    # 4. Первичный брак, %
    rate = _spk_excel_rate(stats.get("rate"))
    rate_cell = ws.cell(row, first_col + 3)

    if rate is None:
        rate_cell.value = "—"
    else:
        rate_cell.value = rate
        rate_cell.number_format = "0.0%"

    # 5. Повторно проконтролировано
    ws.cell(row, first_col + 4).value = _spk_excel_int(
        stats.get("repairControlled")
    )

    # 6. Повторный ремонт / вырез
    ws.cell(row, first_col + 5).value = _spk_excel_int(
        stats.get("repairBad")
    )

    # 7. Повторный брак, %
    repair_rate = _spk_excel_rate(stats.get("repairRate"))
    repair_rate_cell = ws.cell(row, first_col + 6)

    if repair_rate is None:
        repair_rate_cell.value = "—"
    else:
        repair_rate_cell.value = repair_rate
        repair_rate_cell.number_format = "0.0%"

    # 8. Всего ремонтов, вырезов
    ws.cell(row, first_col + 7).value = _spk_excel_int(
        stats.get("totalBad")
    )

    # 9-й показатель (Общий уровень брака, %) — объединённая ячейка
    # на 3 строки, пишется отдельно в export_spk_contractors_excel().


@APP.post("/api/export_spk_contractors_excel")
def export_spk_contractors_excel():
    if not (is_role("admin") or basic_authorized()):
        return error("Нет доступа", 401)

    from openpyxl import load_workbook
    import tempfile

    payload = request.get_json(silent=True) or {}

    contractors = payload.get("contractors") or []

    if not isinstance(contractors, list):
        return error("Некорректный список подрядчиков", 400)

    if not contractors:
        return error("Нет подрядчиков для выгрузки", 400)

    if len(contractors) > 200:
        return error("Слишком много подрядчиков", 400)

    template_path = SPK_CONTRACTORS_EXCEL_TEMPLATE

    if not template_path.exists():
        return error(
            f"Не найден шаблон Excel: {template_path}",
            500,
        )

    try:
        wb = load_workbook(template_path)

        sheet_name = "Субподряд ТТ"

        if sheet_name not in wb.sheetnames:
            raise ValueError(
                f"В шаблоне нет листа: {sheet_name}"
            )

        ws = wb[sheet_name]

        month_label = _spk_excel_text(
            payload.get("month_label"),
            100,
        )

        week_label = _spk_excel_text(
            payload.get("week_label"),
            100,
        )

        ws["P3"] = (
            "За предыдущий месяц"
            + (f" - {month_label}" if month_label else "")
        )

        ws["Y3"] = (
            "За предыдущую неделю"
            + (f" - {week_label}" if week_label else "")
        )

        row_types = [
            ("shop", "ЦЕХ (S)"),
            ("field", "Монтаж (F)"),
            ("total", "ВСЕГО"),
        ]

        for contractor_index, contractor in enumerate(contractors):
            if not isinstance(contractor, dict):
                continue

            base_row = 5 + contractor_index * 3

            if contractor_index > 0:
                _spk_excel_clone_contractor_block(
                    ws,
                    base_row,
                )

            # Основная информация о подрядчике.
            ws.cell(base_row, 1).value = _spk_excel_text(
                contractor.get("object_name")
            )

            ws.cell(base_row, 2).value = _spk_excel_text(
                contractor.get("subcontractor")
            )

            allowed_rate = _spk_excel_rate(
                contractor.get("allowed_reject_rate")
            )

            allowed_cell = ws.cell(base_row, 3)

            if allowed_rate is None:
                allowed_cell.value = "—"
            else:
                allowed_cell.value = allowed_rate
                allowed_cell.number_format = "0.0%"

            # Поля пока нет в настройках сайта.
            ws.cell(base_row, 4).value = _spk_excel_text(
                contractor.get("contract_ref")
            )

            incoming_rows = contractor.get("rows") or []

            row_map = {
                str(item.get("row_type") or ""): item
                for item in incoming_rows
                if isinstance(item, dict)
            }

            for row_offset, (row_type, row_label) in enumerate(row_types):
                row = base_row + row_offset

                ws.cell(row, 5).value = row_label
                ws.cell(row, 6).value = "ст."

                item = row_map.get(row_type) or {}

                # G:O — всё время
                _spk_excel_write_period(
                    ws,
                    row,
                    7,
                    item.get("all"),
                )

                # P:X — предыдущий месяц
                _spk_excel_write_period(
                    ws,
                    row,
                    16,
                    item.get("month"),
                )

                # Y:AG — предыдущая неделя
                _spk_excel_write_period(
                    ws,
                    row,
                    25,
                    item.get("week"),
                )

            # Последний показатель каждого периода —
            # объединённая ячейка на три строки, общий % брака
            # подрядчика целиком (строка "ВСЕГО" = цех + монтаж).
            total_item = row_map.get("total") or {}
            _spk_excel_write_total_rate(
                ws.cell(base_row, 15), total_item.get("all")
            )   # O
            _spk_excel_write_total_rate(
                ws.cell(base_row, 24), total_item.get("month")
            )   # X
            _spk_excel_write_total_rate(
                ws.cell(base_row, 33), total_item.get("week")
            )   # AG

        last_row = 4 + len(contractors) * 3

        try:
            ws.print_area = f"A1:AG{last_row}"
        except Exception:
            pass

        tmp = tempfile.NamedTemporaryFile(
            prefix="statv2_spk_contractors_",
            suffix=".xlsx",
            delete=False,
        )

        output_path = _SpkExcelPath(tmp.name)
        tmp.close()

        wb.save(output_path)
        wb.close()

    except ValueError as exc:
        return error(str(exc), 400)

    except Exception as exc:
        return error(str(exc), 500)

    export_stamp = datetime.now().strftime(
        "%d.%m.%Y %H.%M.%S"
    )

    filename = (
        f"SPK_podryad_{export_stamp}.xlsx"
    )

    @after_this_request
    def cleanup_spk_contractors_excel(response):
        try:
            output_path.unlink(missing_ok=True)
        except Exception:
            pass

        return response

    return send_file(
        output_path,
        as_attachment=True,
        download_name=filename,
        mimetype=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        max_age=0,
    )


# SPK CONTRACTORS EXCEL EXPORT END

# SPK DAILY EXCEL AND OBJECT SETTINGS START

SPK_DEFAULT_OBJECT_ID = "agkh-smk"
SPK_DEFAULT_OBJECT_NAME = "АГХК-СМК"


def statv2_default_spk_objects_payload():
    return {
        "version": 1,
        "objects": {
            SPK_DEFAULT_OBJECT_ID: {
                "id": SPK_DEFAULT_OBJECT_ID,
                "name": SPK_DEFAULT_OBJECT_NAME,
                "daily_spk": {
                    "allowed_reject_rate": None,
                    "average_ndt_percent": None,
                    "organization": "",
                },
                "material_groups": [
                    {"key": key, "name": key, "codes": list(codes)}
                    for key, codes in MATERIAL_GROUP_RAW.items()
                ],
                "base_ranges": {
                    "diam": list(DEFAULT_MATERIAL_RANGE_CONFIG["diam"]),
                    "thick": [list(pair) for pair in DEFAULT_MATERIAL_RANGE_CONFIG["thick"]],
                },
            }
        },
    }


def statv2_read_spk_objects():
    payload = statv2_default_spk_objects_payload()

    try:
        if SPK_OBJECTS_PATH.exists():
            loaded = json.loads(
                SPK_OBJECTS_PATH.read_text(
                    encoding="utf-8"
                )
            )

            if isinstance(loaded, dict):
                objects = loaded.get("objects")

                if isinstance(objects, dict):
                    for object_id, source in objects.items():
                        if not isinstance(source, dict):
                            continue

                        object_id = str(
                            object_id or ""
                        ).strip()

                        if not object_id:
                            continue

                        current = (
                            payload["objects"].get(
                                object_id,
                                {
                                    "id": object_id,
                                    "name": object_id,
                                    "daily_spk": {},
                                },
                            )
                        )

                        daily = source.get(
                            "daily_spk"
                        )

                        if not isinstance(
                            daily,
                            dict,
                        ):
                            daily = {}

                        current["id"] = object_id
                        current["name"] = str(
                            source.get("name")
                            or current.get("name")
                            or object_id
                        )

                        current["daily_spk"] = {
                            "allowed_reject_rate":
                                daily.get(
                                    "allowed_reject_rate"
                                ),
                            "average_ndt_percent":
                                daily.get(
                                    "average_ndt_percent"
                                ),
                            "organization":
                                str(
                                    daily.get(
                                        "organization"
                                    )
                                    or ""
                                ).strip(),
                        }

                        current["material_groups"] = (
                            statv2_sanitize_material_groups(
                                source.get("material_groups"),
                                current.get("material_groups"),
                            )
                        )

                        current["base_ranges"] = (
                            statv2_sanitize_base_ranges(
                                source.get("base_ranges"),
                                current.get("base_ranges"),
                            )
                        )

                        payload["objects"][
                            object_id
                        ] = current
    except Exception:
        pass

    return payload


def statv2_write_spk_objects(payload):
    SPK_OBJECTS_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temp_path = (
        SPK_OBJECTS_PATH.with_suffix(".tmp")
    )

    temp_path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    temp_path.replace(
        SPK_OBJECTS_PATH
    )

    try:
        SPK_OBJECTS_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_get_spk_object(object_id):
    object_id = str(
        object_id or ""
    ).strip()

    return (
        statv2_read_spk_objects()
        .get("objects", {})
        .get(object_id)
    )


def statv2_optional_percent(
    value,
    label,
):
    raw = str(
        "" if value is None else value
    ).strip().replace(",", ".")

    if not raw:
        return None

    try:
        number = float(raw)
    except Exception as exc:
        raise ValueError(
            f"{label} должен быть числом"
        ) from exc

    if not 0 <= number <= 100:
        raise ValueError(
            f"{label} должен быть от 0 до 100%"
        )

    return number


@APP.get("/api/stat_admin/objects")
def statv2_stat_admin_objects():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    payload = statv2_read_spk_objects()

    return jsonify({
        "ok": True,
        "objects": list(
            payload.get(
                "objects",
                {},
            ).values()
        ),
    })


@APP.post(
    "/api/stat_admin/objects/"
    "<object_id>/daily_spk"
)
def statv2_stat_admin_save_daily_spk(
    object_id
):
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    payload = statv2_read_spk_objects()
    objects = payload.setdefault(
        "objects",
        {},
    )

    obj = objects.get(object_id)

    if not isinstance(obj, dict):
        return error(
            "Объект не найден",
            404,
        )

    data = (
        request.get_json(silent=True)
        or request.form
        or {}
    )

    try:
        allowed_reject_rate = (
            statv2_optional_percent(
                data.get(
                    "allowed_reject_rate"
                ),
                "Допустимый уровень брака",
            )
        )

        average_ndt_percent = (
            statv2_optional_percent(
                data.get(
                    "average_ndt_percent"
                ),
                "Средний процент НК по проекту",
            )
        )

    except ValueError as exc:
        return error(
            str(exc),
            400,
        )

    obj["daily_spk"] = {
        "allowed_reject_rate":
            allowed_reject_rate,

        "average_ndt_percent":
            average_ndt_percent,

        "organization":
            str(
                data.get("organization")
                or ""
            ).strip()[:200],
    }

    statv2_write_spk_objects(
        payload
    )

    return jsonify({
        "ok": True,
        "message":
            "Настройки ежедневной СПК сохранены",
        "object": obj,
    })


def statv2_validate_material_groups(raw):
    if raw is None:
        raw = []

    if not isinstance(raw, list):
        raise ValueError("material_groups должен быть списком")

    result = []
    seen_keys = set()

    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"Группа №{idx + 1}: некорректный формат")

        name = str(item.get("name") or "").strip()

        if not name:
            raise ValueError(f"Группа №{idx + 1}: не указано название")

        key = norm_material_key(name)

        if not key:
            raise ValueError(f"Группа №{idx + 1}: некорректное название")

        if key in seen_keys:
            raise ValueError(f"Группа «{name}» указана дважды")

        seen_keys.add(key)

        codes_raw = item.get("codes")

        if not isinstance(codes_raw, list):
            codes_raw = []

        codes = []

        for code in codes_raw:
            code_str = str(code or "").strip()

            if code_str:
                codes.append(code_str[:100])

        color = str(item.get("color") or "").strip()

        def _is_valid_hex_color(value):
            if len(value) != 7 or value[0] != "#":
                return False
            return all(ch in "0123456789abcdefABCDEF" for ch in value[1:])

        if color and not _is_valid_hex_color(color):
            raise ValueError(f"Группа «{name}»: цвет должен быть в формате #RRGGBB")

        result.append({
            "key": key,
            "name": name[:100],
            "codes": codes[:200],
            "color": color or "#6ab3ff",
        })

    if len(result) > 50:
        raise ValueError("Слишком много групп (максимум 50)")

    return result


def statv2_validate_base_ranges(raw):
    if not isinstance(raw, dict):
        raise ValueError("base_ranges должен быть объектом")

    diam_raw = raw.get("diam")

    if not isinstance(diam_raw, list) or len(diam_raw) != 3:
        raise ValueError("Нужно ровно 3 диапазона диаметра")

    diam = [str(d or "").strip()[:50] for d in diam_raw]

    if any(not d for d in diam):
        raise ValueError("Все диапазоны диаметра должны быть заполнены")

    thick_raw = raw.get("thick")

    if not isinstance(thick_raw, list) or len(thick_raw) != 3:
        raise ValueError("Нужно 3 набора толщин (по одному на диаметр)")

    thick = []

    for i, group in enumerate(thick_raw):
        if not isinstance(group, list) or len(group) != 2:
            raise ValueError(f"Для диаметра №{i + 1} нужно ровно 2 диапазона толщины")

        pair = [str(t or "").strip()[:50] for t in group]

        if any(not t for t in pair):
            raise ValueError(f"Толщины для диаметра №{i + 1} должны быть заполнены")

        thick.append(pair)

    return {"diam": diam, "thick": thick}


def statv2_sanitize_material_groups(raw, fallback=None):
    try:
        return statv2_validate_material_groups(raw)
    except Exception:
        return fallback if fallback is not None else []


def statv2_sanitize_base_ranges(raw, fallback=None):
    try:
        return statv2_validate_base_ranges(raw)
    except Exception:
        if fallback is not None:
            return fallback
        return {
            "diam": list(DEFAULT_MATERIAL_RANGE_CONFIG["diam"]),
            "thick": [list(pair) for pair in DEFAULT_MATERIAL_RANGE_CONFIG["thick"]],
        }


@APP.post(
    "/api/stat_admin/objects/"
    "<object_id>/materials"
)
def statv2_stat_admin_save_materials(object_id):
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    payload = statv2_read_spk_objects()
    objects = payload.setdefault("objects", {})

    obj = objects.get(object_id)

    if not isinstance(obj, dict):
        return error("Объект не найден", 404)

    data = (
        request.get_json(silent=True)
        or request.form
        or {}
    )

    updated_fields = []

    if "material_groups" in data:
        try:
            material_groups = statv2_validate_material_groups(data.get("material_groups"))
        except ValueError as exc:
            return error(str(exc), 400)
        obj["material_groups"] = material_groups
        updated_fields.append("material_groups")

    if "base_ranges" in data:
        try:
            base_ranges = statv2_validate_base_ranges(data.get("base_ranges"))
        except ValueError as exc:
            return error(str(exc), 400)
        obj["base_ranges"] = base_ranges
        updated_fields.append("base_ranges")

    if not updated_fields:
        return error("Нечего сохранять", 400)

    statv2_write_spk_objects(payload)

    try:
        live_manifest_path = DB_TARGET / "manifest.json"
        if live_manifest_path.exists():
            live_manifest = json.loads(live_manifest_path.read_text(encoding="utf-8"))
            if "material_groups" in updated_fields:
                live_manifest["material_groups"] = obj["material_groups"]
            if "base_ranges" in updated_fields:
                live_manifest["base_ranges"] = obj["base_ranges"]
            live_manifest_path.write_text(
                json.dumps(live_manifest, ensure_ascii=False, separators=(",", ":")),
                encoding="utf-8",
            )
    except Exception:
        pass

    return jsonify({
        "ok": True,
        "message": "Группы сталей и диапазоны сохранены",
        "object": obj,
    })


def _spk_daily_excel_count(
    cell,
    value,
    blank_when_missing=False,
):
    if (
        value is None
        or str(value).strip()
        in {"", "—", "-"}
    ):
        cell.value = (
            "—"
            if blank_when_missing
            else 0
        )
        return

    cell.value = _spk_excel_int(
        value
    )


def _spk_daily_excel_rate(
    cell,
    value,
):
    rate = _spk_excel_rate(
        value
    )

    if rate is None:
        cell.value = "—"
        return

    cell.value = rate
    cell.number_format = "0.00%"


def _spk_daily_excel_write_period(
    ws,
    row,
    first_col,
    stats,
    all_time=False,
):
    stats = (
        stats
        if isinstance(stats, dict)
        else {}
    )

    _spk_daily_excel_count(
        ws.cell(row, first_col),
        stats.get("welded"),
    )

    _spk_daily_excel_count(
        ws.cell(row, first_col + 1),
        stats.get("controlled"),
    )

    if all_time:
        _spk_daily_excel_count(
            ws.cell(row, first_col + 2),
            stats.get("lnkBacklog"),
            blank_when_missing=True,
        )

        _spk_daily_excel_count(
            ws.cell(row, first_col + 3),
            stats.get("cut"),
        )

        _spk_daily_excel_count(
            ws.cell(row, first_col + 4),
            stats.get("repair"),
        )

        _spk_daily_excel_count(
            ws.cell(row, first_col + 5),
            stats.get("repairBacklog"),
            blank_when_missing=True,
        )

        _spk_daily_excel_rate(
            ws.cell(row, first_col + 6),
            stats.get("ofRate"),
        )

        _spk_daily_excel_rate(
            ws.cell(row, first_col + 7),
            stats.get("rejectRate"),
        )

        return

    _spk_daily_excel_count(
        ws.cell(row, first_col + 2),
        stats.get("cut"),
    )

    _spk_daily_excel_count(
        ws.cell(row, first_col + 3),
        stats.get("repair"),
    )

    _spk_daily_excel_rate(
        ws.cell(row, first_col + 4),
        stats.get("ofRate"),
    )

    _spk_daily_excel_rate(
        ws.cell(row, first_col + 5),
        stats.get("rejectRate"),
    )


@APP.post("/api/export_spk_daily_excel")
def export_spk_daily_excel():
    if str(
        session.get("role") or ""
    ) != "admin":
        return error("Нет доступа", 401)

    if (
        str(
            session.get(
                "account_filter_value"
            ) or ""
        ).strip()
        or str(
            session.get("org_filter") or ""
        ).strip()
    ):
        return error(
            "Выгрузка общей ежедневной СПК "
            "доступна только полной "
            "админской учётке",
            403,
        )

    payload = (
        request.get_json(silent=True)
        or {}
    )

    object_id = str(
        payload.get("object_id")
        or SPK_DEFAULT_OBJECT_ID
    ).strip()

    obj = statv2_get_spk_object(
        object_id
    )

    if not isinstance(obj, dict):
        return error(
            "Объект не найден",
            404,
        )

    rows = payload.get("rows") or []

    if not isinstance(rows, list):
        return error(
            "Некорректные данные СПК",
            400,
        )

    row_map = {
        str(
            item.get("row_type")
            or ""
        ): item
        for item in rows
        if isinstance(item, dict)
    }

    required_rows = {
        "shop",
        "field",
        "total",
    }

    if not required_rows.issubset(
        set(row_map)
    ):
        return error(
            "Не хватает строк ежедневной СПК",
            400,
        )

    shift_raw = str(
        payload.get("shift_date")
        or ""
    )[:10]

    try:
        shift_date = datetime.strptime(
            shift_raw,
            "%Y-%m-%d",
        ).date()
    except Exception:
        return error(
            "Некорректная дата прошедшей смены",
            400,
        )

    if not SPK_DAILY_EXCEL_TEMPLATE.exists():
        return error(
            "Не найден шаблон Excel: "
            f"{SPK_DAILY_EXCEL_TEMPLATE}",
            500,
        )

    try:
        wb = load_workbook(
            SPK_DAILY_EXCEL_TEMPLATE
        )

        sheet_name = (
            "справка по качеству"
        )

        if sheet_name not in wb.sheetnames:
            raise ValueError(
                "В шаблоне нет листа: "
                + sheet_name
            )

        ws = wb[sheet_name]

        object_name = str(
            obj.get("name")
            or SPK_DEFAULT_OBJECT_NAME
        ).strip()

        ws["A1"] = (
            'Уровень качества сварочных работ, '
            'выполняемых ООО "СМК" '
            'на объекте строительства '
            + object_name
        )

        daily_cfg = obj.get(
            "daily_spk"
        )

        if not isinstance(
            daily_cfg,
            dict,
        ):
            daily_cfg = {}

        # Настройки из admin_stat.
        ws["J2"] = daily_cfg.get(
            "allowed_reject_rate"
        )

        ws["Q2"] = daily_cfg.get(
            "average_ndt_percent"
        )

        # "По факту" пока оставляем пустым.
        ws["V2"] = None

        # Сегодняшняя дата.
        report_date = (
            datetime.now().date()
        )

        ws["AA2"] = report_date
        ws["AA2"].number_format = (
            "dd.mm.yyyy"
        )

        # В AA3 уже формула =AA2-1.
        ws["AA3"].number_format = (
            "dd.mm.yyyy"
        )

        month_label = _spk_excel_text(
            payload.get("month_label"),
            100,
        )

        week_label = _spk_excel_text(
            payload.get("week_label"),
            100,
        )

        ws["K4"] = (
            "За предыдущий месяц"
            + (
                f" - {month_label}"
                if month_label
                else ""
            )
        )

        ws["Q4"] = (
            "За предыдущую календарную неделю"
            + (
                f" - {week_label}"
                if week_label
                else ""
            )
        )

        # Дата из поля "Прошедшая смена".
        ws["W5"] = shift_date
        ws["W5"].number_format = (
            "dd.mm.yyyy"
        )

        excel_rows = {
            "shop": 8,
            "field": 9,
            "total": 10,
        }

        labels = {
            "shop": "ЦЕХ (S)",
            "field": "Монтаж (F)",
            "total": "ОБЩИЙ",
        }

        for (
            row_type,
            excel_row,
        ) in excel_rows.items():

            item = row_map[row_type]

            ws.cell(
                excel_row,
                1,
            ).value = labels[row_type]

            ws.cell(
                excel_row,
                2,
            ).value = "ст."

            # C:J — весь период.
            _spk_daily_excel_write_period(
                ws,
                excel_row,
                3,
                item.get("all"),
                all_time=True,
            )

            # K:P — предыдущий месяц.
            _spk_daily_excel_write_period(
                ws,
                excel_row,
                11,
                item.get("month"),
            )

            # Q:V — предыдущая неделя.
            _spk_daily_excel_write_period(
                ws,
                excel_row,
                17,
                item.get("week"),
            )

            # W:AB — прошедшая смена.
            _spk_daily_excel_write_period(
                ws,
                excel_row,
                23,
                item.get("shift"),
            )

        tmp = tempfile.NamedTemporaryFile(
            prefix="statv2_spk_daily_",
            suffix=".xlsx",
            delete=False,
        )

        output_path = Path(
            tmp.name
        )

        tmp.close()

        wb.save(output_path)
        wb.close()

    except ValueError as exc:
        return error(
            str(exc),
            400,
        )

    except Exception as exc:
        return error(
            str(exc),
            500,
        )

    export_stamp = (
        datetime.now().strftime(
            "%d.%m.%Y %H.%M.%S"
        )
    )

    safe_object_name = (
        object_name
        .replace("/", "-")
        .replace("\\", "-")
    )

    filename = (
        "SPK_everyday_"
        + safe_object_name
        + "_"
        + export_stamp
        + ".xlsx"
    )

    @after_this_request
    def cleanup_spk_daily_excel(
        response
    ):
        try:
            output_path.unlink(
                missing_ok=True
            )
        except Exception:
            pass

        return response

    return send_file(
        output_path,
        as_attachment=True,
        download_name=filename,
        mimetype=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        max_age=0,
    )


# SPK DAILY EXCEL AND OBJECT SETTINGS END


# SPK DYNAMIC EXCEL EXPORT START

def _spk_dynamic_empty_row():
    # Порядок совпадает с фронтендом.
    return [
        0,      # welded
        0,      # controlled
        None,   # lnkBacklog
        None,   # repairBacklog
        0,      # cutNoOf
        0,      # repairNoOf
        None,   # allRejectRate
        0,      # cutOf
        0,      # repairOf
        None,   # ofRejectRate
    ]


def _spk_dynamic_normalize_stats(
    values,
):
    result = _spk_dynamic_empty_row()

    if not isinstance(values, list):
        return result

    for index in range(
        min(10, len(values))
    ):
        result[index] = values[index]

    return result


def _spk_dynamic_write_stats(
    ws,
    column,
    start_row,
    values,
):
    """
    10 строк показателей:

    0 сварено
    1 проконтролировано
    2 отставание ЛНК
    3 остаток ремонтов
    4 вырез НЕОФ
    5 ремонт НЕОФ
    6 уровень брака НЕОФ
    7 вырез ОФ
    8 ремонт ОФ
    9 уровень брака ОФ
    """

    values = (
        _spk_dynamic_normalize_stats(
            values
        )
    )

    count_offsets = {
        0, 1, 4, 5, 7, 8
    }

    backlog_offsets = {
        2, 3
    }

    rate_offsets = {
        6, 9
    }

    for offset in range(10):

        cell = ws.cell(
            start_row + offset,
            column,
        )

        value = values[offset]

        if offset in count_offsets:

            cell.value = (
                _spk_excel_int(value)
            )

        elif offset in backlog_offsets:

            if (
                value is None
                or str(value).strip()
                in {"", "—", "-"}
            ):
                cell.value = "—"

            else:
                cell.value = (
                    _spk_excel_int(value)
                )

        elif offset in rate_offsets:

            if (
                value is None
                or str(value).strip()
                in {"", "—", "-"}
            ):
                cell.value = "—"

            else:
                try:
                    cell.value = (
                        float(value) / 100.0
                    )

                    cell.number_format = (
                        "0.0%"
                    )

                except Exception:
                    cell.value = "—"


def _spk_dynamic_decode_items(
    raw_items,
):
    """
    Один период:

    [
        key,
        shop[10],
        field[10],
        total[10]
    ]
    """

    result = []

    if not isinstance(
        raw_items,
        list,
    ):
        return result

    for raw in raw_items:

        if (
            not isinstance(raw, list)
            or len(raw) < 4
        ):
            continue

        key = str(
            raw[0] or ""
        ).strip()

        if not key:
            continue

        result.append({
            "key": key,

            "shop":
                _spk_dynamic_normalize_stats(
                    raw[1]
                ),

            "field":
                _spk_dynamic_normalize_stats(
                    raw[2]
                ),

            "total":
                _spk_dynamic_normalize_stats(
                    raw[3]
                ),
        })

    result.sort(
        key=lambda item: item["key"]
    )

    return result


def _spk_dynamic_completed_items(
    section,
):
    """
    Frontend по-прежнему передаёт special_key,
    но теперь это НЕ отдельный столбец.

    Это просто крайний разрешённый период:

      день   -> позавчера;
      КН     -> предыдущая завершённая КН;
      месяц  -> предыдущий завершённый месяц.

    Сам период выводится обычным столбцом
    с нормальным названием.
    """

    items = (
        _spk_dynamic_decode_items(
            section.get("items")
        )
    )

    cutoff = str(
        section.get("special_key")
        or ""
    ).strip()

    if cutoff:
        items = [
            item
            for item in items
            if item["key"] <= cutoff
        ]

    return items


def _spk_dynamic_fill_common(
    ws,
    obj,
):
    daily_cfg = obj.get(
        "daily_spk"
    )

    if not isinstance(
        daily_cfg,
        dict,
    ):
        daily_cfg = {}

    object_name = str(
        obj.get("name")
        or SPK_DEFAULT_OBJECT_NAME
    ).strip()

    organization = str(
        daily_cfg.get("organization")
        or ""
    ).strip()

    allowed = daily_cfg.get(
        "allowed_reject_rate"
    )

    # № объекта
    ws["A3"] = int(
        obj.get("number")
        or 1
    )

    # Организация
    ws["B3"] = organization

    # Объект
    ws["C3"] = object_name

    for address in (
        "E3",
        "E13",
        "E23",
    ):
        cell = ws[address]

        if allowed is None:
            cell.value = "—"

        else:
            cell.value = (
                float(allowed) / 100.0
            )

            cell.number_format = "0.0%"


def _spk_dynamic_write_period_rows(
    ws,
    column,
    item,
):
    if not isinstance(
        item,
        dict,
    ):
        item = {}

    _spk_dynamic_write_stats(
        ws,
        column,
        3,
        item.get("shop"),
    )

    _spk_dynamic_write_stats(
        ws,
        column,
        13,
        item.get("field"),
    )

    _spk_dynamic_write_stats(
        ws,
        column,
        23,
        item.get("total"),
    )


def _spk_dynamic_capture_column_styles(
    ws,
    column,
):
    from copy import copy

    return {
        row: copy(
            ws.cell(
                row,
                column,
            )._style
        )
        for row in range(1, 33)
    }


def _spk_dynamic_prepare_columns(
    ws,
    count,
    mode,
):
    """
    Убираем демонстрационные столбцы J:...
    из шаблона и создаём реальное количество
    периодов.

    Столбец I и новые формулы накопительной
    остаются нетронутыми.
    """

    from copy import copy
    from openpyxl.utils import (
        get_column_letter,
    )

    first_col = 10  # J

    if mode == "day":

        # В новом шаблоне:
        #
        # J = начало КН
        # K = обычный день внутри КН
        # P = конец КН
        #
        # В качестве базового оформления
        # используем обычный внутренний день.
        style_col = (
            11
            if ws.max_column >= 11
            else 10
        )

    else:
        style_col = 10

    styles = (
        _spk_dynamic_capture_column_styles(
            ws,
            style_col,
        )
    )

    width = (
        ws.column_dimensions[
            get_column_letter(style_col)
        ].width
        or 11
    )

    # Убираем КН-объединения демонстрационного
    # блока нового шаблона.
    for merged in list(
        ws.merged_cells.ranges
    ):
        if merged.min_col >= first_col:
            ws.unmerge_cells(
                str(merged)
            )

    # Удаляем все демонстрационные периоды.
    delete_count = max(
        0,
        ws.max_column - first_col + 1,
    )

    if delete_count:
        ws.delete_cols(
            first_col,
            delete_count,
        )

    # Создаём нужное число периодов.
    for index in range(count):

        col = first_col + index

        letter = get_column_letter(
            col
        )

        ws.column_dimensions[
            letter
        ].width = width

        for row in range(1, 33):

            ws.cell(
                row,
                col,
            )._style = copy(
                styles[row]
            )

    return first_col


def _spk_dynamic_calendar_week_info(day):
    """
    Календарная КН для СПК.

    Неделя: понедельник-воскресенье.

    Неделя, содержащая 1 января,
    считается КН1 НОВОГО года,
    даже если её понедельник находится
    ещё в декабре предыдущего года.

    Примеры:

      28.12.2020 - 03.01.2021 -> КН1 2021
      27.12.2021 - 02.01.2022 -> КН1 2022
      30.12.2024 - 05.01.2025 -> КН1 2025
    """

    from datetime import date, timedelta

    monday = (
        day
        - timedelta(
            days=day.weekday()
        )
    )

    sunday = (
        monday
        + timedelta(days=6)
    )

    # Если неделя пересекает Новый год,
    # она относится уже к новому году.
    if monday.year != sunday.year:
        week_year = sunday.year

    else:
        week_year = day.year

    jan1 = date(
        week_year,
        1,
        1,
    )

    # Понедельник недели,
    # содержащей 1 января.
    first_monday = (
        jan1
        - timedelta(
            days=jan1.weekday()
        )
    )

    week_number = (
        (
            monday
            - first_monday
        ).days
        // 7
        + 1
    )

    return (
        week_year,
        week_number,
    )


def _spk_dynamic_apply_day_borders(
    ws,
    first_col,
    parsed_dates,
):
    """
    В дневном листе:

      внутри КН        -> тонкая вертикальная граница
      между разными КН -> толстая вертикальная граница

    Строку 2 здесь специально не трогаем:
    для объединённых заголовков КН она
    оформляется отдельно ПОСЛЕ определения
    диапазона недели.
    """

    from copy import copy
    from openpyxl.styles import Side

    if not parsed_dates:
        return

    thin = Side(
        style="thin",
        color="000000",
    )

    medium = Side(
        style="medium",
        color="000000",
    )

    rows = [
        1,
        *range(3, 33),
    ]

    for index, day in enumerate(
        parsed_dates
    ):

        col = (
            first_col
            + index
        )

        current_week = (
            _spk_dynamic_calendar_week_info(
                day
            )
        )

        previous_week = None
        next_week = None

        if index > 0:

            previous_week = (
                _spk_dynamic_calendar_week_info(
                    parsed_dates[
                        index - 1
                    ]
                )
            )

        if (
            index + 1
            < len(parsed_dates)
        ):

            next_week = (
                _spk_dynamic_calendar_week_info(
                    parsed_dates[
                        index + 1
                    ]
                )
            )

        week_start = (
            previous_week
            != current_week
        )

        week_end = (
            next_week
            != current_week
        )

        for row in rows:

            cell = ws.cell(
                row,
                col,
            )

            border = copy(
                cell.border
            )

            border.left = (
                medium
                if week_start
                else thin
            )

            border.right = (
                medium
                if week_end
                else thin
            )

            cell.border = border


def _spk_dynamic_fill_days(
    ws,
    obj,
    section,
):
    from copy import copy
    from datetime import datetime

    from openpyxl.styles import Side
    from openpyxl.utils import (
        get_column_letter,
    )

    # Сохраняем ОРИГИНАЛЬНОЕ оформление
    # строки КН из шаблона ДО удаления
    # демонстрационных столбцов.
    #
    # J2 в исходнике:
    #   RGB(217,225,242)
    #   жирный
    #   по центру
    #   с толстой рамкой.
    week_fill = copy(
        ws["J2"].fill
    )

    week_font = copy(
        ws["J2"].font
    )

    week_alignment = copy(
        ws["J2"].alignment
    )

    items = (
        _spk_dynamic_completed_items(
            section
        )
    )

    if len(items) > 16375:

        raise ValueError(
            "Слишком много дневных "
            "колонок для Excel"
        )

    first_col = (
        _spk_dynamic_prepare_columns(
            ws,
            len(items),
            "day",
        )
    )

    _spk_dynamic_fill_common(
        ws,
        obj,
    )

    parsed_dates = []

    for index, item in enumerate(
        items
    ):

        col = (
            first_col
            + index
        )

        day = datetime.strptime(
            item["key"],
            "%Y-%m-%d",
        ).date()

        parsed_dates.append(
            day
        )

        ws.cell(
            1,
            col,
        ).value = day

        ws.cell(
            1,
            col,
        ).number_format = (
            "dd.mm.yyyy"
        )

        _spk_dynamic_write_period_rows(
            ws,
            col,
            item,
        )

    # Вертикальные границы
    # в таблице по фактическим КН.
    _spk_dynamic_apply_day_borders(
        ws,
        first_col,
        parsed_dates,
    )

    # ========================================================
    # Строка 2 — объединённые заголовки КН.
    #
    # Оформление берём из исходного J2:
    #   - голубая заливка;
    #   - жирный шрифт;
    #   - центрирование.
    #
    # По внешнему контуру каждой КН
    # ставим medium-границу.
    # ========================================================

    medium = Side(
        style="medium",
        color="000000",
    )

    empty_side = Side(
        style=None,
    )

    index = 0

    while index < len(
        parsed_dates
    ):

        week_year, week_number = (
            _spk_dynamic_calendar_week_info(
                parsed_dates[index]
            )
        )

        current_week = (
            week_year,
            week_number,
        )

        end = index

        while (
            end + 1
            < len(parsed_dates)
        ):

            next_week = (
                _spk_dynamic_calendar_week_info(
                    parsed_dates[
                        end + 1
                    ]
                )
            )

            if (
                next_week
                != current_week
            ):
                break

            end += 1

        start_col = (
            first_col
            + index
        )

        end_col = (
            first_col
            + end
        )

        # ВАЖНО:
        # стилизуем ВСЕ ячейки диапазона
        # ДО merge_cells.
        #
        # Так openpyxl подхватит в том числе
        # правую толстую границу последней
        # ячейки при объединении.
        for col in range(
            start_col,
            end_col + 1,
        ):

            cell = ws.cell(
                2,
                col,
            )

            cell.fill = copy(
                week_fill
            )

            cell.font = copy(
                week_font
            )

            cell.alignment = copy(
                week_alignment
            )

            border = copy(
                cell.border
            )

            border.top = medium
            border.bottom = medium

            border.left = (
                medium
                if col == start_col
                else empty_side
            )

            border.right = (
                medium
                if col == end_col
                else empty_side
            )

            cell.border = border

        if end_col > start_col:

            ws.merge_cells(
                start_row=2,
                start_column=start_col,
                end_row=2,
                end_column=end_col,
            )

        header_cell = ws.cell(
            2,
            start_col,
        )

        header_cell.value = (
            f"КН{week_number}"
        )

        # На всякий случай ещё раз
        # фиксируем оформление top-left
        # уже после merge.
        header_cell.fill = copy(
            week_fill
        )

        header_cell.font = copy(
            week_font
        )

        header_cell.alignment = copy(
            week_alignment
        )

        index = (
            end + 1
        )

    if items:

        last_col = (
            first_col
            + len(items)
            - 1
        )

        ws.print_area = (
            f"A1:"
            f"{get_column_letter(last_col)}32"
        )

    else:

        ws.print_area = "A1:I32"


def _spk_dynamic_fill_weeks(
    ws,
    obj,
    section,
):
    from openpyxl.utils import (
        get_column_letter,
    )

    items = (
        _spk_dynamic_completed_items(
            section
        )
    )

    if len(items) > 16375:
        raise ValueError(
            "Слишком много колонок КН"
        )

    first_col = (
        _spk_dynamic_prepare_columns(
            ws,
            len(items),
            "week",
        )
    )

    _spk_dynamic_fill_common(
        ws,
        obj,
    )

    for index, item in enumerate(items):

        col = first_col + index

        try:

            year, week = (
                item["key"]
                .split("-W")
            )

            year_number = int(
                year
            )

            week_number = int(
                week
            )

        except Exception:

            raise ValueError(
                "Некорректный ключ КН: "
                +item["key"]
            )

        ws.cell(
            1,
            col,
        ).value = week_number

        ws.cell(
            2,
            col,
        ).value = (
            f"КН {year_number}"
        )

        _spk_dynamic_write_period_rows(
            ws,
            col,
            item,
        )

    if items:

        last_col = (
            first_col
            +len(items)
            -1
        )

        ws.print_area = (
            f"A1:"
            f"{get_column_letter(last_col)}32"
        )

    else:
        ws.print_area = "A1:I32"


def _spk_dynamic_fill_months(
    ws,
    obj,
    section,
):
    from openpyxl.utils import (
        get_column_letter,
    )

    months = [
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь",
    ]

    items = (
        _spk_dynamic_completed_items(
            section
        )
    )

    if len(items) > 16375:
        raise ValueError(
            "Слишком много месячных "
            "колонок"
        )

    first_col = (
        _spk_dynamic_prepare_columns(
            ws,
            len(items),
            "month",
        )
    )

    _spk_dynamic_fill_common(
        ws,
        obj,
    )

    for index, item in enumerate(items):

        col = first_col + index

        try:

            year, month = (
                item["key"]
                .split("-")
            )

            year_number = int(
                year
            )

            month_number = int(
                month
            )

            month_name = (
                months[
                    month_number - 1
                ]
            )

        except Exception:

            raise ValueError(
                "Некорректный месяц: "
                +item["key"]
            )

        ws.cell(
            1,
            col,
        ).value = month_name

        ws.cell(
            2,
            col,
        ).value = year_number

        _spk_dynamic_write_period_rows(
            ws,
            col,
            item,
        )

    if items:

        last_col = (
            first_col
            +len(items)
            -1
        )

        ws.print_area = (
            f"A1:"
            f"{get_column_letter(last_col)}32"
        )

    else:
        ws.print_area = "A1:I32"


@APP.post("/api/export_spk_dynamic_excel")
def export_spk_dynamic_excel():
    if str(
        session.get("role") or ""
    ) != "admin":
        return error(
            "Нет доступа",
            401,
        )

    if (
        str(
            session.get(
                "account_filter_value"
            )
            or ""
        ).strip()
        or str(
            session.get("org_filter")
            or ""
        ).strip()
    ):
        return error(
            "Выгрузка динамики доступна "
            "только полной админской учётке",
            403,
        )

    payload = (
        request.get_json(silent=True)
        or {}
    )

    object_id = str(
        payload.get("object_id")
        or SPK_DEFAULT_OBJECT_ID
    ).strip()

    obj = statv2_get_spk_object(
        object_id
    )

    if not isinstance(obj, dict):
        return error(
            "Объект не найден",
            404,
        )

    periods = payload.get(
        "periods"
    )

    if not isinstance(
        periods,
        dict,
    ):
        return error(
            "Некорректные данные динамики",
            400,
        )

    if not SPK_DYNAMIC_EXCEL_TEMPLATE.exists():
        return error(
            "Не найден шаблон Excel: "
            f"{SPK_DYNAMIC_EXCEL_TEMPLATE}",
            500,
        )

    try:
        wb = load_workbook(
            SPK_DYNAMIC_EXCEL_TEMPLATE
        )

        required = [
            "СПК по дням",
            "СПК по КН",
            "СПК по месяцам",
        ]

        for sheet_name in required:
            if sheet_name not in wb.sheetnames:
                raise ValueError(
                    "В шаблоне нет листа: "
                    + sheet_name
                )

        _spk_dynamic_fill_days(
            wb["СПК по дням"],
            obj,
            periods.get("day") or {},
        )

        _spk_dynamic_fill_weeks(
            wb["СПК по КН"],
            obj,
            periods.get("week") or {},
        )

        _spk_dynamic_fill_months(
            wb["СПК по месяцам"],
            obj,
            periods.get("month") or {},
        )

    except SyntaxError:
        raise

    except Exception as exc:
        try:
            wb.close()
        except Exception:
            pass

        return error(
            str(exc),
            500,
        )

    # Просим Excel пересчитать формулы I
    # при открытии файла.
    try:
        wb.calculation.calcMode = "auto"
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
    except Exception:
        pass

    import tempfile

    tmp = tempfile.NamedTemporaryFile(
        prefix="statv2_spk_dynamic_",
        suffix=".xlsx",
        delete=False,
    )

    output_path = Path(
        tmp.name
    )

    tmp.close()

    try:
        wb.save(
            output_path
        )
        wb.close()

    except Exception as exc:
        try:
            output_path.unlink(
                missing_ok=True
            )
        except Exception:
            pass

        return error(
            str(exc),
            500,
        )

    export_stamp = (
        datetime.now().strftime(
            "%d.%m.%Y %H.%M.%S"
        )
    )

    object_name = str(
        obj.get("name")
        or SPK_DEFAULT_OBJECT_NAME
    )

    safe_object_name = (
        object_name
        .replace("/", "-")
        .replace("\\", "-")
    )

    filename = (
        "SPK_dinam_"
        + safe_object_name
        + "_"
        + export_stamp
        + ".xlsx"
    )

    @after_this_request
    def cleanup_spk_dynamic_excel(
        response
    ):
        try:
            output_path.unlink(
                missing_ok=True
            )
        except Exception:
            pass

        return response

    return send_file(
        output_path,
        as_attachment=True,
        download_name=filename,
        mimetype=(
            "application/vnd.openxmlformats-"
            "officedocument.spreadsheetml.sheet"
        ),
        max_age=0,
    )


# SPK DYNAMIC EXCEL EXPORT END




@APP.get("/api/welder_access")
@APP.get("/api/welder_access")
def api_welder_access():
    # Доступы сварщика отдаём только авторизованному админу.
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    welder_id = str(request.args.get("welder_id") or "").strip()
    if not welder_id:
        return error("Не указан welder_id", 400)

    try:
        w = None

        try:
            w = _find_auth_welder_by_id(welder_id)
        except Exception:
            w = None

        if not w:
            auth_path = globals().get("PRIVATE_AUTH_PATH", None)
            if not auth_path:
                auth_path = Path("/opt/statv2-auth/auth.json.gz")

            auth_db = read_json_gz(auth_path) if "read_json_gz" in globals() else _read_json_gz(auth_path)

            for item in auth_db.get("welders", []):
                if str(item.get("id") or "") == welder_id:
                    w = item
                    break

        if not w:
            return error("Сварщик не найден", 404)

        org_filter = str(session.get("org_filter") or "").casefold().replace("ё", "е").strip()
        if org_filter:
            org_value = str(w.get("organization") or "").casefold().replace("ё", "е")
            if org_filter not in org_value:
                return error("Нет доступа к этому сварщику", 403)

        return jsonify({
            "ok": True,
            "welder_id": w.get("id", ""),
            "name": w.get("name", ""),
            "login": w.get("login", ""),
            "password_plain": w.get("password_plain", ""),
        })

    except Exception as exc:
        return error(str(exc), 500)



# STATV2_AUDIT_AFTER_REQUEST_V1
@APP.after_request
def statv2_audit_after_request(response):
    try:
        path = request.path or ""

        # Пишем любую попытку входа независимо от того, какая ветка api_login сработала.
        if path == "/api/login" and request.method == "POST":
            data = request.get_json(silent=True) or request.form or {}
            login = str(data.get("login") or "")

            role = str(session.get("role") or "")
            ok = 200 <= int(response.status_code) < 400

            event = "login_success" if ok else "login_failed"

            extra = {}
            if session.get("welder_id"):
                extra["welder_id"] = session.get("welder_id", "")
            if session.get("org_filter"):
                extra["org_filter"] = session.get("org_filter", "")
                extra["org_title"] = session.get("org_title", "")

            # Не пишем пароль. Никогда. Даже под дулом Excel.
            audit_event(event, login=login, role=role, ok=ok, extra=extra)

        # Пишем восстановление сессии при открытии сайта.
        elif path == "/api/session" and request.method == "GET":
            role = str(session.get("role") or "")
            if role:
                extra = {}
                if session.get("welder_id"):
                    extra["welder_id"] = session.get("welder_id", "")
                if session.get("org_filter"):
                    extra["org_filter"] = session.get("org_filter", "")
                    extra["org_title"] = session.get("org_title", "")

                audit_event(
                    "session_restore",
                    login=str(session.get("login") or ""),
                    role=role,
                    ok=True,
                    extra=extra,
                )

    except Exception:
        pass

    return response



# ---------------- Stat admin cabinet ----------------

def statv2_int_nonnegative(value):
    try:
        return max(0, int(float(value or 0)))
    except Exception:
        return 0


def statv2_normalize_spk_backlog_record(record):
    record = record if isinstance(record, dict) else {}
    repair_s = statv2_int_nonnegative(record.get("repair_backlog_S"))
    lnk_s = statv2_int_nonnegative(record.get("lnk_backlog_S"))
    repair_nos = statv2_int_nonnegative(record.get("repair_backlog_NoS"))
    lnk_nos = statv2_int_nonnegative(record.get("lnk_backlog_NoS"))
    repair_has_split = "repair_backlog_S" in record or "repair_backlog_NoS" in record
    lnk_has_split = "lnk_backlog_S" in record or "lnk_backlog_NoS" in record
    return {
        "repair_backlog_S": repair_s,
        "lnk_backlog_S": lnk_s,
        "repair_backlog_NoS": repair_nos,
        "lnk_backlog_NoS": lnk_nos,
        "repair_backlog": repair_s + repair_nos if repair_has_split else statv2_int_nonnegative(record.get("repair_backlog")),
        "lnk_backlog": lnk_s + lnk_nos if lnk_has_split else statv2_int_nonnegative(record.get("lnk_backlog")),
    }


def statv2_read_spk_backlog_history():
    try:
        if SPK_BACKLOG_HISTORY_PATH.exists():
            data = json.loads(SPK_BACKLOG_HISTORY_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {
                    str(day)[:10]: statv2_normalize_spk_backlog_record(record)
                    for day, record in data.items()
                    if isinstance(record, dict)
                }
    except Exception:
        pass
    return {}


def statv2_write_spk_backlog_history(history):
    SPK_BACKLOG_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    normalized = {
        str(day)[:10]: statv2_normalize_spk_backlog_record(record)
        for day, record in sorted((history or {}).items())
        if isinstance(record, dict)
    }
    temp_path = SPK_BACKLOG_HISTORY_PATH.with_suffix(".tmp")
    temp_path.write_text(
        json.dumps(normalized, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temp_path.replace(SPK_BACKLOG_HISTORY_PATH)
    try:
        SPK_BACKLOG_HISTORY_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_merge_spk_backlog_snapshot(snapshot):
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    snapshot_date = str(snapshot.get("date") or "")[:10]
    try:
        datetime.strptime(snapshot_date, "%Y-%m-%d")
    except Exception as exc:
        raise ValueError("В снимке СПК указана некорректная дата") from exc

    history = statv2_read_spk_backlog_history()
    history[snapshot_date] = statv2_normalize_spk_backlog_record(snapshot)
    statv2_write_spk_backlog_history(history)
    return snapshot_date


def statv2_read_dynamic_org_accounts():
    try:
        if DYNAMIC_ORG_ACCOUNTS_PATH.exists():
            return json.loads(DYNAMIC_ORG_ACCOUNTS_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def statv2_write_dynamic_org_accounts(data):
    DYNAMIC_ORG_ACCOUNTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    DYNAMIC_ORG_ACCOUNTS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        DYNAMIC_ORG_ACCOUNTS_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_read_spk_contractors():
    try:
        if SPK_CONTRACTORS_PATH.exists():
            data = json.loads(SPK_CONTRACTORS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data = data.get("contractors", [])
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
    except Exception:
        pass
    return []


def statv2_write_spk_contractors(items):
    SPK_CONTRACTORS_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "contractors": items}
    temp_path = SPK_CONTRACTORS_PATH.with_suffix(".tmp")
    temp_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp_path.replace(SPK_CONTRACTORS_PATH)
    try:
        SPK_CONTRACTORS_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_find_spk_contractor_by_account(login):
    login_key = str(login or "").strip().upper()
    if not login_key:
        return None
    for item in statv2_read_spk_contractors():
        if str(item.get("account_login") or "").strip().upper() == login_key:
            return item
    return None


def statv2_public_spk_contractor(item):
    return {
        "id": str(item.get("id") or ""),
        "object_name": str(item.get("object_name") or ""),
        "subcontractor": str(item.get("subcontractor") or ""),
        "allowed_reject_rate": item.get("allowed_reject_rate", 0),
        "brigadier_filter": str(item.get("brigadier_filter") or ""),
        "account_login": str(item.get("account_login") or ""),
    }


def statv2_all_org_accounts():
    result = {}

    try:
        for login, cfg in ORG_ADMIN_ACCOUNTS.items():
            result[str(login).strip().upper()] = {
                "password": cfg.get("password", ""),
                "filter_type": "organization",
                "filter_value": cfg.get("org_filter", ""),
                "title": cfg.get("title") or cfg.get("org_filter", ""),
                "builtin": True,
            }
    except Exception:
        pass

    for login, cfg in statv2_read_dynamic_org_accounts().items():
        result[str(login).strip().upper()] = {
            "password": cfg.get("password", ""),
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title") or cfg.get("filter_value", ""),
            "builtin": False,
        }

    return result


@APP.before_request
def statv2_stat_admin_login_hook():
    if request.path != "/api/login" or request.method != "POST":
        return None

    data = request.get_json(silent=True) or request.form or {}
    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "")

    if not login or not password:
        return None

    if hmac.compare_digest(login.encode("utf-8"), STAT_ADMIN_LOGIN.encode("utf-8")) and hmac.compare_digest(password.encode("utf-8"), STAT_ADMIN_PASS.encode("utf-8")):
        session.clear()
        session["role"] = "stat_admin"
        session["login"] = STAT_ADMIN_LOGIN
        return jsonify({
            "ok": True,
            "role": "stat_admin",
            "meta": safe_public_meta() if "safe_public_meta" in globals() else {},
        })

    cfg = statv2_all_org_accounts().get(login.strip().upper())
    if cfg and hmac.compare_digest(password, str(cfg.get("password") or "")):
        session.clear()
        session["role"] = "admin"
        session["login"] = login.strip()
        session["account_filter_type"] = cfg.get("filter_type", "organization")
        session["account_filter_value"] = cfg.get("filter_value", "")
        session["account_filter_title"] = cfg.get("title", cfg.get("filter_value", ""))

        contractor = statv2_find_spk_contractor_by_account(login)
        if contractor:
            session["spk_contractor_id"] = str(contractor.get("id") or "")

        # Совместимость со старой логикой НГТС/НОВА/ГАЛА/ССПИ.
        if cfg.get("filter_type", "organization") == "organization":
            session["org_filter"] = cfg.get("filter_value", "")
            session["org_title"] = cfg.get("title", cfg.get("filter_value", ""))

        return jsonify({
            "ok": True,
            "role": "admin",
            "account_filter_type": session.get("account_filter_type", ""),
            "account_filter_value": session.get("account_filter_value", ""),
            "account_filter_title": session.get("account_filter_title", ""),
            "org_filter": session.get("org_filter", ""),
            "org_title": session.get("org_title", ""),
            "spk_contractor_id": session.get("spk_contractor_id", ""),
            "meta": safe_public_meta() if "safe_public_meta" in globals() else {},
        })

    return None


@APP.after_request
def statv2_add_filter_fields_to_session_response(response):
    try:
        if request.path == "/api/session" and response.is_json:
            data = response.get_json(silent=True)
            if isinstance(data, dict) and data.get("authenticated"):
                if session.get("account_filter_type"):
                    data["account_filter_type"] = session.get("account_filter_type", "")
                    data["account_filter_value"] = session.get("account_filter_value", "")
                    data["account_filter_title"] = session.get("account_filter_title", "")
                if session.get("org_filter"):
                    data["org_filter"] = session.get("org_filter", "")
                    data["org_title"] = session.get("org_title", "")

                contractor = statv2_find_spk_contractor_by_account(
                    session.get("login", "")
                )
                if contractor:
                    contractor_id = str(contractor.get("id") or "")
                    session["spk_contractor_id"] = contractor_id
                    data["spk_contractor_id"] = contractor_id
                else:
                    session.pop("spk_contractor_id", None)
                    data["spk_contractor_id"] = ""

                response.set_data(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
                response.headers["Content-Type"] = "application/json; charset=utf-8"
    except Exception:
        pass
    return response


def statv2_require_stat_admin():
    return str(session.get("role") or "") == "stat_admin"


def statv2_audit_status_ru(event, ok):
    if event == "login_success" and ok:
        return "Вход на сайт"
    if event == "org_admin_login_success" and ok:
        return "Вход ограниченной админки"
    if event == "session_restore" and ok:
        return "Восстановление сессии"
    if event == "login_failed":
        return "Неудачный вход"
    if event == "logout":
        return "Выход"
    if event == "export_excel":
        return "Выгрузка Excel"
    if event == "upload_db":
        return "Обновление базы"
    return str(event or "")


def statv2_device_from_ua(ua):
    ua = str(ua or "")
    low = ua.lower()
    if "iphone" in low:
        return "iPhone"
    if "android" in low:
        return "Android"
    if "windows" in low:
        return "Windows"
    if "mac os" in low or "macintosh" in low:
        return "Mac"
    if "linux" in low:
        return "Linux"
    return ua[:80]


def statv2_format_ts(ts):
    raw = str(ts or "")
    try:
        d = datetime.fromisoformat(raw)
        return d.strftime("%d.%m.%Y %H.%M.%S")
    except Exception:
        return raw.replace("T", " ")

@APP.route('/api/stat_admin/audit_stats', methods=['GET'])
def statv2_audit_stats():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)
    from datetime import datetime, timezone, timedelta
    try:
        filter_hours = int(request.args.get("hours") or 0)
    except Exception:
        filter_hours = 0
    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))
    all_records = []
    cutoff_str = ""
    if filter_hours:
        from datetime import datetime, timezone, timedelta
        cutoff_str = (datetime.now(timezone.utc) - timedelta(hours=filter_hours)).strftime("%Y-%m-%dT%H:%M:%S")
    if log_path.exists():
        lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for line in lines:
            try:
                r = json.loads(line)
                if r.get("ok") and r.get("login"):
                    if cutoff_str and r.get("ts","") < cutoff_str:
                        continue
                    all_records.append(r)
            except Exception:
                continue

    now = datetime.now(timezone.utc)

    def count_since(hours):
        cutoff = now - timedelta(hours=hours)
        count = 0
        for r in all_records:
            try:
                ts = r.get("ts","")
                if ts:
                    dt = datetime.fromisoformat(ts.replace('Z','+00:00'))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt >= cutoff:
                        count += 1
            except Exception:
                pass
        return count

    # Топ логинов — от отфильтрованных записей
    from collections import Counter
    login_counts = Counter(r.get("login","") for r in all_records if r.get("login"))
    top_logins = [{"login": l, "count": c} for l, c in login_counts.most_common(10)]

    # Периоды — всегда от ВСЕХ записей
    all_records_full = []
    if log_path.exists():
        lines2 = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for line in lines2:
            try:
                r = json.loads(line)
                if r.get("ok") and r.get("login"):
                    all_records_full.append(r)
            except Exception:
                continue
    def count_since_full(hours):
        cutoff = now - timedelta(hours=hours)
        count = 0
        for r in all_records_full:
            try:
                ts = r.get("ts","")
                if ts:
                    dt = datetime.fromisoformat(ts.replace("Z","+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt >= cutoff:
                        count += 1
            except Exception:
                pass
        return count

    # Периоды
    periods = [
        {"label": "3 часа", "hours": 3, "count": count_since_full(3)},
        {"label": "6 часов", "hours": 6, "count": count_since_full(6)},
        {"label": "12 часов", "hours": 12, "count": count_since_full(12)},
        {"label": "24 часа", "hours": 24, "count": count_since_full(24)},
        {"label": "48 часов", "hours": 48, "count": count_since_full(48)},
        {"label": "Неделя", "hours": 168, "count": count_since_full(168)},
        {"label": "Месяц", "hours": 720, "count": count_since_full(720)},
        {"label": "Всё время", "hours": 0, "count": len(all_records_full)},
    ]

    return jsonify({
        "ok": True,
        "total": len(all_records),
        "top_logins": top_logins,
        "periods": periods,
    })

@APP.route("/api/stat_admin/audit", methods=["GET"])
def statv2_stat_admin_audit():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    try:
        limit = int(request.args.get("limit") or 50)
    except Exception:
        limit = 50

    try:
        page = int(request.args.get("page") or 1)
    except Exception:
        page = 1

    limit = max(1, min(limit, 200))
    since_str = request.args.get("since", "")
    page = max(1, page)

    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))

    all_records = []

    if log_path.exists():
        lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()

        # Новые записи сверху.
        for line in reversed(lines):
            try:
                r = json.loads(line)
            except Exception:
                continue

            ts_val = r.get('ts','')
            if since_str and ts_val and ts_val < since_str:
                continue
            all_records.append({
                "ts": ts_val,
                "date": statv2_format_ts(r.get("ts", "")),
                "ip": r.get("ip", ""),
                "event": r.get("event", ""),
                "status": statv2_audit_status_ru(r.get("event", ""), bool(r.get("ok"))),
                "ok": bool(r.get("ok")),
                "role": r.get("role", ""),
                "login": r.get("login", ""),
                "name": r.get("name", ""),
                "org_filter": r.get("org_filter", ""),
                "device": statv2_device_from_ua(r.get("user_agent", "")),
            })

    total = len(all_records)
    pages = max(1, (total + limit - 1) // limit)
    page = min(page, pages)

    start = (page - 1) * limit
    end = start + limit
    records = all_records[start:end]

    return jsonify({
        "ok": True,
        "records": records,
        "page": page,
        "pages": pages,
        "limit": limit,
        "total": total,
    })

@APP.post("/api/stat_admin/audit/clear")
def statv2_stat_admin_audit_clear():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("", encoding="utf-8")

    return jsonify({"ok": True, "message": "Лог очищен"})


@APP.get("/api/stat_admin/accounts")
def statv2_stat_admin_accounts():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    rows = []
    for login, cfg in sorted(statv2_all_org_accounts().items()):
        rows.append({
            "login": login,
            "password": cfg.get("password", ""),
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title", ""),
            "builtin": bool(cfg.get("builtin")),
        })

    return jsonify({"ok": True, "accounts": rows})

@APP.post("/api/stat_admin/accounts")
def statv2_stat_admin_create_account():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}

    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "").strip()
    filter_type = str(data.get("filter_type") or "organization").strip()
    filter_value = str(data.get("filter_value") or "").strip()
    title = str(data.get("title") or filter_value).strip()

    allowed_filters = {
        "organization",
        "responsible",
        "shift",
        "position",
        "status",
    }

    if not login:
        return error("Введите логин", 400)
    if not password:
        return error("Введите пароль", 400)
    if filter_type not in allowed_filters:
        return error("Неизвестный фильтр", 400)
    if not filter_value:
        return error("Введите значение фильтра", 400)

    key = login.upper()

    builtin = statv2_all_org_accounts().get(key, {}).get("builtin")
    if builtin:
        return error("Такой логин занят встроенной учёткой", 400)

    data_all = statv2_read_dynamic_org_accounts()
    data_all[key] = {
        "password": password,
        "filter_type": filter_type,
        "filter_value": filter_value,
        "title": title or filter_value,
    }
    statv2_write_dynamic_org_accounts(data_all)

    return jsonify({
        "ok": True,
        "message": "Учётка создана",
        "account": {
            "login": key,
            "password": password,
            "filter_type": filter_type,
            "filter_value": filter_value,
            "title": title or filter_value,
        }
    })


@APP.post("/api/stat_admin/accounts/delete")
def statv2_stat_admin_delete_account():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    login = str(data.get("login") or "").strip().upper()

    if not login:
        return error("Не указан логин", 400)

    account = statv2_all_org_accounts().get(login)
    if account and account.get("builtin"):
        return error("Встроенную учётку удалить нельзя", 400)

    linked_contractor = statv2_find_spk_contractor_by_account(login)
    if linked_contractor:
        return error(
            "Учётка привязана к подрядчику. Сначала отвяжите её в разделе Подрядчики",
            400,
        )

    data_all = statv2_read_dynamic_org_accounts()

    if login not in data_all:
        return error("Учётка не найдена", 404)

    data_all.pop(login, None)
    statv2_write_dynamic_org_accounts(data_all)

    return jsonify({"ok": True, "message": "Учётка удалена"})


@APP.get("/api/stat_admin/contractors")
def statv2_stat_admin_contractors():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    contractors = [
        statv2_public_spk_contractor(item)
        for item in statv2_read_spk_contractors()
    ]

    accounts = []
    for login, cfg in sorted(statv2_all_org_accounts().items()):
        accounts.append({
            "login": login,
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title", ""),
            "builtin": bool(cfg.get("builtin")),
        })

    return jsonify({
        "ok": True,
        "contractors": contractors,
        "accounts": accounts,
    })


@APP.post("/api/stat_admin/contractors")
def statv2_stat_admin_save_contractor():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    contractor_id = str(data.get("id") or "").strip()
    object_name = str(data.get("object_name") or "").strip()
    subcontractor = str(data.get("subcontractor") or "").strip()
    brigadier_filter = str(data.get("brigadier_filter") or "").strip()
    account_login = str(data.get("account_login") or "").strip().upper()

    allowed_raw = str(data.get("allowed_reject_rate") or "").strip()
    if not allowed_raw:
        return error("Введите допустимый уровень брака", 400)
    try:
        allowed_reject_rate = float(allowed_raw.replace(",", "."))
    except Exception:
        return error("Допустимый уровень брака должен быть числом", 400)

    if not object_name:
        return error("Введите объект строительства", 400)
    if not subcontractor:
        return error("Введите имя субподрядчика", 400)
    if not brigadier_filter:
        return error("Введите значение фильтра по полю Бригадир", 400)
    if not (0 <= allowed_reject_rate <= 100):
        return error("Допустимый уровень брака должен быть от 0 до 100%", 400)

    accounts = statv2_all_org_accounts()
    if account_login and account_login not in accounts:
        return error("Выбранная ограниченная учётка не найдена", 400)

    items = statv2_read_spk_contractors()

    for item in items:
        item_id = str(item.get("id") or "")
        linked_login = str(item.get("account_login") or "").strip().upper()
        if account_login and linked_login == account_login and item_id != contractor_id:
            return error("Эта учётка уже привязана к другому подрядчику", 400)

    now = datetime.now().isoformat(timespec="seconds")
    saved = None

    if contractor_id:
        for item in items:
            if str(item.get("id") or "") == contractor_id:
                item.update({
                    "object_name": object_name,
                    "subcontractor": subcontractor,
                    "allowed_reject_rate": allowed_reject_rate,
                    "brigadier_filter": brigadier_filter,
                    "account_login": account_login,
                    "updated_at": now,
                })
                saved = item
                break
        if saved is None:
            return error("Подрядчик не найден", 404)
    else:
        saved = {
            "id": secrets.token_hex(8),
            "object_name": object_name,
            "subcontractor": subcontractor,
            "allowed_reject_rate": allowed_reject_rate,
            "brigadier_filter": brigadier_filter,
            "account_login": account_login,
            "created_at": now,
            "updated_at": now,
        }
        items.append(saved)

    statv2_write_spk_contractors(items)

    return jsonify({
        "ok": True,
        "message": "Подрядчик сохранён",
        "contractor": statv2_public_spk_contractor(saved),
    })


@APP.post("/api/stat_admin/contractors/delete")
def statv2_stat_admin_delete_contractor():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    contractor_id = str(data.get("id") or "").strip()
    if not contractor_id:
        return error("Не указан подрядчик", 400)

    items = statv2_read_spk_contractors()
    filtered = [
        item for item in items
        if str(item.get("id") or "") != contractor_id
    ]

    if len(filtered) == len(items):
        return error("Подрядчик не найден", 404)

    statv2_write_spk_contractors(filtered)
    return jsonify({"ok": True, "message": "Подрядчик удалён"})


@APP.get("/api/spk/backlog_history")
def statv2_spk_backlog_history():
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    account_filter_value = str(session.get("account_filter_value") or "").strip()
    org_filter = str(session.get("org_filter") or "").strip()
    if account_filter_value or org_filter:
        return error("История общей ежедневной СПК доступна только полной админской учётке", 403)

    return jsonify({
        "ok": True,
        "history": statv2_read_spk_backlog_history(),
    })


@APP.get("/api/spk/contractors")
def statv2_spk_contractors():
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    items = statv2_read_spk_contractors()
    account_filter_value = str(session.get("account_filter_value") or "").strip()
    org_filter = str(session.get("org_filter") or "").strip()
    full_admin = not account_filter_value and not org_filter

    if full_admin:
        visible = items
        mode = "full"
        contractor_id = ""
    else:
        linked = statv2_find_spk_contractor_by_account(session.get("login", ""))
        visible = [linked] if linked else []
        mode = "linked"
        contractor_id = str(linked.get("id") or "") if linked else ""

    return jsonify({
        "ok": True,
        "mode": mode,
        "contractor_id": contractor_id,
        "contractors": [
            statv2_public_spk_contractor(item)
            for item in visible
            if item
        ],
    })


import json as _json_mod
import os as _os_mod
from datetime import datetime as _dt

SUGG_FILE = '/var/www/statv2/db/suggestions.json'

@APP.route('/api/suggestion', methods=['POST'])
def api_add_suggestion():
    from flask import session, request, jsonify
    if not session.get('role'):
        return jsonify({'error': 'unauthorized'}), 401
    data = request.get_json(force=True)
    name = (data.get('name') or '').strip()
    text = (data.get('text') or '').strip()
    role = (data.get('role') or '').strip()
    if not text:
        return jsonify({'error': 'empty'}), 400
    suggestions = []
    if _os_mod.path.exists(SUGG_FILE):
        try:
            with open(SUGG_FILE, 'r') as f:
                suggestions = _json_mod.load(f)
        except Exception:
            suggestions = []
    suggestions.insert(0, {
        'name': name,
        'text': text,
        'role': role,
        'ts': _dt.now().strftime('%d.%m.%Y %H:%M')
    })
    with open(SUGG_FILE, 'w') as f:
        _json_mod.dump(suggestions, f, ensure_ascii=False, indent=2)
    return jsonify({'ok': True})


@APP.route('/api/suggestion/<int:idx>', methods=['DELETE'])
def api_delete_suggestion(idx):
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    if not _os_mod.path.exists(SUGG_FILE):
        return jsonify({'ok': True})
    try:
        with open(SUGG_FILE, 'r') as f:
            suggestions = _json_mod.load(f)
        if 0 <= idx < len(suggestions):
            suggestions.pop(idx)
        with open(SUGG_FILE, 'w') as f:
            _json_mod.dump(suggestions, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return jsonify({'ok': True})

@APP.route('/api/suggestions', methods=['GET'])
def api_get_suggestions():
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    if not _os_mod.path.exists(SUGG_FILE):
        return jsonify([])
    try:
        with open(SUGG_FILE, 'r') as f:
            return jsonify(_json_mod.load(f))
    except Exception:
        return jsonify([])


OVERRIDES_FILE = '/var/www/statv2/db/overrides.json'

def load_overrides():
    if not _os_mod.path.exists(OVERRIDES_FILE):
        return []
    try:
        with open(OVERRIDES_FILE, 'r') as f:
            return _json_mod.load(f)
    except Exception:
        return []

def save_overrides(overrides):
    with open(OVERRIDES_FILE, 'w') as f:
        _json_mod.dump(overrides, f, ensure_ascii=False, indent=2)


def update_manifest_timestamp():
    import hashlib as _hashlib, datetime as _datetime
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    manifest_path = site_root / "db" / "manifest.json"
    shards_dir = site_root / "db" / "welders"
    try:
        with open(manifest_path, 'r') as f:
            m = _json_mod.load(f)
        # Обновляем хэши shard файлов
        shard_paths = m.get('shards', [])
        total_size = 0
        combined = b""
        for rel_path in shard_paths:
            fpath = site_root / "db" / rel_path
            if fpath.exists():
                data = fpath.read_bytes()
                total_size += len(data)
                combined += data
        if combined:
            m['files']['shards']['sha256'] = _hashlib.sha256(combined).hexdigest()
            m['files']['shards']['size_bytes'] = total_size
        m['generated_at'] = _datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        m['overrides_ts'] = m['generated_at']
        with open(manifest_path, 'w') as f:
            _json_mod.dump(m, f, ensure_ascii=False)
    except Exception as e:
        pass

def _recalc_welder_stats(welders, joints):
    """Пересчитывает статистику сварщиков на основе стыков"""
    from collections import defaultdict
    # Строим индекс сварщиков по id
    welder_map = {w.get('id',''): w for w in welders}
    # Сбрасываем статистику
    for w in welders:
        for scope in ['primary_all','repairs_all']:
            if scope in w.get('stats',{}):
                s = w['stats'][scope]
                for k in ['total_welded','submitted_control','accepted','rejected','wait','not_required']:
                    s[k] = 0
                s['production'] = 0.0
                s['reject_rate'] = 0.0
    # Пересчитываем
    for joint in joints:
        for action in joint.get('actions', []):
            stage_type = action.get('stage_type','primary')
            scope = 'repairs_all' if stage_type == 'repair' else 'primary_all'
            result = action.get('result','')
            weld_date = action.get('weld_date','')
            inch = joint.get('inch', 0) or 0
            for wid in action.get('welder_ids', []):
                w = welder_map.get(wid)
                if not w:
                    continue
                s = w.setdefault('stats', {}).setdefault(scope, {
                    'total_welded':0,'production':0.0,'submitted_control':0,
                    'accepted':0,'rejected':0,'wait':0,'not_required':0,'reject_rate':0.0
                })
                if weld_date:
                    s['total_welded'] = s.get('total_welded',0) + 1
                    s['production'] = s.get('production',0.0) + float(inch)
                if 'Годен' in result:
                    s['accepted'] = s.get('accepted',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'Не годен' in result:
                    s['rejected'] = s.get('rejected',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'Ожидание' in result:
                    s['wait'] = s.get('wait',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'не требуется' in result.lower():
                    s['not_required'] = s.get('not_required',0) + 1
                sc = s.get('submitted_control',0)
                rj = s.get('rejected',0)
                s['reject_rate'] = rj/sc if sc else 0.0

def apply_overrides_to_shards():
    """Применяет оверрайды ко всем shard файлам после загрузки базы"""
    overrides = load_overrides()
    if not overrides:
        return 0
    import gzip as _gzip
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    shards_dir = site_root / "db" / "welders"
    applied = 0
    for shard_path in sorted(shards_dir.glob("shard_*.json.gz")):
        try:
            with _gzip.open(shard_path, 'rt', encoding='utf-8') as f:
                shard = _json_mod.load(f)
            joints = shard.get('joints', [])
            welders = shard.get('welders', [])
            changed = False
            for joint in joints:
                vik = joint.get('vik_request', '')
                for ov in overrides:
                    if ov.get('vik_request') != vik:
                        continue
                    actions = joint.get('actions', [])
                    stage_index = ov.get('stage_index', 0)
                    for action in actions:
                        if action.get('stage_index') == stage_index:
                            new_name = ov.get('welder_name', '')
                            action['welders_raw'] = new_name
                            action['welder_names'] = [new_name] if new_name else []
                            action['welder_ids'] = []
                            action['unknown_welder_names'] = [new_name] if new_name else []
                            action['unknown_welder_ids'] = []
                            changed = True
                            applied += 1
            if changed:
                _recalc_welder_stats(welders, joints)
                with _gzip.open(shard_path, 'wt', encoding='utf-8') as f:
                    _json_mod.dump(shard, f, ensure_ascii=False)
        except Exception as e:
            continue
    return applied

@APP.route('/api/stat_admin/overrides', methods=['GET'])
def api_get_overrides():
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    return jsonify({'ok': True, 'overrides': load_overrides()})

@APP.route('/api/stat_admin/overrides', methods=['POST'])
def api_add_override():
    from flask import session, request, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    data = request.get_json(force=True)
    vik = (data.get('vik_request') or '').strip()
    welder_name = (data.get('welder_name') or '').strip()
    stage_index = int(data.get('stage_index', 0))
    stage_label = (data.get('stage_label') or '').strip()
    joint_no = (data.get('joint_no') or '').strip()
    iso = (data.get('iso') or '').strip()
    if not vik:
        return jsonify({'error': 'Укажите номер заявки'}), 400
    overrides = load_overrides()
    # Проверим дубль
    for ov in overrides:
        if ov.get('vik_request') == vik and ov.get('stage_index') == stage_index:
            ov['welder_name'] = welder_name
            ov['stage_label'] = stage_label
            ov['joint_no'] = joint_no
            ov['iso'] = iso
            save_overrides(overrides)
            apply_overrides_to_shards()
            update_manifest_timestamp()
            return jsonify({'ok': True, 'updated': True})
    overrides.insert(0, {
        'vik_request': vik,
        'welder_name': welder_name,
        'stage_index': stage_index,
        'stage_label': stage_label,
        'joint_no': joint_no,
        'iso': iso,
        'ts': __import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M')
    })
    save_overrides(overrides)
    apply_overrides_to_shards()
    update_manifest_timestamp()
    return jsonify({'ok': True, 'updated': False})

@APP.route('/api/stat_admin/overrides/<int:idx>', methods=['DELETE'])
def api_delete_override(idx):
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    overrides = load_overrides()
    if 0 <= idx < len(overrides):
        overrides.pop(idx)
        save_overrides(overrides)
    return jsonify({'ok': True})

@APP.route('/api/stat_admin/joint_search', methods=['GET'])
def api_joint_search():
    from flask import session, request, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    vik = (request.args.get('vik_request') or '').strip()
    if not vik:
        return jsonify({'error': 'Укажите номер заявки'}), 400
    import gzip as _gzip
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    shards_dir = site_root / "db" / "welders"
    results = []
    seen_ids = set()
    for shard_path in sorted(shards_dir.glob("shard_*.json.gz")):
        try:
            with _gzip.open(shard_path, 'rt', encoding='utf-8') as f:
                shard = _json_mod.load(f)
            for joint in shard.get('joints', []):
                jid = joint.get('id','')
                if jid in seen_ids:
                    continue
                seen_ids.add(jid)
                if joint.get('vik_request', '') == vik:
                    results.append({
                        'id': joint.get('id',''),
                        'iso': joint.get('iso',''),
                        'joint_no': joint.get('joint_no',''),
                        'vik_request': joint.get('vik_request',''),
                        'actions': [{'stage_index': a.get('stage_index',0), 'stage_label': a.get('stage_label',''), 'repair_no': a.get('repair_no',0), 'welder_names': a.get('welder_names',[]), 'welders_raw': a.get('welders_raw','')} for a in joint.get('actions',[])]
                    })
        except Exception:
            continue
    return jsonify({'ok': True, 'joints': results})

if __name__ == "__main__":
    APP.run(host="127.0.0.1", port=int(os.environ.get("STATV2_UPLOAD_PORT", "5088")))


# ── ID-карты: загрузка ZIP ────────────────────────────────────────────────────

@APP.post("/api/upload_idcards")
def upload_idcards():
    if not authorized():
        return error("Нет доступа", 401)
    file = request.files.get("file")
    if not file or not file.filename:
        return error("Файл не выбран")
    if not file.filename.lower().endswith(".zip"):
        return error("Нужен zip-архив")
    IDCARDS_ROOT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="statv2_idcards_") as tmp_name:
        tmp = Path(tmp_name)
        zip_path = tmp / "upload.zip"
        file.save(zip_path)
        try:
            with zipfile.ZipFile(zip_path) as z:
                names = z.namelist()
                if "manifest.json" not in names:
                    return error("В архиве нет manifest.json")
                manifest_bytes = z.read("manifest.json")
                try:
                    new_manifest = json.loads(manifest_bytes.decode("utf-8"))
                except Exception:
                    return error("manifest.json повреждён")
                pdf_count = 0
                for member in z.infolist():
                    name = member.filename.replace("\\", "/")
                    if not name.lower().endswith(".pdf"):
                        continue
                    parts = Path(name).parts
                    if any(p in ("..", "") for p in parts):
                        continue
                    target = IDCARDS_ROOT / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(z.read(member.filename))
                    try:
                        target.chmod(0o644)
                        target.parent.chmod(0o755)
                    except Exception:
                        pass
                    pdf_count += 1
        except zipfile.BadZipFile:
            return error("Файл повреждён или не является zip-архивом")
        except Exception as exc:
            return error(f"Ошибка распаковки: {exc}", 500)
        merged_manifest = {}
        if IDCARDS_MANIFEST.exists():
            try:
                old = json.loads(IDCARDS_MANIFEST.read_text(encoding="utf-8"))
                merged_manifest.update(old)
            except Exception:
                pass
        merged_manifest.update(new_manifest)
        merged_manifest["__version__"] = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        IDCARDS_MANIFEST.write_text(
            json.dumps(merged_manifest, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        try:
            IDCARDS_MANIFEST.chmod(0o644)
        except Exception:
            pass
    return jsonify({
        "ok": True,
        "pdf_added": pdf_count,
        "welders": len([k for k in merged_manifest if not k.startswith("__")]),
        "version": merged_manifest["__version__"],
    })


# ── ID-карты: манифест ────────────────────────────────────────────────────────

@APP.get("/api/idcards_manifest")
def idcards_manifest():
    if not IDCARDS_MANIFEST.exists():
        return jsonify({"__version__": "0"})
    try:
        data = json.loads(IDCARDS_MANIFEST.read_text(encoding="utf-8"))
        return jsonify(data)
    except Exception:
        return error("Манифест повреждён", 500)


# ── ID-карты: отдача PDF ──────────────────────────────────────────────────────

@APP.get("/api/idcards/<stamp>/<path:filename>")
def idcard_file(stamp, filename):
    safe_stamp = Path(stamp).name
    target = (IDCARDS_ROOT / safe_stamp / filename).resolve()
    if not str(target).startswith(str(IDCARDS_ROOT.resolve())):
        return error("Недопустимый путь", 400)
    if not target.exists() or not target.suffix.lower() == ".pdf":
        return error("Файл не найден", 404)
    return send_file(
        target,
        mimetype="application/pdf",
        as_attachment=False,
        max_age=86400 * 30,
    )


# ── Инженеры по сварке ────────────────────────────────────────────────────────


# WELDER PHOTOS API START

WELDER_PHOTOS_ROOT = Path(
    os.environ.get(
        "STATV2_WELDER_PHOTOS_ROOT",
        "/opt/statv2-auth/welder_photos",
    )
).resolve()

WELDER_PHOTOS_MANIFEST = (
    WELDER_PHOTOS_ROOT
    / "manifest.json"
)

WELDER_PHOTO_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
}


# Первая база фото может быть около 800 МБ.
# Даём Flask запас до 2 ГБ.
APP.config["MAX_CONTENT_LENGTH"] = max(
    int(
        APP.config.get(
            "MAX_CONTENT_LENGTH"
        )
        or 0
    ),
    2 * 1024 * 1024 * 1024,
)


def _welder_photo_upload_allowed():

    role = str(
        session.get("role")
        or ""
    )

    if role in (
        "stat_admin",
        "updater",
    ):
        return True

    # Аварийный старый Basic-доступ
    # admin_update тоже сохраняем.
    return authorized()


def _welder_photo_norm_stamp(
    value
):
    return (
        str(value or "")
        .strip()
        .upper()
    )


def _welder_photo_read_manifest():

    if not WELDER_PHOTOS_MANIFEST.exists():
        return {
            "__version__": "0"
        }

    try:
        data = json.loads(
            WELDER_PHOTOS_MANIFEST
            .read_text(
                encoding="utf-8"
            )
        )

        if isinstance(
            data,
            dict,
        ):
            return data

    except Exception:
        pass

    return {
        "__version__": "0"
    }


def _welder_photo_find_auth_welder_by_stamp(
    stamp
):

    wanted = (
        _welder_photo_norm_stamp(
            stamp
        )
    )

    if not wanted:
        return None

    try:
        auth_db = (
            load_private_auth()
        )

    except Exception:
        return None

    for item in (
        auth_db.get(
            "welders",
            [],
        )
    ):

        if (
            _welder_photo_norm_stamp(
                item.get("stamp")
            )
            == wanted
        ):
            return item

    return None


def _welder_photo_request_allowed(
    stamp
):

    role = str(
        session.get("role")
        or ""
    )

    if not role:
        return False, None

    welder = (
        _welder_photo_find_auth_welder_by_stamp(
            stamp
        )
    )

    if not welder:
        return False, None

    # Сам сварщик может получить
    # исключительно своё фото.
    if role == "welder":

        allowed = (
            str(
                welder.get("id")
                or ""
            )
            ==
            str(
                session.get(
                    "welder_id"
                )
                or ""
            )
        )

        return (
            allowed,
            welder,
        )

    # Администратор может получать
    # только доступных ему сварщиков.
    if role == "admin":

        org_filter = (
            str(
                session.get(
                    "org_filter"
                )
                or ""
            )
            .casefold()
            .replace(
                "ё",
                "е",
            )
            .strip()
        )

        if org_filter:

            organization = (
                str(
                    welder.get(
                        "organization"
                    )
                    or ""
                )
                .casefold()
                .replace(
                    "ё",
                    "е",
                )
            )

            if (
                org_filter
                not in organization
            ):
                return (
                    False,
                    welder,
                )

        return (
            True,
            welder,
        )

    # admin_stat нужен для администрирования.
    if role == "stat_admin":
        return (
            True,
            welder,
        )

    return (
        False,
        welder,
    )


@APP.post(
    "/api/upload_welder_photos"
)
def upload_welder_photos():

    if not _welder_photo_upload_allowed():
        return error(
            "Нет доступа",
            401,
        )

    file = request.files.get(
        "file"
    )

    if (
        not file
        or not file.filename
    ):
        return error(
            "Файл не выбран"
        )

    if not (
        file.filename
        .lower()
        .endswith(".zip")
    ):
        return error(
            "Нужен zip-архив"
        )

    WELDER_PHOTOS_ROOT.mkdir(
        parents=True,
        exist_ok=True,
    )

    with tempfile.TemporaryDirectory(
        prefix="statv2_welder_photos_"
    ) as tmp_name:

        tmp = Path(
            tmp_name
        )

        zip_path = (
            tmp
            / "upload.zip"
        )

        #
        # Файл большой.
        # Не читаем архив целиком в RAM.
        #
        file.save(
            zip_path
        )

        try:

            with zipfile.ZipFile(
                zip_path
            ) as archive:

                names = (
                    archive.namelist()
                )

                if (
                    "manifest.json"
                    not in names
                ):
                    return error(
                        "В архиве нет manifest.json"
                    )

                try:

                    uploaded_manifest = (
                        json.loads(
                            archive
                            .read(
                                "manifest.json"
                            )
                            .decode(
                                "utf-8-sig"
                            )
                        )
                    )

                except Exception:
                    return error(
                        "manifest.json повреждён"
                    )

                if not isinstance(
                    uploaded_manifest,
                    dict,
                ):
                    return error(
                        "manifest.json "
                        "должен быть объектом"
                    )

                files_added = 0
                bytes_added = 0

                for member in (
                    archive.infolist()
                ):

                    raw_name = (
                        member.filename
                        .replace(
                            "\\",
                            "/",
                        )
                    )

                    if (
                        not raw_name
                        or raw_name.endswith("/")
                    ):
                        continue

                    suffix = (
                        Path(raw_name)
                        .suffix
                        .lower()
                    )

                    if (
                        suffix
                        not in
                        WELDER_PHOTO_EXTENSIONS
                    ):
                        continue

                    parts = (
                        Path(raw_name)
                        .parts
                    )

                    if (
                        raw_name.startswith("/")
                        or any(
                            part in (
                                "",
                                "..",
                            )
                            for part
                            in parts
                        )
                    ):
                        continue

                    target = (
                        WELDER_PHOTOS_ROOT
                        / raw_name
                    ).resolve()

                    root_resolved = (
                        WELDER_PHOTOS_ROOT
                        .resolve()
                    )

                    if not str(
                        target
                    ).startswith(
                        str(
                            root_resolved
                        )
                    ):
                        continue

                    target.parent.mkdir(
                        parents=True,
                        exist_ok=True,
                    )

                    #
                    # Копируем потоково по 1 МБ,
                    # без z.read(photo) целиком.
                    #
                    with (
                        archive.open(
                            member,
                            "r",
                        )
                        as source,
                        target.open(
                            "wb"
                        )
                        as dest
                    ):

                        shutil.copyfileobj(
                            source,
                            dest,
                            length=(
                                1024
                                * 1024
                            ),
                        )

                    try:
                        target.chmod(
                            0o644
                        )

                        target.parent.chmod(
                            0o755
                        )

                    except Exception:
                        pass

                    files_added += 1

                    bytes_added += int(
                        member.file_size
                        or 0
                    )

        except zipfile.BadZipFile:
            return error(
                "Файл повреждён "
                "или не является zip-архивом"
            )

        except Exception as exc:
            return error(
                "Ошибка распаковки фото: "
                + str(exc),
                500,
            )


        #
        # manifest из нашего сборщика полный:
        # он содержит и старые, и новые клейма.
        #
        # Но сам ZIP после первой загрузки
        # содержит только новые фотографии.
        #
        # Поэтому файлы просто дополняем,
        # а manifest сливаем с серверным.
        #
        merged = (
            _welder_photo_read_manifest()
        )

        for (
            stamp,
            rel_path,
        ) in (
            uploaded_manifest.items()
        ):

            if str(
                stamp
            ).startswith("__"):
                continue

            stamp_text = (
                _welder_photo_norm_stamp(
                    stamp
                )
            )

            rel_text = (
                str(
                    rel_path
                    or ""
                )
                .replace(
                    "\\",
                    "/",
                )
                .strip()
            )

            if (
                not stamp_text
                or not rel_text
            ):
                continue

            suffix = (
                Path(rel_text)
                .suffix
                .lower()
            )

            parts = (
                Path(rel_text)
                .parts
            )

            if (
                suffix
                not in
                WELDER_PHOTO_EXTENSIONS
            ):
                continue

            if (
                rel_text.startswith("/")
                or any(
                    part in (
                        "",
                        "..",
                    )
                    for part
                    in parts
                )
            ):
                continue

            merged[
                stamp_text
            ] = rel_text


        merged[
            "__version__"
        ] = (
            datetime
            .utcnow()
            .strftime(
                "%Y%m%d%H%M%S"
            )
        )


        WELDER_PHOTOS_MANIFEST.write_text(
            json.dumps(
                merged,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        try:

            WELDER_PHOTOS_MANIFEST.chmod(
                0o644
            )

            WELDER_PHOTOS_ROOT.chmod(
                0o755
            )

        except Exception:
            pass


    return jsonify({
        "ok": True,

        "files_added":
            files_added,

        "bytes_added":
            bytes_added,

        "welders":
            len([
                key
                for key
                in merged.keys()
                if not str(key)
                .startswith("__")
            ]),

        "version":
            merged.get(
                "__version__",
                "0",
            ),
    })


@APP.get(
    "/api/welder_photo/<stamp>"
)
def welder_photo(
    stamp
):

    safe_stamp = (
        _welder_photo_norm_stamp(
            Path(stamp).name
        )
    )

    if not safe_stamp:
        return error(
            "Клеймо не указано",
            400,
        )


    allowed, welder = (
        _welder_photo_request_allowed(
            safe_stamp
        )
    )


    if not allowed:

        #
        # Если такого клейма вообще нет,
        # браузеру удобнее получить 404.
        #
        if welder is None:
            return error(
                "Фото не найдено",
                404,
            )

        return error(
            "Нет доступа",
            403,
        )


    manifest = (
        _welder_photo_read_manifest()
    )


    rel_path = (
        manifest.get(
            safe_stamp
        )
    )


    #
    # На всякий случай поддерживаем
    # manifest со старым регистром клейма.
    #
    if not rel_path:

        for (
            key,
            value,
        ) in (
            manifest.items()
        ):

            if (
                _welder_photo_norm_stamp(
                    key
                )
                == safe_stamp
            ):

                rel_path = value
                break


    if not rel_path:
        return error(
            "Фото не найдено",
            404,
        )


    rel_path = (
        str(rel_path)
        .replace(
            "\\",
            "/",
        )
    )


    target = (
        WELDER_PHOTOS_ROOT
        / rel_path
    ).resolve()


    root_resolved = (
        WELDER_PHOTOS_ROOT
        .resolve()
    )


    if not str(
        target
    ).startswith(
        str(
            root_resolved
        )
    ):
        return error(
            "Недопустимый путь",
            400,
        )


    if (
        not target.exists()
        or not target.is_file()
        or target.suffix.lower()
        not in
        WELDER_PHOTO_EXTENSIONS
    ):
        return error(
            "Фото не найдено",
            404,
        )


    suffix = (
        target.suffix
        .lower()
    )


    mimetype = {
        ".png":
            "image/png",

        ".jpg":
            "image/jpeg",

        ".jpeg":
            "image/jpeg",

        ".webp":
            "image/webp",

    }.get(
        suffix,
        "application/octet-stream",
    )


    response = send_file(
        target,
        mimetype=mimetype,
        as_attachment=False,
        max_age=(
            86400
            * 30
        ),
        conditional=True,
    )


    #
    # Обычный HTTP-кэш разрешён,
    # но ответ приватный.
    #
    response.headers[
        "Cache-Control"
    ] = (
        "private, max-age=2592000"
    )


    return response


# WELDER PHOTOS API END


ENGINEERS_FILE = SITE_ROOT / "engineers.json"

@APP.get("/api/engineers")
def get_engineers():
    if not ENGINEERS_FILE.exists():
        return jsonify([])
    try:
        data = json.loads(ENGINEERS_FILE.read_text(encoding="utf-8"))
        return jsonify(data)
    except Exception:
        return jsonify([])

@APP.post("/api/engineers")
def save_engineers():
    if not authorized():
        return error("Нет доступа", 401)
    try:
        data = request.get_json(force=True)
        if not isinstance(data, list):
            return error("Ожидается список")
        ENGINEERS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        ENGINEERS_FILE.chmod(0o644)
        return jsonify({"ok": True, "count": len(data)})
    except Exception as exc:
        return error(f"Ошибка: {exc}", 500)
