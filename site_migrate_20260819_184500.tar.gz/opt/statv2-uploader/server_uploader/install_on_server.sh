#!/usr/bin/env bash
set -euo pipefail
apt update
apt install -y python3-venv python3-pip unzip
mkdir -p /opt/statv2-uploader
cp app.py requirements.txt statv2-uploader.service /opt/statv2-uploader/
cd /opt/statv2-uploader
if [ ! -d venv ]; then
  python3 -m venv venv
fi
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
cp statv2-uploader.service /etc/systemd/system/statv2-uploader.service
systemctl daemon-reload
systemctl enable --now statv2-uploader
systemctl restart statv2-uploader
systemctl status statv2-uploader --no-pager
printf '\nТеперь добавь location /api/export_stats_excel в Nginx и выполни: nginx -t && systemctl reload nginx\n'
