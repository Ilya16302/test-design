const CACHE_NAME = 'statv2-pwa-v8';
const CACHE_PREFIX = 'statv2-pwa-';

self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(['/index.html', '/index_v2.html', '/gate.html']);
    }).catch(function(e){ console.warn('precache failed:', e); })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      // Чистим ТОЛЬКО свою версионную линейку (statv2-pwa-*),
      // остальные кеши сайта (например, statv2-offline-v5 —
      // там лежит офлайн-копия базы) не трогаем.
      return Promise.all(
        keys
          .filter(function(k){ return k.indexOf(CACHE_PREFIX) === 0 && k !== CACHE_NAME; })
          .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return clients.claim(); })
  );
});

self.addEventListener('fetch', function(e) {
  var url = new URL(e.request.url);

  // Навигация — кеш первым для мгновенной загрузки,
  // обновление кеша идёт через waitUntil, вызванный СРАЗУ,
  // синхронно при получении события (не из вложенного .then).
  if(e.request.mode === 'navigate') {
    // "/" и "/gate.html" — это один и тот же файл (см. nginx index),
    // поэтому используем ОДИН ключ кеша для обоих, чтобы они
    // не могли разойтись между собой.
    var cacheKey = (url.pathname === '/')
      ? (url.origin + '/gate.html')
      : e.request;

    // Сеть — первым делом. Обычно сервер отвечает быстрым 304
    // (Cache-Control: no-cache на HTML заставляет браузер сверяться
    // каждый раз, но это не полная перекачка) — юзер получает
    // гарантированно актуальную страницу. Если сеть не ответила
    // за 4 секунды (реально нет интернета) — откатываемся на кеш.
    var navNetwork = fetch(e.request.clone()).then(function(r) {
      if(r.ok){
        var copy = r.clone();
        caches.open(CACHE_NAME).then(function(c){ c.put(cacheKey, copy); });
      }
      return r;
    });

    e.waitUntil(navNetwork.catch(function(){ /* офлайн — просто не обновляем кеш */ }));

    var navTimeout = new Promise(function(resolve) {
      setTimeout(function(){ resolve(null); }, 4000);
    });

    e.respondWith(
      Promise.race([navNetwork, navTimeout]).then(function(r) {
        if(r) return r;
        return caches.match(cacheKey).then(function(cached) {
          return cached || navNetwork;
        });
      }).catch(function() {
        return caches.match(cacheKey).then(function(cached) {
          return cached || caches.match('/index_v2.html').then(function(shell) {
            return shell || new Response(
              '<!doctype html><meta charset="utf-8"><body style="background:#111;color:#eee;font-family:sans-serif;padding:40px;text-align:center"><h2>Нет соединения</h2><p>Сайт ещё ни разу не открывался на этом устройстве с интернетом — офлайн-копии нет.</p></body>',
              {headers:{'Content-Type':'text/html; charset=utf-8'}, status: 200}
            );
          });
        });
      })
    );
    return;
  }

  // /api/session
  if(url.pathname === '/api/session') {
    e.respondWith(
      fetch(e.request).catch(function() {
        return new Response(JSON.stringify({ok:true,authenticated:false,offline:true}), {
          headers:{'Content-Type':'application/json'}
        });
      })
    );
    return;
  }

  // Остальные API
  if(url.pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(e.request).catch(function() {
        return new Response(JSON.stringify({ok:false,error:'offline',offline:true}), {
          headers:{'Content-Type':'application/json'}
        });
      })
    );
    return;
  }

  // Всё остальное — та же схема: waitUntil сразу, respondWith отдельно
  var otherNetwork = fetch(e.request.clone());

  var otherCacheUpdate = otherNetwork.then(function(r) {
    if(r.ok){
      return caches.open(CACHE_NAME).then(function(c){ return c.put(e.request, r.clone()); });
    }
  }).catch(function(){});

  e.waitUntil(otherCacheUpdate);

  e.respondWith(
    otherNetwork.then(function(r){ return r; }).catch(function() {
      return caches.match(e.request).then(function(c) {
        return c || new Response('Offline', {status:503});
      });
    })
  );
});
