#!/usr/bin/env python3
import base64
import hashlib
import hmac
import secrets
import gzip
import json
import os
import shutil
import tempfile
import zipfile
from copy import copy
from datetime import datetime
from pathlib import Path

from flask import Flask, after_this_request, jsonify, request, send_file, session, g
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Border, Side

APP = Flask(__name__)
APP.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("STATV2_MAX_UPLOAD_MB", "250")) * 1024 * 1024

SITE_ROOT = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2")).resolve()
DB_TARGET = SITE_ROOT / "db"
BACKUP_ROOT = SITE_ROOT / "uploads_backup"
IDCARDS_ROOT     = SITE_ROOT / "id_cards"
IDCARDS_MANIFEST = IDCARDS_ROOT / "manifest.json"
TEMPLATE_PATH = SITE_ROOT / "templates" / "statistika_template.xlsm"
MATERIAL_TEMPLATE_PATH = SITE_ROOT / "templates" / "statistika_template_material.xlsm"
UPLOAD_USER = os.environ.get("STATV2_UPLOAD_USER", "admin_update")
UPLOAD_PASS = os.environ.get("STATV2_UPLOAD_PASS", "Polina110302")

STAT_ADMIN_LOGIN = os.environ.get("STATV2_STAT_ADMIN_LOGIN", "admin_stat")
STAT_ADMIN_PASS = os.environ.get("STATV2_STAT_ADMIN_PASS", "Ilya16302")
DYNAMIC_ORG_ACCOUNTS_PATH = Path(os.environ.get("STATV2_ORG_ACCOUNTS_PATH", "/opt/statv2-auth/org_accounts.json"))
SPK_CONTRACTORS_PATH = Path(os.environ.get("STATV2_SPK_CONTRACTORS_PATH", "/opt/statv2-auth/spk_contractors.json"))
SPK_BACKLOG_HISTORY_PATH = Path(os.environ.get("STATV2_SPK_BACKLOG_HISTORY_PATH", "/opt/statv2-auth/spk_daily_backlog.json"))

# Организационные админки. Живут на сервере и не зависят от обновления базы.
ORG_ADMIN_ACCOUNTS = {
    "NGTS_01": {"password": "ddyvxyhi", "org_filter": "НГТС", "title": "НГТС"},
    "NOVA_01": {"password": "tvixwowc", "org_filter": "НОВА", "title": "НОВА"},
    "GALA_01": {"password": "uvnxebih", "org_filter": "ГАЛА", "title": "ГАЛА"},
    "SSPI_01": {"password": "fzzfdxzr", "org_filter": "ССПИ", "title": "ССПИ"},
}

# STATV2_HYBRID_AUTH_ROUTES_V1
PRIVATE_AUTH_ROOT = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
PRIVATE_AUTH_PATH = PRIVATE_AUTH_ROOT / "auth.json.gz"
SECRET_PATH = PRIVATE_AUTH_ROOT / "flask_secret_key.txt"

PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)

if not SECRET_PATH.exists():
    SECRET_PATH.write_text(secrets.token_hex(32), encoding="utf-8")
    SECRET_PATH.chmod(0o600)

APP.secret_key = os.environ.get("STATV2_SECRET_KEY") or SECRET_PATH.read_text(encoding="utf-8").strip()
APP.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("STATV2_COOKIE_SECURE", "1") != "0",
)

# STATV2_AUTH_PATCH_V1
PRIVATE_AUTH_ROOT = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
PRIVATE_AUTH_PATH = PRIVATE_AUTH_ROOT / "auth.json.gz"
SECRET_PATH = PRIVATE_AUTH_ROOT / "flask_secret_key.txt"

PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
if not SECRET_PATH.exists():
    SECRET_PATH.write_text(secrets.token_hex(32), encoding="utf-8")
    SECRET_PATH.chmod(0o600)

APP.secret_key = os.environ.get("STATV2_SECRET_KEY") or SECRET_PATH.read_text(encoding="utf-8").strip()
APP.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("STATV2_COOKIE_SECURE", "1") != "0",
)

REQUIRED = [
    "manifest.json",
    "auth.json.gz",
    "admin_summary.json.gz",
    "welders/shard_00.json.gz",
    "welders/shard_01.json.gz",
    "welders/shard_02.json.gz",
    "welders/shard_03.json.gz",
    "welders/shard_04.json.gz",
    "welders/shard_05.json.gz",
    "welders/shard_06.json.gz",
    "welders/shard_07.json.gz",
]


def error(message, code=400):
    return jsonify({"ok": False, "error": message}), code


AUDIT_LOG = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))


def client_ip():
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",", 1)[0].strip()
    return request.headers.get("X-Real-IP") or request.remote_addr or ""


def audit_event(event, login="", role="", ok=False, extra=None):
    try:
        AUDIT_LOG.parent.mkdir(parents=True, exist_ok=True)
        now = datetime.now()
        ip = client_ip()
        login_s = str(login or "")

        # Дедуп: тот же логин+событие+IP за последние 5 секунд считаем повторным
        # сабмитом (двойной тап / Enter+клик / ретрай мобильной сети), а не новым визитом.
        try:
            if AUDIT_LOG.exists():
                with AUDIT_LOG.open("rb") as f:
                    f.seek(0, 2)
                    size = f.tell()
                    f.seek(max(0, size - 8192))
                    tail = f.read().decode("utf-8", errors="ignore")
                for line in reversed(tail.splitlines()):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        last = json.loads(line)
                        last_ts = datetime.fromisoformat(last.get("ts", ""))
                    except Exception:
                        continue
                    if (now - last_ts).total_seconds() > 5:
                        break
                    if last.get("event") == event and last.get("login") == login_s and last.get("ip") == ip:
                        return
        except Exception:
            pass

        row = {
            "ts": now.isoformat(timespec="seconds"),
            "event": event,
            "ok": bool(ok),
            "login": login_s,
            "role": str(role or ""),
            "ip": ip,
            "user_agent": request.headers.get("User-Agent", ""),
        }
        if extra:
            row.update(extra)
        with AUDIT_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception:
        pass


def authorized() -> bool:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
        user, password = raw.split(":", 1)
    except Exception:
        return False
    return user == UPLOAD_USER and password == UPLOAD_PASS


def read_json_gz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def write_json_gz(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(path, "wt", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))


def norm_login(value: str) -> str:
    return str(value or "").strip().lower().replace("ё", "е")


def password_sha256(password: str) -> str:
    return hashlib.sha256(str(password or "").encode("utf-8")).hexdigest()


def verify_password(password: str, password_hash: str = "", password_plain: str = "") -> bool:
    password = str(password or "")
    password_hash = str(password_hash or "")
    password_plain = str(password_plain or "")

    if password_hash and hmac.compare_digest(password_sha256(password), password_hash):
        return True
    if password_plain and hmac.compare_digest(password, password_plain):
        return True
    return False


def load_private_auth():
    if PRIVATE_AUTH_PATH.exists():
        return read_json_gz(PRIVATE_AUTH_PATH)

    fallback = DB_TARGET / "auth.json.gz"
    if fallback.exists():
        PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
        shutil.copy2(fallback, PRIVATE_AUTH_PATH)
        PRIVATE_AUTH_PATH.chmod(0o600)
        return read_json_gz(PRIVATE_AUTH_PATH)

    raise FileNotFoundError("Не найден закрытый auth.json.gz")


def save_private_auth_from_db(db_dir: Path):
    auth = db_dir / "auth.json.gz"
    if auth.exists():
        PRIVATE_AUTH_ROOT.mkdir(parents=True, exist_ok=True)
        shutil.copy2(auth, PRIVATE_AUTH_PATH)
        PRIVATE_AUTH_PATH.chmod(0o600)


def strip_secrets_obj(obj):
    if isinstance(obj, dict):
        for k in ("password_plain", "password_hash", "admin_password_hash"):
            obj.pop(k, None)
        if isinstance(obj.get("auth"), dict):
            obj["auth"] = {
                k: v for k, v in obj["auth"].items()
                if k not in ("admin_password_hash", "password_hash", "password_plain")
            }
        for v in obj.values():
            strip_secrets_obj(v)
    elif isinstance(obj, list):
        for v in obj:
            strip_secrets_obj(v)


def sanitize_public_db(db_dir: Path):
    for gz in db_dir.rglob("*.json.gz"):
        data = read_json_gz(gz)
        strip_secrets_obj(data)
        write_json_gz(gz, data)


def is_role(*roles: str) -> bool:
    return str(session.get("role") or "") in roles


def basic_authorized() -> bool:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
        user, password = raw.split(":", 1)
    except Exception:
        return False
    return hmac.compare_digest(user, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS)


def public_meta():
    manifest = DB_TARGET / "manifest.json"
    if not manifest.exists():
        return {}
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        return {
            "generated_at": data.get("generated_at", ""),
            "period_start": data.get("period_start", ""),
            "period_end": data.get("period_end", ""),
            "counts": data.get("counts", {}),
        }
    except Exception:
        return {}


def find_auth_welder_by_login(login: str):
    login_n = norm_login(login)
    auth_db = load_private_auth()
    for w in auth_db.get("welders", []):
        if norm_login(w.get("login")) == login_n:
            return w
    return None




def safe_public_meta():
    # Универсальная безопасная обёртка, чтобы логин не падал из-за разных имён функций meta.
    for name in ("_public_meta", "public_meta", "db_public_meta"):
        fn = globals().get(name)
        if callable(fn):
            try:
                return fn()
            except Exception:
                pass

    try:
        manifest = DB_TARGET / "manifest.json"
        if manifest.exists():
            data = json.loads(manifest.read_text(encoding="utf-8"))
            return {
                "generated_at": data.get("generated_at", ""),
                "period_start": data.get("period_start", ""),
                "period_end": data.get("period_end", ""),
                "counts": data.get("counts", {}),
            }
    except Exception:
        pass

    return {}

@APP.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or request.form
    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "")

    if not login or not password:
        return error("Введите логин и пароль", 400)

    org_cfg = ORG_ADMIN_ACCOUNTS.get(login.strip().upper())
    if org_cfg and hmac.compare_digest(password, org_cfg["password"]):
        session.clear()
        session["role"] = "admin"
        session["login"] = login.strip()
        session["org_filter"] = org_cfg["org_filter"]
        session["org_title"] = org_cfg["title"]
        try:
            audit_event("org_admin_login_success", login=login, role="admin", ok=True, extra={
                "org_filter": org_cfg["org_filter"],
                "org_title": org_cfg["title"],
            })
        except Exception:
            pass
        return jsonify({
            "ok": True,
            "role": "admin",
            "org_filter": org_cfg["org_filter"],
            "org_title": org_cfg["title"],
            "meta": safe_public_meta(),
        })

    if hmac.compare_digest(login, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS):
        session.clear()
        session["role"] = "updater"
        session["login"] = UPLOAD_USER
        return jsonify({"ok": True, "role": "updater", "meta": safe_public_meta()})

    try:
        auth_db = load_private_auth()
    except Exception as exc:
        return error(str(exc), 500)

    auth = auth_db.get("auth", {})
    admin_login = str(auth.get("admin_login") or "admin")

    if norm_login(login) == norm_login(admin_login):
        if verify_password(password, auth.get("admin_password_hash", "")):
            session.clear()
            session["role"] = "admin"
            session["login"] = admin_login
            return jsonify({"ok": True, "role": "admin", "meta": safe_public_meta()})

    w = find_auth_welder_by_login(login)
    if w and verify_password(password, w.get("password_hash", ""), w.get("password_plain", "")):
        session.clear()
        session["role"] = "welder"
        session["login"] = w.get("login", login)
        session["welder_id"] = w.get("id", "")
        return jsonify({
            "ok": True,
            "role": "welder",
            "welder_id": w.get("id", ""),
            "shard": w.get("shard", ""),
            "name": w.get("name", ""),
            "meta": safe_public_meta(),
        })

    audit_event("login_failed", login=login, role="", ok=False)
    return error("Логин или пароль не подошли", 401)


@APP.get("/api/session")
def api_session():
    role = str(session.get("role") or "")
    if not role:
        return jsonify({"ok": True, "authenticated": False, "meta": safe_public_meta()})

    result = {
        "ok": True,
        "authenticated": True,
        "role": role,
        "login": session.get("login", ""),
        "welder_id": session.get("welder_id", ""),
        "meta": safe_public_meta(),
    }

    if session.get("org_filter"):
        result["org_filter"] = session.get("org_filter", "")
        result["org_title"] = session.get("org_title", "")

    if role == "welder":
        w = None
        try:
            auth_db = load_private_auth()
            for item in auth_db.get("welders", []):
                if str(item.get("id") or "") == str(session.get("welder_id") or ""):
                    w = item
                    break
        except Exception:
            w = None
        if w:
            result["shard"] = w.get("shard", "")

    return jsonify(result)


@APP.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify({"ok": True})


def safe_extract_zip(zip_path: Path, dest: Path) -> None:
    dest_resolved = dest.resolve()
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            name = member.filename.replace("\\", "/")
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError(f"Запрещённый путь в архиве: {member.filename}")
            target = (dest / name).resolve()
            if not str(target).startswith(str(dest_resolved)):
                raise ValueError(f"Запрещённый путь в архиве: {member.filename}")
        z.extractall(dest)


def find_db_dir(extracted: Path) -> Path:
    candidate = extracted / "db"
    if candidate.is_dir():
        return candidate
    if (extracted / "manifest.json").exists():
        return extracted
    raise ValueError("В архиве не найдена папка db или manifest.json")


def validate_db_dir(db_dir: Path) -> None:
    missing = [name for name in REQUIRED if not (db_dir / name).is_file()]
    if missing:
        raise ValueError("В архиве не хватает файлов: " + ", ".join(missing))


def chmod_tree(path: Path) -> None:
    for p in path.rglob("*"):
        try:
            if p.is_dir():
                p.chmod(0o755)
            else:
                p.chmod(0o644)
        except Exception:
            pass
    try:
        path.chmod(0o755)
    except Exception:
        pass


@APP.get("/health")
def health():
    return jsonify({"ok": True, "site_root": str(SITE_ROOT), "template": str(TEMPLATE_PATH)})



@APP.post("/api/upload_db")
def upload_db():
    # Разрешаем загрузку только пользователю admin_update через серверную сессию.
    # Старый Basic-режим оставляем как аварийный запас.
    allowed = str(session.get("role") or "") in ("updater", "stat_admin")

    if not allowed:
        header = request.headers.get("Authorization", "")
        if header.startswith("Basic "):
            try:
                raw = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
                user, password = raw.split(":", 1)
                allowed = hmac.compare_digest(user, UPLOAD_USER) and hmac.compare_digest(password, UPLOAD_PASS)
            except Exception:
                allowed = False

    if not allowed:
        return error("Нет доступа", 401)

    file = request.files.get("file")
    if not file or not file.filename:
        return error("Файл не выбран")

    if not file.filename.lower().endswith(".zip"):
        return error("Нужен zip-архив")

    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    SITE_ROOT.mkdir(parents=True, exist_ok=True)

    def _read_gz(path):
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)

    def _write_gz(path, data):
        with gzip.open(path, "wt", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))

    def _strip_secrets(obj):
        if isinstance(obj, dict):
            # В публичной базе не должно быть логинов, паролей и хэшей.
            for key in ("login", "password_plain", "password_hash", "admin_password_hash"):
                obj.pop(key, None)

            if isinstance(obj.get("auth"), dict):
                obj["auth"] = {}

            for value in obj.values():
                _strip_secrets(value)

        elif isinstance(obj, list):
            for value in obj:
                _strip_secrets(value)

    def _save_private_auth(db_dir):
        auth_file = db_dir / "auth.json.gz"
        if not auth_file.exists():
            raise ValueError("В архиве нет auth.json.gz — без него сервер не сможет проверять вход")

        private_root = Path(os.environ.get("STATV2_AUTH_ROOT", "/opt/statv2-auth")).resolve()
        private_root.mkdir(parents=True, exist_ok=True)

        private_auth = private_root / "auth.json.gz"
        shutil.copy2(auth_file, private_auth)
        private_auth.chmod(0o600)

    def _sanitize_public_db(db_dir):
        for gz in db_dir.rglob("*.json.gz"):
            data = _read_gz(gz)
            _strip_secrets(data)
            _write_gz(gz, data)

    with tempfile.TemporaryDirectory(prefix="statv2_upload_") as tmp_name:
        tmp = Path(tmp_name)
        zip_path = tmp / "upload.zip"
        extracted = tmp / "extracted"
        new_db_tmp = tmp / "db_new"
        spk_snapshot = None

        extracted.mkdir()
        file.save(zip_path)

        try:
            safe_extract_zip(zip_path, extracted)
            db_dir = find_db_dir(extracted)
            validate_db_dir(db_dir)

            shutil.copytree(db_dir, new_db_tmp)

            snapshot_path = new_db_tmp / "spk_backlog_snapshot.json"
            if snapshot_path.exists():
                spk_snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
                if not isinstance(spk_snapshot, dict):
                    raise ValueError("Некорректный spk_backlog_snapshot.json")

            # 1. Сначала сохраняем закрытую базу входа.
            _save_private_auth(new_db_tmp)

            # 2. Потом чистим публичную базу.
            _sanitize_public_db(new_db_tmp)

            chmod_tree(new_db_tmp)

        except Exception as exc:
            return error(str(exc), 400)

        backup_path = None

        if DB_TARGET.exists():
            backup_path = BACKUP_ROOT / ("db_" + datetime.now().strftime("%Y%m%d_%H%M%S"))
            shutil.move(str(DB_TARGET), str(backup_path))

        try:
            shutil.move(str(new_db_tmp), str(DB_TARGET))
            if spk_snapshot:
                statv2_merge_spk_backlog_snapshot(spk_snapshot)
        except Exception as exc:
            if DB_TARGET.exists():
                shutil.rmtree(DB_TARGET, ignore_errors=True)
            if backup_path and backup_path.exists():
                shutil.move(str(backup_path), str(DB_TARGET))
            return error("Не удалось заменить db или сохранить снимок СПК: " + str(exc), 500)

    snapshot_date = str((spk_snapshot or {}).get("date") or "")
    return jsonify({
        "ok": True,
        "message": "База обновлена. Закрытый auth сохранён, публичная db очищена от логинов и паролей.",
        "backup": str(backup_path) if backup_path else "",
        "spk_snapshot_date": snapshot_date,
    })


# ---------------- Excel export ----------------

def read_json_gz(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def load_sharded_database(include_joints=False):
    manifest_path = DB_TARGET / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError("Не найден db/manifest.json")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    shard_paths = manifest.get("shards") or [f"welders/shard_{i:02d}.json.gz" for i in range(8)]

    welders = []
    welder_events = {}
    joints_by_id = {}

    for rel in shard_paths:
        shard = read_json_gz(DB_TARGET / rel)
        welders.extend(shard.get("welders", []))
        welder_events.update(shard.get("welder_events", {}))
        if include_joints:
            for joint in shard.get("joints", []):
                joint_id = str(joint.get("id") or joint.get("key") or "")
                if joint_id:
                    joints_by_id[joint_id] = joint

    welders.sort(key=lambda w: str(w.get("name") or "").casefold())
    joints = list(joints_by_id.values())
    return manifest, welders, welder_events, joints


def empty_stats():
    return {
        "total_welded": 0,
        "production": 0.0,
        "submitted_control": 0,
        "accepted": 0,
        "rejected": 0,
        "wait": 0,
        "not_required": 0,
        "reject_rate": None,
    }


def add_stat(s, e):
    s["total_welded"] += 1
    try:
        s["production"] += float(e.get("inch") or 0)
    except Exception:
        pass

    result = e.get("result") or ""
    if result == "Годен":
        s["submitted_control"] += 1
        s["accepted"] += 1
    elif result == "Не годен":
        s["submitted_control"] += 1
        s["rejected"] += 1
    elif result == "Ожидание контроля":
        s["submitted_control"] += 1
        s["wait"] += 1
    elif result == "Контроль РК/УЗК не требуется":
        s["not_required"] += 1


def finalize(s):
    controlled = s["accepted"] + s["rejected"]
    s["reject_rate"] = (s["rejected"] / controlled) if controlled else None
    return s


def calc_stats(events, scope, start="", end=""):
    s = empty_stats()
    for e in events:
        if scope == "primary" and e.get("stage_type") != "primary":
            continue
        if scope == "repairs" and e.get("stage_type") != "repair":
            continue
        d = str(e.get("weld_date") or "")[:10]
        if start and d < start:
            continue
        if end and d > end:
            continue
        add_stat(s, e)
    return finalize(s)


MATERIAL_GROUPS = ("LTCS", "SS", "LOAS")
MATERIAL_GROUP_RAW = {
    "LTCS": (
        "LTCS", "09G2S", "СТ20", "09G2S/09G2S(K48)", "STS410-S",
        "A333-6/A671-CC60", "ASTMA333-6", "ASTMA350-LF2CL.1",
        "ASTMA420-WPL6",
    ),
    "SS": (
        "304/304L", "316/316L", "12Х18Н10Т",
        "A312-TP304/304L/A358-304/304L", "304L", "304/304", "316L",
        "304/316L", "ASTMA312-TP304/304L", "ASTMA182-F304/304L", "316",
    ),
    "LOAS": ("1.25CR-0.5MO", "ASTMA335-P11"),
}
DEFAULT_MATERIAL_RANGE_CONFIG = {
    "diam": ["0-50", "50-109", "109-выше"],
    "thick": [
        ["0-4", "4-выше"],
        ["0-4", "4-выше"],
        ["0-4", "4-выше"],
    ],
}


def norm_material_key(value):
    return "".join(str(value or "").upper().split()).replace("–", "-").replace("—", "-").replace("?", "-")


MATERIAL_GROUP_LOOKUP = {
    norm_material_key(code): group
    for group, codes in MATERIAL_GROUP_RAW.items()
    for code in codes
}


def material_group_of(value):
    return MATERIAL_GROUP_LOOKUP.get(norm_material_key(value), "")


def parse_number(value):
    try:
        return float(str(value or "").strip().replace(",", "."))
    except Exception:
        return None


def parse_range_spec(raw):
    text = str(raw or "").strip().lower().replace("–", "-").replace("—", "-")
    if "-" not in text:
        return None
    left, right = text.split("-", 1)
    minimum = parse_number(left)
    if minimum is None:
        return None
    right = right.strip()
    maximum = parse_number(right)
    if right in ("выше", "больше") or maximum is None:
        maximum = None
    return {"min": minimum, "max": maximum}


def normalize_material_range_config(raw):
    source = raw if isinstance(raw, dict) else {}
    diam = source.get("diam")
    thick = source.get("thick")

    if not isinstance(diam, list) or len(diam) != 3:
        diam = list(DEFAULT_MATERIAL_RANGE_CONFIG["diam"])
    else:
        diam = [str(value or "").strip() for value in diam]

    if not isinstance(thick, list) or len(thick) != 3:
        thick = [list(pair) for pair in DEFAULT_MATERIAL_RANGE_CONFIG["thick"]]
    else:
        normalized_thick = []
        for index, pair in enumerate(thick):
            if not isinstance(pair, list) or len(pair) != 2:
                normalized_thick.append(list(DEFAULT_MATERIAL_RANGE_CONFIG["thick"][index]))
            else:
                normalized_thick.append([str(value or "").strip() for value in pair])
        thick = normalized_thick

    for label in diam:
        if parse_range_spec(label) is None:
            raise ValueError(f"Некорректный диапазон диаметра: {label}")
    for pair in thick:
        for label in pair:
            if parse_range_spec(label) is None:
                raise ValueError(f"Некорректный диапазон толщины: {label}")

    return {"diam": diam, "thick": thick}


def in_material_range(value, range_info):
    if value is None or value < range_info["min"]:
        return False
    maximum = range_info["max"]
    return maximum is None or value < maximum


def material_bucket_index(diameter, thickness, range_config):
    diameter_ranges = [parse_range_spec(spec) for spec in range_config["diam"]]
    diameter_index = next(
        (index for index, item in enumerate(diameter_ranges) if in_material_range(diameter, item)),
        -1,
    )
    if diameter_index < 0:
        return -1

    thickness_ranges = [
        parse_range_spec(spec)
        for spec in range_config["thick"][diameter_index]
    ]
    thickness_index = next(
        (index for index, item in enumerate(thickness_ranges) if in_material_range(thickness, item)),
        -1,
    )
    if thickness_index < 0:
        return -1
    return diameter_index * 2 + thickness_index


def empty_material_bucket():
    return {"controlled": 0, "good": 0, "bad": 0}


def empty_material_groups():
    return {
        group: {
            "overall": empty_material_bucket(),
            "buckets": [empty_material_bucket() for _ in range(6)],
        }
        for group in MATERIAL_GROUPS
    }


def add_material_result(groups, material, diameter, thickness, result, range_config):
    if result not in ("Годен", "Не годен"):
        return
    group = material_group_of(material)
    if not group:
        return

    is_good = result == "Годен"
    record = groups[group]
    record["overall"]["controlled"] += 1
    record["overall"]["good" if is_good else "bad"] += 1

    diameter_value = parse_number(diameter)
    thickness_value = parse_number(thickness)
    if diameter_value is None or thickness_value is None:
        return

    bucket_index = material_bucket_index(diameter_value, thickness_value, range_config)
    if bucket_index < 0:
        return

    bucket = record["buckets"][bucket_index]
    bucket["controlled"] += 1
    bucket["good" if is_good else "bad"] += 1


def event_matches_scope_and_period(event, scope, start, end):
    if scope == "primary" and event.get("stage_type") != "primary":
        return False
    if scope == "repairs" and event.get("stage_type") != "repair":
        return False
    event_date = str(event.get("weld_date") or "")[:10]
    if start and event_date < start:
        return False
    if end and event_date > end:
        return False
    return True


def calc_material_stats(events, scope, start, end, range_config):
    groups = empty_material_groups()
    for event in events:
        if not event_matches_scope_and_period(event, scope, start, end):
            continue
        add_material_result(
            groups,
            event.get("material"),
            event.get("diameter"),
            event.get("thickness"),
            event.get("result"),
            range_config,
        )
    return groups


def joint_action_allowed(action, allowed_welder_ids):
    if allowed_welder_ids is None:
        return True
    action_welder_ids = {
        str(value or "")
        for value in action.get("welder_ids", [])
        if str(value or "")
    }
    return bool(action_welder_ids & allowed_welder_ids)


def calc_stats_from_joints(joints, scope, start, end, allowed_welder_ids=None):
    stats = empty_stats()
    for joint in joints:
        for action in joint.get("actions", []):
            event = {
                "stage_type": action.get("stage_type"),
                "weld_date": action.get("weld_date"),
            }
            if not event_matches_scope_and_period(event, scope, start, end):
                continue
            if not joint_action_allowed(action, allowed_welder_ids):
                continue
            add_stat(stats, {
                "inch": joint.get("inch"),
                "result": action.get("result"),
            })
    return finalize(stats)


def calc_material_stats_from_joints(joints, scope, start, end, range_config, allowed_welder_ids=None):
    groups = empty_material_groups()
    for joint in joints:
        for action in joint.get("actions", []):
            event = {
                "stage_type": action.get("stage_type"),
                "weld_date": action.get("weld_date"),
            }
            if not event_matches_scope_and_period(event, scope, start, end):
                continue
            if not joint_action_allowed(action, allowed_welder_ids):
                continue
            add_material_result(
                groups,
                joint.get("material"),
                joint.get("diameter"),
                joint.get("thickness"),
                action.get("result"),
                range_config,
            )
    return groups


def controlled_count(s):
    return int(s.get("accepted") or 0) + int(s.get("rejected") or 0)


def reject_rate_value(s):
    return "нет рк/узк" if s.get("reject_rate") is None else s.get("reject_rate")


def parse_iso_date(value: str):
    value = (value or "").strip()
    if not value:
        return None
    return datetime.strptime(value[:10], "%Y-%m-%d").date()


def dash(value):
    return value if value not in (None, "") else "—"


THIN_SIDE = Side(style="thin", color="000000")
DATA_BORDER = Border(left=THIN_SIDE, right=THIN_SIDE, top=THIN_SIDE, bottom=THIN_SIDE)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)


def copy_row_style(ws, source_row: int, target_row: int, col_start: int, col_end: int):
    for col in range(col_start, col_end + 1):
        src = ws.cell(source_row, col)
        dst = ws.cell(target_row, col)
        if src.has_style:
            dst._style = copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        dst.alignment = CENTER
        dst.border = DATA_BORDER
    ws.row_dimensions[target_row].height = ws.row_dimensions[source_row].height or 15.75


def clear_range(ws, row_start, row_end, col_start, col_end):
    for row in range(row_start, row_end + 1):
        for col in range(col_start, col_end + 1):
            cell = ws.cell(row, col)
            cell.value = None


def prepare_sheet(ws, max_row, data_col_start, data_col_end, data_start_row=4, style_source_row=3, clear_floor=5000):
    clear_to = max(ws.max_row, max_row, clear_floor)
    clear_range(ws, data_start_row, clear_to, data_col_start, data_col_end)
    for row in range(data_start_row, max_row + 1):
        copy_row_style(ws, style_source_row, row, data_col_start, data_col_end)


def write_period_cells(ws, start_cell, end_cell, start, end):
    ws[start_cell].value = parse_iso_date(start)
    ws[end_cell].value = parse_iso_date(end)
    ws[start_cell].number_format = "dd.mm.yyyy"
    ws[end_cell].number_format = "dd.mm.yyyy"
    ws[start_cell].alignment = CENTER
    ws[end_cell].alignment = CENTER


def write_full_or_repairs(ws, rows, start, end):
    last_row = 3 + len(rows)
    prepare_sheet(ws, last_row, 3, 18)  # C:R
    write_period_cells(ws, "T3", "U3", start, end)

    for idx, row in enumerate(rows, start=4):
        all_s = row["all"]
        per_s = row["period"]
        values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            controlled_count(all_s), all_s["accepted"], all_s["rejected"], reject_rate_value(all_s),
            controlled_count(per_s), per_s["accepted"], per_s["rejected"], reject_rate_value(per_s),
        ]
        for col, value in enumerate(values, start=3):
            cell = ws.cell(idx, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (14, 18):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col >= 11:
                cell.number_format = "0"


def write_primary(ws, rows, start, end):
    last_row = 3 + len(rows)
    prepare_sheet(ws, last_row, 3, 22)  # C:V
    write_period_cells(ws, "X3", "Y3", start, end)

    for idx, row in enumerate(rows, start=4):
        all_s = row["all"]
        per_s = row["period"]
        values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            all_s["total_welded"], all_s["production"], all_s["submitted_control"], all_s["accepted"], all_s["rejected"], reject_rate_value(all_s),
            per_s["total_welded"], per_s["production"], per_s["submitted_control"], per_s["accepted"], per_s["rejected"], reject_rate_value(per_s),
        ]
        for col, value in enumerate(values, start=3):
            cell = ws.cell(idx, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (16, 22):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col in (12, 18):
                cell.number_format = "0.00"
            elif col >= 11:
                cell.number_format = "0"




def material_rate_value(bucket):
    controlled = int(bucket.get("controlled") or 0)
    return (int(bucket.get("bad") or 0) / controlled) if controlled else "—"


def material_bucket_values(bucket):
    return [
        int(bucket.get("controlled") or 0),
        int(bucket.get("good") or 0),
        int(bucket.get("bad") or 0),
        material_rate_value(bucket),
    ]


def flatten_material_groups(groups):
    values = []
    for group in MATERIAL_GROUPS:
        record = groups[group]
        values.extend(material_bucket_values(record["overall"]))
        for bucket in record["buckets"]:
            values.extend(material_bucket_values(bucket))
    return values


def write_material_range_headers(ws, material_start_col, range_config):
    for group_index, _group in enumerate(MATERIAL_GROUPS):
        group_start = material_start_col + group_index * 28
        for diameter_index, diameter_label in enumerate(range_config["diam"]):
            diameter_start = group_start + 4 + diameter_index * 8
            ws.cell(3, diameter_start).value = diameter_label
            ws.cell(4, diameter_start).value = range_config["thick"][diameter_index][0]
            ws.cell(4, diameter_start + 4).value = range_config["thick"][diameter_index][1]


def write_material_values(ws, row_index, start_col, values):
    for offset, value in enumerate(values):
        col = start_col + offset
        cell = ws.cell(row_index, col)
        cell.value = value
        cell.alignment = CENTER
        cell.border = DATA_BORDER
        if offset % 4 == 3:
            cell.number_format = "@" if isinstance(value, str) else "0.00%"
        else:
            cell.number_format = "0"


def write_material_full_or_repairs(ws, rows, start, end, range_config):
    data_start_row = 7
    last_row = data_start_row - 1 + len(rows)
    prepare_sheet(ws, last_row, 3, 102, data_start_row=data_start_row, style_source_row=6, clear_floor=0)  # C:CX
    write_period_cells(ws, "CZ3", "DA3", start, end)
    write_material_range_headers(ws, 19, range_config)  # S

    for row_index, row in enumerate(rows, start=data_start_row):
        all_stats = row["all"]
        period_stats = row["period"]
        base_values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            controlled_count(all_stats), all_stats["accepted"], all_stats["rejected"], reject_rate_value(all_stats),
            controlled_count(period_stats), period_stats["accepted"], period_stats["rejected"], reject_rate_value(period_stats),
        ]
        for col, value in enumerate(base_values, start=3):
            cell = ws.cell(row_index, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (14, 18):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col >= 11:
                cell.number_format = "0"
        write_material_values(ws, row_index, 19, flatten_material_groups(row["materials"]))

    ws.auto_filter.ref = f"C6:CX{max(6, last_row)}"


def write_material_primary(ws, rows, start, end, range_config):
    data_start_row = 7
    last_row = data_start_row - 1 + len(rows)
    prepare_sheet(ws, last_row, 3, 106, data_start_row=data_start_row, style_source_row=6, clear_floor=0)  # C:DB
    write_period_cells(ws, "DD3", "DE3", start, end)
    write_material_range_headers(ws, 23, range_config)  # W

    for row_index, row in enumerate(rows, start=data_start_row):
        all_stats = row["all"]
        period_stats = row["period"]
        base_values = [
            dash(row["shift"]), dash(row["position"]), dash(row["responsible"]), "Сварщик",
            dash(row["name"]), dash(row["stamp"]), dash(row["status"]), dash(row["organization"]),
            all_stats["total_welded"], all_stats["production"], all_stats["submitted_control"], all_stats["accepted"], all_stats["rejected"], reject_rate_value(all_stats),
            period_stats["total_welded"], period_stats["production"], period_stats["submitted_control"], period_stats["accepted"], period_stats["rejected"], reject_rate_value(period_stats),
        ]
        for col, value in enumerate(base_values, start=3):
            cell = ws.cell(row_index, col)
            cell.value = value
            cell.alignment = CENTER
            cell.border = DATA_BORDER
            if col in (16, 22):
                cell.number_format = "@" if isinstance(value, str) else "0.00%"
            elif col in (12, 18):
                cell.number_format = "0.00"
            elif col >= 11:
                cell.number_format = "0"
        write_material_values(ws, row_index, 23, flatten_material_groups(row["materials"]))

    ws.auto_filter.ref = f"C6:DB{max(6, last_row)}"


def write_material_summary_row(ws, row_index, stats):
    values = [
        controlled_count(stats),
        int(stats.get("accepted") or 0),
        int(stats.get("rejected") or 0),
        reject_rate_value(stats),
    ]
    for offset, value in enumerate(values):
        cell = ws.cell(row_index, 2 + offset)
        cell.value = value
        cell.alignment = CENTER
        cell.border = DATA_BORDER
        cell.number_format = ("@" if isinstance(value, str) else "0.00%") if offset == 3 else "0"


def write_material_block_headers(ws, header_start_row, range_config):
    diameter_columns = (11, 19, 27)  # K, S, AA
    thickness_columns = ((11, 15), (19, 23), (27, 31))
    diameter_row = header_start_row + 1
    thickness_row = header_start_row + 2
    for index, label in enumerate(range_config["diam"]):
        ws.cell(diameter_row, diameter_columns[index]).value = label
        ws.cell(thickness_row, thickness_columns[index][0]).value = range_config["thick"][index][0]
        ws.cell(thickness_row, thickness_columns[index][1]).value = range_config["thick"][index][1]


def write_materials_sheet(ws, start, end, scope_stats, scope_materials, range_config):
    start_date = parse_iso_date(start)
    end_date = parse_iso_date(end)
    ws["P1"].value = f"с {start_date.strftime('%d.%m.%Y')} по {end_date.strftime('%d.%m.%Y')}"
    ws["P1"].alignment = CENTER

    summary_rows = {"repairs": 8, "primary": 29, "total": 50}
    for scope, row_index in summary_rows.items():
        write_material_summary_row(ws, row_index, scope_stats[scope])

    blocks = [
        ("repairs", "LTCS", 4, 8),
        ("repairs", "SS", 11, 15),
        ("repairs", "LOAS", 18, 22),
        ("primary", "LTCS", 25, 29),
        ("primary", "SS", 32, 36),
        ("primary", "LOAS", 39, 43),
        ("total", "LTCS", 46, 50),
        ("total", "SS", 53, 57),
        ("total", "LOAS", 60, 64),
    ]

    for scope, group, header_start_row, values_row in blocks:
        write_material_block_headers(ws, header_start_row, range_config)
        record = scope_materials[scope][group]
        values = material_bucket_values(record["overall"])
        for bucket in record["buckets"]:
            values.extend(material_bucket_values(bucket))
        write_material_values(ws, values_row, 7, values)  # G:AH
        ws.row_dimensions[values_row].height = ws.row_dimensions[values_row].height or 18


def build_export_workbook(start: str, end: str, org_filter: str = "", include_materials=False, material_range_config=None) -> Path:
    range_config = normalize_material_range_config(material_range_config)
    template_path = MATERIAL_TEMPLATE_PATH if include_materials else TEMPLATE_PATH
    if not template_path.exists():
        raise FileNotFoundError(f"Не найден шаблон: {template_path}")

    _manifest, welders, welder_events, joints = load_sharded_database(include_joints=include_materials)

    org_filter_n = str(org_filter or "").casefold().replace("ё", "е").strip()
    if org_filter_n:
        welders = [
            w for w in welders
            if org_filter_n in str(w.get("organization") or "").casefold().replace("ё", "е")
        ]

    allowed_welder_ids = None if not org_filter_n else {
        str(w.get("id") or "") for w in welders if str(w.get("id") or "")
    }

    def row_common(w):
        return {
            "shift": w.get("shift"),
            "position": w.get("position"),
            "responsible": w.get("responsible"),
            "name": w.get("name"),
            "stamp": w.get("stamp"),
            "status": w.get("status"),
            "organization": w.get("organization"),
        }

    rows_by_scope = {"total": [], "primary": [], "repairs": []}
    for w in welders:
        events = welder_events.get(w.get("id"), [])
        for scope in rows_by_scope:
            item = row_common(w)
            item["all"] = calc_stats(events, scope)
            item["period"] = calc_stats(events, scope, start, end)
            if include_materials:
                item["materials"] = calc_material_stats(events, scope, start, end, range_config)
            rows_by_scope[scope].append(item)

    wb = load_workbook(template_path, keep_vba=True)

    if include_materials:
        required_sheets = [
            "Полная с разбивкой",
            "Первичка с разбивкой",
            "Ремонты с разбивкой",
            "Материалы",
        ]
        for name in required_sheets:
            if name not in wb.sheetnames:
                raise ValueError(f"В шаблоне нет листа: {name}")

        write_material_full_or_repairs(wb["Полная с разбивкой"], rows_by_scope["total"], start, end, range_config)
        write_material_primary(wb["Первичка с разбивкой"], rows_by_scope["primary"], start, end, range_config)
        write_material_full_or_repairs(wb["Ремонты с разбивкой"], rows_by_scope["repairs"], start, end, range_config)

        scope_stats = {
            scope: calc_stats_from_joints(joints, scope, start, end, allowed_welder_ids)
            for scope in rows_by_scope
        }
        scope_materials = {
            scope: calc_material_stats_from_joints(
                joints,
                scope,
                start,
                end,
                range_config,
                allowed_welder_ids,
            )
            for scope in rows_by_scope
        }
        write_materials_sheet(
            wb["Материалы"],
            start,
            end,
            scope_stats,
            scope_materials,
            range_config,
        )
    else:
        required_sheets = ["Полная статистика", "Первичка", "Ремонты"]
        for name in required_sheets:
            if name not in wb.sheetnames:
                raise ValueError(f"В шаблоне нет листа: {name}")

        write_full_or_repairs(wb["Полная статистика"], rows_by_scope["total"], start, end)
        write_primary(wb["Первичка"], rows_by_scope["primary"], start, end)
        write_full_or_repairs(wb["Ремонты"], rows_by_scope["repairs"], start, end)

    prefix = "statv2_export_materials_" if include_materials else "statv2_export_"
    tmp = tempfile.NamedTemporaryFile(prefix=prefix, suffix=".xlsm", delete=False)
    tmp_path = Path(tmp.name)
    tmp.close()
    wb.save(tmp_path)
    return tmp_path


@APP.get("/api/export_stats_excel")
def export_stats_excel():
    if not (is_role("admin") or basic_authorized()):
        return error("Нет доступа", 401)

    start = (request.args.get("start") or "").strip()
    end = (request.args.get("end") or "").strip()
    if not start or not end:
        return error("Нужны параметры start и end")
    try:
        parse_iso_date(start)
        parse_iso_date(end)
    except Exception:
        return error("Дата должна быть в формате YYYY-MM-DD")

    mode = (request.args.get("mode") or "normal").strip().lower()
    include_materials = mode == "materials"
    material_range_config = None
    if include_materials:
        raw_ranges = (request.args.get("ranges") or "").strip()
        if raw_ranges:
            try:
                material_range_config = json.loads(raw_ranges)
            except Exception:
                return error("Некорректные настройки диапазонов материалов")

    try:
        output_path = build_export_workbook(
            start,
            end,
            str(session.get("org_filter") or ""),
            include_materials=include_materials,
            material_range_config=material_range_config,
        )
    except ValueError as exc:
        return error(str(exc), 400)
    except Exception as exc:
        return error(str(exc), 500)

    export_stamp = datetime.now().strftime("%d.%m.%Y %H.%M.%S")
    name_suffix = "_materials" if include_materials else ""
    filename = f"statv2_stats{name_suffix}_{export_stamp}.xlsm"

    @after_this_request
    def cleanup(response):
        try:
            output_path.unlink(missing_ok=True)
        except Exception:
            pass
        return response

    return send_file(
        output_path,
        as_attachment=True,
        download_name=filename,
        mimetype="application/vnd.ms-excel.sheet.macroEnabled.12",
        max_age=0,
    )



@APP.get("/api/welder_access")
@APP.get("/api/welder_access")
def api_welder_access():
    # Доступы сварщика отдаём только авторизованному админу.
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    welder_id = str(request.args.get("welder_id") or "").strip()
    if not welder_id:
        return error("Не указан welder_id", 400)

    try:
        w = None

        try:
            w = _find_auth_welder_by_id(welder_id)
        except Exception:
            w = None

        if not w:
            auth_path = globals().get("PRIVATE_AUTH_PATH", None)
            if not auth_path:
                auth_path = Path("/opt/statv2-auth/auth.json.gz")

            auth_db = read_json_gz(auth_path) if "read_json_gz" in globals() else _read_json_gz(auth_path)

            for item in auth_db.get("welders", []):
                if str(item.get("id") or "") == welder_id:
                    w = item
                    break

        if not w:
            return error("Сварщик не найден", 404)

        org_filter = str(session.get("org_filter") or "").casefold().replace("ё", "е").strip()
        if org_filter:
            org_value = str(w.get("organization") or "").casefold().replace("ё", "е")
            if org_filter not in org_value:
                return error("Нет доступа к этому сварщику", 403)

        return jsonify({
            "ok": True,
            "welder_id": w.get("id", ""),
            "name": w.get("name", ""),
            "login": w.get("login", ""),
            "password_plain": w.get("password_plain", ""),
        })

    except Exception as exc:
        return error(str(exc), 500)



# STATV2_AUDIT_AFTER_REQUEST_V1
@APP.after_request
def statv2_audit_after_request(response):
    try:
        path = request.path or ""

        # Пишем любую попытку входа независимо от того, какая ветка api_login сработала.
        if path == "/api/login" and request.method == "POST":
            data = request.get_json(silent=True) or request.form or {}
            login = str(data.get("login") or "")

            role = str(session.get("role") or "")
            ok = 200 <= int(response.status_code) < 400

            event = "login_success" if ok else "login_failed"

            extra = {}
            if session.get("welder_id"):
                extra["welder_id"] = session.get("welder_id", "")
            if session.get("org_filter"):
                extra["org_filter"] = session.get("org_filter", "")
                extra["org_title"] = session.get("org_title", "")

            # Не пишем пароль. Никогда. Даже под дулом Excel.
            audit_event(event, login=login, role=role, ok=ok, extra=extra)

        # Пишем восстановление сессии при открытии сайта.
        elif path == "/api/session" and request.method == "GET":
            role = str(session.get("role") or "")
            if role:
                extra = {}
                if session.get("welder_id"):
                    extra["welder_id"] = session.get("welder_id", "")
                if session.get("org_filter"):
                    extra["org_filter"] = session.get("org_filter", "")
                    extra["org_title"] = session.get("org_title", "")

                audit_event(
                    "session_restore",
                    login=str(session.get("login") or ""),
                    role=role,
                    ok=True,
                    extra=extra,
                )

    except Exception:
        pass

    return response



# ---------------- Stat admin cabinet ----------------

def statv2_int_nonnegative(value):
    try:
        return max(0, int(float(value or 0)))
    except Exception:
        return 0


def statv2_normalize_spk_backlog_record(record):
    record = record if isinstance(record, dict) else {}
    repair_s = statv2_int_nonnegative(record.get("repair_backlog_S"))
    lnk_s = statv2_int_nonnegative(record.get("lnk_backlog_S"))
    repair_nos = statv2_int_nonnegative(record.get("repair_backlog_NoS"))
    lnk_nos = statv2_int_nonnegative(record.get("lnk_backlog_NoS"))
    repair_has_split = "repair_backlog_S" in record or "repair_backlog_NoS" in record
    lnk_has_split = "lnk_backlog_S" in record or "lnk_backlog_NoS" in record
    return {
        "repair_backlog_S": repair_s,
        "lnk_backlog_S": lnk_s,
        "repair_backlog_NoS": repair_nos,
        "lnk_backlog_NoS": lnk_nos,
        "repair_backlog": repair_s + repair_nos if repair_has_split else statv2_int_nonnegative(record.get("repair_backlog")),
        "lnk_backlog": lnk_s + lnk_nos if lnk_has_split else statv2_int_nonnegative(record.get("lnk_backlog")),
    }


def statv2_read_spk_backlog_history():
    try:
        if SPK_BACKLOG_HISTORY_PATH.exists():
            data = json.loads(SPK_BACKLOG_HISTORY_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {
                    str(day)[:10]: statv2_normalize_spk_backlog_record(record)
                    for day, record in data.items()
                    if isinstance(record, dict)
                }
    except Exception:
        pass
    return {}


def statv2_write_spk_backlog_history(history):
    SPK_BACKLOG_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    normalized = {
        str(day)[:10]: statv2_normalize_spk_backlog_record(record)
        for day, record in sorted((history or {}).items())
        if isinstance(record, dict)
    }
    temp_path = SPK_BACKLOG_HISTORY_PATH.with_suffix(".tmp")
    temp_path.write_text(
        json.dumps(normalized, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temp_path.replace(SPK_BACKLOG_HISTORY_PATH)
    try:
        SPK_BACKLOG_HISTORY_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_merge_spk_backlog_snapshot(snapshot):
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    snapshot_date = str(snapshot.get("date") or "")[:10]
    try:
        datetime.strptime(snapshot_date, "%Y-%m-%d")
    except Exception as exc:
        raise ValueError("В снимке СПК указана некорректная дата") from exc

    history = statv2_read_spk_backlog_history()
    history[snapshot_date] = statv2_normalize_spk_backlog_record(snapshot)
    statv2_write_spk_backlog_history(history)
    return snapshot_date


def statv2_read_dynamic_org_accounts():
    try:
        if DYNAMIC_ORG_ACCOUNTS_PATH.exists():
            return json.loads(DYNAMIC_ORG_ACCOUNTS_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def statv2_write_dynamic_org_accounts(data):
    DYNAMIC_ORG_ACCOUNTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    DYNAMIC_ORG_ACCOUNTS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        DYNAMIC_ORG_ACCOUNTS_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_read_spk_contractors():
    try:
        if SPK_CONTRACTORS_PATH.exists():
            data = json.loads(SPK_CONTRACTORS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                data = data.get("contractors", [])
            if isinstance(data, list):
                return [item for item in data if isinstance(item, dict)]
    except Exception:
        pass
    return []


def statv2_write_spk_contractors(items):
    SPK_CONTRACTORS_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 1, "contractors": items}
    temp_path = SPK_CONTRACTORS_PATH.with_suffix(".tmp")
    temp_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temp_path.replace(SPK_CONTRACTORS_PATH)
    try:
        SPK_CONTRACTORS_PATH.chmod(0o600)
    except Exception:
        pass


def statv2_find_spk_contractor_by_account(login):
    login_key = str(login or "").strip().upper()
    if not login_key:
        return None
    for item in statv2_read_spk_contractors():
        if str(item.get("account_login") or "").strip().upper() == login_key:
            return item
    return None


def statv2_public_spk_contractor(item):
    return {
        "id": str(item.get("id") or ""),
        "object_name": str(item.get("object_name") or ""),
        "subcontractor": str(item.get("subcontractor") or ""),
        "allowed_reject_rate": item.get("allowed_reject_rate", 0),
        "brigadier_filter": str(item.get("brigadier_filter") or ""),
        "account_login": str(item.get("account_login") or ""),
    }


def statv2_all_org_accounts():
    result = {}

    try:
        for login, cfg in ORG_ADMIN_ACCOUNTS.items():
            result[str(login).strip().upper()] = {
                "password": cfg.get("password", ""),
                "filter_type": "organization",
                "filter_value": cfg.get("org_filter", ""),
                "title": cfg.get("title") or cfg.get("org_filter", ""),
                "builtin": True,
            }
    except Exception:
        pass

    for login, cfg in statv2_read_dynamic_org_accounts().items():
        result[str(login).strip().upper()] = {
            "password": cfg.get("password", ""),
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title") or cfg.get("filter_value", ""),
            "builtin": False,
        }

    return result


@APP.before_request
def statv2_stat_admin_login_hook():
    if request.path != "/api/login" or request.method != "POST":
        return None

    data = request.get_json(silent=True) or request.form or {}
    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "")

    if not login or not password:
        return None

    if hmac.compare_digest(login.encode("utf-8"), STAT_ADMIN_LOGIN.encode("utf-8")) and hmac.compare_digest(password.encode("utf-8"), STAT_ADMIN_PASS.encode("utf-8")):
        session.clear()
        session["role"] = "stat_admin"
        session["login"] = STAT_ADMIN_LOGIN
        return jsonify({
            "ok": True,
            "role": "stat_admin",
            "meta": safe_public_meta() if "safe_public_meta" in globals() else {},
        })

    cfg = statv2_all_org_accounts().get(login.strip().upper())
    if cfg and hmac.compare_digest(password, str(cfg.get("password") or "")):
        session.clear()
        session["role"] = "admin"
        session["login"] = login.strip()
        session["account_filter_type"] = cfg.get("filter_type", "organization")
        session["account_filter_value"] = cfg.get("filter_value", "")
        session["account_filter_title"] = cfg.get("title", cfg.get("filter_value", ""))

        contractor = statv2_find_spk_contractor_by_account(login)
        if contractor:
            session["spk_contractor_id"] = str(contractor.get("id") or "")

        # Совместимость со старой логикой НГТС/НОВА/ГАЛА/ССПИ.
        if cfg.get("filter_type", "organization") == "organization":
            session["org_filter"] = cfg.get("filter_value", "")
            session["org_title"] = cfg.get("title", cfg.get("filter_value", ""))

        return jsonify({
            "ok": True,
            "role": "admin",
            "account_filter_type": session.get("account_filter_type", ""),
            "account_filter_value": session.get("account_filter_value", ""),
            "account_filter_title": session.get("account_filter_title", ""),
            "org_filter": session.get("org_filter", ""),
            "org_title": session.get("org_title", ""),
            "spk_contractor_id": session.get("spk_contractor_id", ""),
            "meta": safe_public_meta() if "safe_public_meta" in globals() else {},
        })

    return None


@APP.after_request
def statv2_add_filter_fields_to_session_response(response):
    try:
        if request.path == "/api/session" and response.is_json:
            data = response.get_json(silent=True)
            if isinstance(data, dict) and data.get("authenticated"):
                if session.get("account_filter_type"):
                    data["account_filter_type"] = session.get("account_filter_type", "")
                    data["account_filter_value"] = session.get("account_filter_value", "")
                    data["account_filter_title"] = session.get("account_filter_title", "")
                if session.get("org_filter"):
                    data["org_filter"] = session.get("org_filter", "")
                    data["org_title"] = session.get("org_title", "")

                contractor = statv2_find_spk_contractor_by_account(
                    session.get("login", "")
                )
                if contractor:
                    contractor_id = str(contractor.get("id") or "")
                    session["spk_contractor_id"] = contractor_id
                    data["spk_contractor_id"] = contractor_id
                else:
                    session.pop("spk_contractor_id", None)
                    data["spk_contractor_id"] = ""

                response.set_data(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
                response.headers["Content-Type"] = "application/json; charset=utf-8"
    except Exception:
        pass
    return response


def statv2_require_stat_admin():
    return str(session.get("role") or "") == "stat_admin"


def statv2_audit_status_ru(event, ok):
    if event == "login_success" and ok:
        return "Вход на сайт"
    if event == "org_admin_login_success" and ok:
        return "Вход ограниченной админки"
    if event == "session_restore" and ok:
        return "Восстановление сессии"
    if event == "login_failed":
        return "Неудачный вход"
    if event == "logout":
        return "Выход"
    if event == "export_excel":
        return "Выгрузка Excel"
    if event == "upload_db":
        return "Обновление базы"
    return str(event or "")


def statv2_device_from_ua(ua):
    ua = str(ua or "")
    low = ua.lower()
    if "iphone" in low:
        return "iPhone"
    if "android" in low:
        return "Android"
    if "windows" in low:
        return "Windows"
    if "mac os" in low or "macintosh" in low:
        return "Mac"
    if "linux" in low:
        return "Linux"
    return ua[:80]


def statv2_format_ts(ts):
    raw = str(ts or "")
    try:
        d = datetime.fromisoformat(raw)
        return d.strftime("%d.%m.%Y %H.%M.%S")
    except Exception:
        return raw.replace("T", " ")

@APP.route('/api/stat_admin/audit_stats', methods=['GET'])
def statv2_audit_stats():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)
    from datetime import datetime, timezone, timedelta
    try:
        filter_hours = int(request.args.get("hours") or 0)
    except Exception:
        filter_hours = 0
    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))
    all_records = []
    cutoff_str = ""
    if filter_hours:
        from datetime import datetime, timezone, timedelta
        cutoff_str = (datetime.now(timezone.utc) - timedelta(hours=filter_hours)).strftime("%Y-%m-%dT%H:%M:%S")
    if log_path.exists():
        lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for line in lines:
            try:
                r = json.loads(line)
                if r.get("ok") and r.get("login"):
                    if cutoff_str and r.get("ts","") < cutoff_str:
                        continue
                    all_records.append(r)
            except Exception:
                continue

    now = datetime.now(timezone.utc)

    def count_since(hours):
        cutoff = now - timedelta(hours=hours)
        count = 0
        for r in all_records:
            try:
                ts = r.get("ts","")
                if ts:
                    dt = datetime.fromisoformat(ts.replace('Z','+00:00'))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt >= cutoff:
                        count += 1
            except Exception:
                pass
        return count

    # Топ логинов — от отфильтрованных записей
    from collections import Counter
    login_counts = Counter(r.get("login","") for r in all_records if r.get("login"))
    top_logins = [{"login": l, "count": c} for l, c in login_counts.most_common(10)]

    # Периоды — всегда от ВСЕХ записей
    all_records_full = []
    if log_path.exists():
        lines2 = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()
        for line in lines2:
            try:
                r = json.loads(line)
                if r.get("ok") and r.get("login"):
                    all_records_full.append(r)
            except Exception:
                continue
    def count_since_full(hours):
        cutoff = now - timedelta(hours=hours)
        count = 0
        for r in all_records_full:
            try:
                ts = r.get("ts","")
                if ts:
                    dt = datetime.fromisoformat(ts.replace("Z","+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt >= cutoff:
                        count += 1
            except Exception:
                pass
        return count

    # Периоды
    periods = [
        {"label": "3 часа", "hours": 3, "count": count_since_full(3)},
        {"label": "6 часов", "hours": 6, "count": count_since_full(6)},
        {"label": "12 часов", "hours": 12, "count": count_since_full(12)},
        {"label": "24 часа", "hours": 24, "count": count_since_full(24)},
        {"label": "48 часов", "hours": 48, "count": count_since_full(48)},
        {"label": "Неделя", "hours": 168, "count": count_since_full(168)},
        {"label": "Месяц", "hours": 720, "count": count_since_full(720)},
        {"label": "Всё время", "hours": 0, "count": len(all_records_full)},
    ]

    return jsonify({
        "ok": True,
        "total": len(all_records),
        "top_logins": top_logins,
        "periods": periods,
    })

@APP.route("/api/stat_admin/audit", methods=["GET"])
def statv2_stat_admin_audit():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    try:
        limit = int(request.args.get("limit") or 50)
    except Exception:
        limit = 50

    try:
        page = int(request.args.get("page") or 1)
    except Exception:
        page = 1

    limit = max(1, min(limit, 200))
    since_str = request.args.get("since", "")
    page = max(1, page)

    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))

    all_records = []

    if log_path.exists():
        lines = log_path.read_text(encoding="utf-8", errors="ignore").splitlines()

        # Новые записи сверху.
        for line in reversed(lines):
            try:
                r = json.loads(line)
            except Exception:
                continue

            ts_val = r.get('ts','')
            if since_str and ts_val and ts_val < since_str:
                continue
            all_records.append({
                "ts": ts_val,
                "date": statv2_format_ts(r.get("ts", "")),
                "ip": r.get("ip", ""),
                "event": r.get("event", ""),
                "status": statv2_audit_status_ru(r.get("event", ""), bool(r.get("ok"))),
                "ok": bool(r.get("ok")),
                "role": r.get("role", ""),
                "login": r.get("login", ""),
                "name": r.get("name", ""),
                "org_filter": r.get("org_filter", ""),
                "device": statv2_device_from_ua(r.get("user_agent", "")),
            })

    total = len(all_records)
    pages = max(1, (total + limit - 1) // limit)
    page = min(page, pages)

    start = (page - 1) * limit
    end = start + limit
    records = all_records[start:end]

    return jsonify({
        "ok": True,
        "records": records,
        "page": page,
        "pages": pages,
        "limit": limit,
        "total": total,
    })

@APP.post("/api/stat_admin/audit/clear")
def statv2_stat_admin_audit_clear():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    log_path = Path(os.environ.get("STATV2_AUDIT_LOG", "/var/log/statv2-audit.log"))
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("", encoding="utf-8")

    return jsonify({"ok": True, "message": "Лог очищен"})


@APP.get("/api/stat_admin/accounts")
def statv2_stat_admin_accounts():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    rows = []
    for login, cfg in sorted(statv2_all_org_accounts().items()):
        rows.append({
            "login": login,
            "password": cfg.get("password", ""),
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title", ""),
            "builtin": bool(cfg.get("builtin")),
        })

    return jsonify({"ok": True, "accounts": rows})

@APP.post("/api/stat_admin/accounts")
def statv2_stat_admin_create_account():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}

    login = str(data.get("login") or "").strip()
    password = str(data.get("password") or "").strip()
    filter_type = str(data.get("filter_type") or "organization").strip()
    filter_value = str(data.get("filter_value") or "").strip()
    title = str(data.get("title") or filter_value).strip()

    allowed_filters = {
        "organization",
        "responsible",
        "shift",
        "position",
        "status",
    }

    if not login:
        return error("Введите логин", 400)
    if not password:
        return error("Введите пароль", 400)
    if filter_type not in allowed_filters:
        return error("Неизвестный фильтр", 400)
    if not filter_value:
        return error("Введите значение фильтра", 400)

    key = login.upper()

    builtin = statv2_all_org_accounts().get(key, {}).get("builtin")
    if builtin:
        return error("Такой логин занят встроенной учёткой", 400)

    data_all = statv2_read_dynamic_org_accounts()
    data_all[key] = {
        "password": password,
        "filter_type": filter_type,
        "filter_value": filter_value,
        "title": title or filter_value,
    }
    statv2_write_dynamic_org_accounts(data_all)

    return jsonify({
        "ok": True,
        "message": "Учётка создана",
        "account": {
            "login": key,
            "password": password,
            "filter_type": filter_type,
            "filter_value": filter_value,
            "title": title or filter_value,
        }
    })


@APP.post("/api/stat_admin/accounts/delete")
def statv2_stat_admin_delete_account():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    login = str(data.get("login") or "").strip().upper()

    if not login:
        return error("Не указан логин", 400)

    account = statv2_all_org_accounts().get(login)
    if account and account.get("builtin"):
        return error("Встроенную учётку удалить нельзя", 400)

    linked_contractor = statv2_find_spk_contractor_by_account(login)
    if linked_contractor:
        return error(
            "Учётка привязана к подрядчику. Сначала отвяжите её в разделе Подрядчики",
            400,
        )

    data_all = statv2_read_dynamic_org_accounts()

    if login not in data_all:
        return error("Учётка не найдена", 404)

    data_all.pop(login, None)
    statv2_write_dynamic_org_accounts(data_all)

    return jsonify({"ok": True, "message": "Учётка удалена"})


@APP.get("/api/stat_admin/contractors")
def statv2_stat_admin_contractors():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    contractors = [
        statv2_public_spk_contractor(item)
        for item in statv2_read_spk_contractors()
    ]

    accounts = []
    for login, cfg in sorted(statv2_all_org_accounts().items()):
        accounts.append({
            "login": login,
            "filter_type": cfg.get("filter_type", "organization"),
            "filter_value": cfg.get("filter_value", ""),
            "title": cfg.get("title", ""),
            "builtin": bool(cfg.get("builtin")),
        })

    return jsonify({
        "ok": True,
        "contractors": contractors,
        "accounts": accounts,
    })


@APP.post("/api/stat_admin/contractors")
def statv2_stat_admin_save_contractor():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    contractor_id = str(data.get("id") or "").strip()
    object_name = str(data.get("object_name") or "").strip()
    subcontractor = str(data.get("subcontractor") or "").strip()
    brigadier_filter = str(data.get("brigadier_filter") or "").strip()
    account_login = str(data.get("account_login") or "").strip().upper()

    allowed_raw = str(data.get("allowed_reject_rate") or "").strip()
    if not allowed_raw:
        return error("Введите допустимый уровень брака", 400)
    try:
        allowed_reject_rate = float(allowed_raw.replace(",", "."))
    except Exception:
        return error("Допустимый уровень брака должен быть числом", 400)

    if not object_name:
        return error("Введите объект строительства", 400)
    if not subcontractor:
        return error("Введите имя субподрядчика", 400)
    if not brigadier_filter:
        return error("Введите значение фильтра по полю Бригадир", 400)
    if not (0 <= allowed_reject_rate <= 100):
        return error("Допустимый уровень брака должен быть от 0 до 100%", 400)

    accounts = statv2_all_org_accounts()
    if account_login and account_login not in accounts:
        return error("Выбранная ограниченная учётка не найдена", 400)

    items = statv2_read_spk_contractors()

    for item in items:
        item_id = str(item.get("id") or "")
        linked_login = str(item.get("account_login") or "").strip().upper()
        if account_login and linked_login == account_login and item_id != contractor_id:
            return error("Эта учётка уже привязана к другому подрядчику", 400)

    now = datetime.now().isoformat(timespec="seconds")
    saved = None

    if contractor_id:
        for item in items:
            if str(item.get("id") or "") == contractor_id:
                item.update({
                    "object_name": object_name,
                    "subcontractor": subcontractor,
                    "allowed_reject_rate": allowed_reject_rate,
                    "brigadier_filter": brigadier_filter,
                    "account_login": account_login,
                    "updated_at": now,
                })
                saved = item
                break
        if saved is None:
            return error("Подрядчик не найден", 404)
    else:
        saved = {
            "id": secrets.token_hex(8),
            "object_name": object_name,
            "subcontractor": subcontractor,
            "allowed_reject_rate": allowed_reject_rate,
            "brigadier_filter": brigadier_filter,
            "account_login": account_login,
            "created_at": now,
            "updated_at": now,
        }
        items.append(saved)

    statv2_write_spk_contractors(items)

    return jsonify({
        "ok": True,
        "message": "Подрядчик сохранён",
        "contractor": statv2_public_spk_contractor(saved),
    })


@APP.post("/api/stat_admin/contractors/delete")
def statv2_stat_admin_delete_contractor():
    if not statv2_require_stat_admin():
        return error("Нет доступа", 401)

    data = request.get_json(silent=True) or request.form or {}
    contractor_id = str(data.get("id") or "").strip()
    if not contractor_id:
        return error("Не указан подрядчик", 400)

    items = statv2_read_spk_contractors()
    filtered = [
        item for item in items
        if str(item.get("id") or "") != contractor_id
    ]

    if len(filtered) == len(items):
        return error("Подрядчик не найден", 404)

    statv2_write_spk_contractors(filtered)
    return jsonify({"ok": True, "message": "Подрядчик удалён"})


@APP.get("/api/spk/backlog_history")
def statv2_spk_backlog_history():
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    account_filter_value = str(session.get("account_filter_value") or "").strip()
    org_filter = str(session.get("org_filter") or "").strip()
    if account_filter_value or org_filter:
        return error("История общей ежедневной СПК доступна только полной админской учётке", 403)

    return jsonify({
        "ok": True,
        "history": statv2_read_spk_backlog_history(),
    })


@APP.get("/api/spk/contractors")
def statv2_spk_contractors():
    if str(session.get("role") or "") != "admin":
        return error("Нет доступа", 401)

    items = statv2_read_spk_contractors()
    account_filter_value = str(session.get("account_filter_value") or "").strip()
    org_filter = str(session.get("org_filter") or "").strip()
    full_admin = not account_filter_value and not org_filter

    if full_admin:
        visible = items
        mode = "full"
        contractor_id = ""
    else:
        linked = statv2_find_spk_contractor_by_account(session.get("login", ""))
        visible = [linked] if linked else []
        mode = "linked"
        contractor_id = str(linked.get("id") or "") if linked else ""

    return jsonify({
        "ok": True,
        "mode": mode,
        "contractor_id": contractor_id,
        "contractors": [
            statv2_public_spk_contractor(item)
            for item in visible
            if item
        ],
    })


import json as _json_mod
import os as _os_mod
from datetime import datetime as _dt

SUGG_FILE = '/var/www/statv2/db/suggestions.json'

@APP.route('/api/suggestion', methods=['POST'])
def api_add_suggestion():
    from flask import session, request, jsonify
    if not session.get('role'):
        return jsonify({'error': 'unauthorized'}), 401
    data = request.get_json(force=True)
    name = (data.get('name') or '').strip()
    text = (data.get('text') or '').strip()
    role = (data.get('role') or '').strip()
    if not text:
        return jsonify({'error': 'empty'}), 400
    suggestions = []
    if _os_mod.path.exists(SUGG_FILE):
        try:
            with open(SUGG_FILE, 'r') as f:
                suggestions = _json_mod.load(f)
        except Exception:
            suggestions = []
    suggestions.insert(0, {
        'name': name,
        'text': text,
        'role': role,
        'ts': _dt.now().strftime('%d.%m.%Y %H:%M')
    })
    with open(SUGG_FILE, 'w') as f:
        _json_mod.dump(suggestions, f, ensure_ascii=False, indent=2)
    return jsonify({'ok': True})


@APP.route('/api/suggestion/<int:idx>', methods=['DELETE'])
def api_delete_suggestion(idx):
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    if not _os_mod.path.exists(SUGG_FILE):
        return jsonify({'ok': True})
    try:
        with open(SUGG_FILE, 'r') as f:
            suggestions = _json_mod.load(f)
        if 0 <= idx < len(suggestions):
            suggestions.pop(idx)
        with open(SUGG_FILE, 'w') as f:
            _json_mod.dump(suggestions, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    return jsonify({'ok': True})

@APP.route('/api/suggestions', methods=['GET'])
def api_get_suggestions():
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    if not _os_mod.path.exists(SUGG_FILE):
        return jsonify([])
    try:
        with open(SUGG_FILE, 'r') as f:
            return jsonify(_json_mod.load(f))
    except Exception:
        return jsonify([])


OVERRIDES_FILE = '/var/www/statv2/db/overrides.json'

def load_overrides():
    if not _os_mod.path.exists(OVERRIDES_FILE):
        return []
    try:
        with open(OVERRIDES_FILE, 'r') as f:
            return _json_mod.load(f)
    except Exception:
        return []

def save_overrides(overrides):
    with open(OVERRIDES_FILE, 'w') as f:
        _json_mod.dump(overrides, f, ensure_ascii=False, indent=2)


def update_manifest_timestamp():
    import hashlib as _hashlib, datetime as _datetime
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    manifest_path = site_root / "db" / "manifest.json"
    shards_dir = site_root / "db" / "welders"
    try:
        with open(manifest_path, 'r') as f:
            m = _json_mod.load(f)
        # Обновляем хэши shard файлов
        shard_paths = m.get('shards', [])
        total_size = 0
        combined = b""
        for rel_path in shard_paths:
            fpath = site_root / "db" / rel_path
            if fpath.exists():
                data = fpath.read_bytes()
                total_size += len(data)
                combined += data
        if combined:
            m['files']['shards']['sha256'] = _hashlib.sha256(combined).hexdigest()
            m['files']['shards']['size_bytes'] = total_size
        m['generated_at'] = _datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        m['overrides_ts'] = m['generated_at']
        with open(manifest_path, 'w') as f:
            _json_mod.dump(m, f, ensure_ascii=False)
    except Exception as e:
        pass

def _recalc_welder_stats(welders, joints):
    """Пересчитывает статистику сварщиков на основе стыков"""
    from collections import defaultdict
    # Строим индекс сварщиков по id
    welder_map = {w.get('id',''): w for w in welders}
    # Сбрасываем статистику
    for w in welders:
        for scope in ['primary_all','repairs_all']:
            if scope in w.get('stats',{}):
                s = w['stats'][scope]
                for k in ['total_welded','submitted_control','accepted','rejected','wait','not_required']:
                    s[k] = 0
                s['production'] = 0.0
                s['reject_rate'] = 0.0
    # Пересчитываем
    for joint in joints:
        for action in joint.get('actions', []):
            stage_type = action.get('stage_type','primary')
            scope = 'repairs_all' if stage_type == 'repair' else 'primary_all'
            result = action.get('result','')
            weld_date = action.get('weld_date','')
            inch = joint.get('inch', 0) or 0
            for wid in action.get('welder_ids', []):
                w = welder_map.get(wid)
                if not w:
                    continue
                s = w.setdefault('stats', {}).setdefault(scope, {
                    'total_welded':0,'production':0.0,'submitted_control':0,
                    'accepted':0,'rejected':0,'wait':0,'not_required':0,'reject_rate':0.0
                })
                if weld_date:
                    s['total_welded'] = s.get('total_welded',0) + 1
                    s['production'] = s.get('production',0.0) + float(inch)
                if 'Годен' in result:
                    s['accepted'] = s.get('accepted',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'Не годен' in result:
                    s['rejected'] = s.get('rejected',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'Ожидание' in result:
                    s['wait'] = s.get('wait',0) + 1
                    s['submitted_control'] = s.get('submitted_control',0) + 1
                elif 'не требуется' in result.lower():
                    s['not_required'] = s.get('not_required',0) + 1
                sc = s.get('submitted_control',0)
                rj = s.get('rejected',0)
                s['reject_rate'] = rj/sc if sc else 0.0

def apply_overrides_to_shards():
    """Применяет оверрайды ко всем shard файлам после загрузки базы"""
    overrides = load_overrides()
    if not overrides:
        return 0
    import gzip as _gzip
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    shards_dir = site_root / "db" / "welders"
    applied = 0
    for shard_path in sorted(shards_dir.glob("shard_*.json.gz")):
        try:
            with _gzip.open(shard_path, 'rt', encoding='utf-8') as f:
                shard = _json_mod.load(f)
            joints = shard.get('joints', [])
            welders = shard.get('welders', [])
            changed = False
            for joint in joints:
                vik = joint.get('vik_request', '')
                for ov in overrides:
                    if ov.get('vik_request') != vik:
                        continue
                    actions = joint.get('actions', [])
                    stage_index = ov.get('stage_index', 0)
                    for action in actions:
                        if action.get('stage_index') == stage_index:
                            new_name = ov.get('welder_name', '')
                            action['welders_raw'] = new_name
                            action['welder_names'] = [new_name] if new_name else []
                            action['welder_ids'] = []
                            action['unknown_welder_names'] = [new_name] if new_name else []
                            action['unknown_welder_ids'] = []
                            changed = True
                            applied += 1
            if changed:
                _recalc_welder_stats(welders, joints)
                with _gzip.open(shard_path, 'wt', encoding='utf-8') as f:
                    _json_mod.dump(shard, f, ensure_ascii=False)
        except Exception as e:
            continue
    return applied

@APP.route('/api/stat_admin/overrides', methods=['GET'])
def api_get_overrides():
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    return jsonify({'ok': True, 'overrides': load_overrides()})

@APP.route('/api/stat_admin/overrides', methods=['POST'])
def api_add_override():
    from flask import session, request, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    data = request.get_json(force=True)
    vik = (data.get('vik_request') or '').strip()
    welder_name = (data.get('welder_name') or '').strip()
    stage_index = int(data.get('stage_index', 0))
    stage_label = (data.get('stage_label') or '').strip()
    joint_no = (data.get('joint_no') or '').strip()
    iso = (data.get('iso') or '').strip()
    if not vik:
        return jsonify({'error': 'Укажите номер заявки'}), 400
    overrides = load_overrides()
    # Проверим дубль
    for ov in overrides:
        if ov.get('vik_request') == vik and ov.get('stage_index') == stage_index:
            ov['welder_name'] = welder_name
            ov['stage_label'] = stage_label
            ov['joint_no'] = joint_no
            ov['iso'] = iso
            save_overrides(overrides)
            apply_overrides_to_shards()
            update_manifest_timestamp()
            return jsonify({'ok': True, 'updated': True})
    overrides.insert(0, {
        'vik_request': vik,
        'welder_name': welder_name,
        'stage_index': stage_index,
        'stage_label': stage_label,
        'joint_no': joint_no,
        'iso': iso,
        'ts': __import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M')
    })
    save_overrides(overrides)
    apply_overrides_to_shards()
    update_manifest_timestamp()
    return jsonify({'ok': True, 'updated': False})

@APP.route('/api/stat_admin/overrides/<int:idx>', methods=['DELETE'])
def api_delete_override(idx):
    from flask import session, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    overrides = load_overrides()
    if 0 <= idx < len(overrides):
        overrides.pop(idx)
        save_overrides(overrides)
    return jsonify({'ok': True})

@APP.route('/api/stat_admin/joint_search', methods=['GET'])
def api_joint_search():
    from flask import session, request, jsonify
    if session.get('role') != 'stat_admin':
        return jsonify({'error': 'forbidden'}), 403
    vik = (request.args.get('vik_request') or '').strip()
    if not vik:
        return jsonify({'error': 'Укажите номер заявки'}), 400
    import gzip as _gzip
    site_root = Path(os.environ.get("STATV2_SITE_ROOT", "/var/www/statv2"))
    shards_dir = site_root / "db" / "welders"
    results = []
    seen_ids = set()
    for shard_path in sorted(shards_dir.glob("shard_*.json.gz")):
        try:
            with _gzip.open(shard_path, 'rt', encoding='utf-8') as f:
                shard = _json_mod.load(f)
            for joint in shard.get('joints', []):
                jid = joint.get('id','')
                if jid in seen_ids:
                    continue
                seen_ids.add(jid)
                if joint.get('vik_request', '') == vik:
                    results.append({
                        'id': joint.get('id',''),
                        'iso': joint.get('iso',''),
                        'joint_no': joint.get('joint_no',''),
                        'vik_request': joint.get('vik_request',''),
                        'actions': [{'stage_index': a.get('stage_index',0), 'stage_label': a.get('stage_label',''), 'repair_no': a.get('repair_no',0), 'welder_names': a.get('welder_names',[]), 'welders_raw': a.get('welders_raw','')} for a in joint.get('actions',[])]
                    })
        except Exception:
            continue
    return jsonify({'ok': True, 'joints': results})

if __name__ == "__main__":
    APP.run(host="127.0.0.1", port=int(os.environ.get("STATV2_UPLOAD_PORT", "5088")))


# ── ID-карты: загрузка ZIP ────────────────────────────────────────────────────

@APP.post("/api/upload_idcards")
def upload_idcards():
    if not authorized():
        return error("Нет доступа", 401)
    file = request.files.get("file")
    if not file or not file.filename:
        return error("Файл не выбран")
    if not file.filename.lower().endswith(".zip"):
        return error("Нужен zip-архив")
    IDCARDS_ROOT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="statv2_idcards_") as tmp_name:
        tmp = Path(tmp_name)
        zip_path = tmp / "upload.zip"
        file.save(zip_path)
        try:
            with zipfile.ZipFile(zip_path) as z:
                names = z.namelist()
                if "manifest.json" not in names:
                    return error("В архиве нет manifest.json")
                manifest_bytes = z.read("manifest.json")
                try:
                    new_manifest = json.loads(manifest_bytes.decode("utf-8"))
                except Exception:
                    return error("manifest.json повреждён")
                pdf_count = 0
                for member in z.infolist():
                    name = member.filename.replace("\\", "/")
                    if not name.lower().endswith(".pdf"):
                        continue
                    parts = Path(name).parts
                    if any(p in ("..", "") for p in parts):
                        continue
                    target = IDCARDS_ROOT / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(z.read(member.filename))
                    try:
                        target.chmod(0o644)
                        target.parent.chmod(0o755)
                    except Exception:
                        pass
                    pdf_count += 1
        except zipfile.BadZipFile:
            return error("Файл повреждён или не является zip-архивом")
        except Exception as exc:
            return error(f"Ошибка распаковки: {exc}", 500)
        merged_manifest = {}
        if IDCARDS_MANIFEST.exists():
            try:
                old = json.loads(IDCARDS_MANIFEST.read_text(encoding="utf-8"))
                merged_manifest.update(old)
            except Exception:
                pass
        merged_manifest.update(new_manifest)
        merged_manifest["__version__"] = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        IDCARDS_MANIFEST.write_text(
            json.dumps(merged_manifest, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        try:
            IDCARDS_MANIFEST.chmod(0o644)
        except Exception:
            pass
    return jsonify({
        "ok": True,
        "pdf_added": pdf_count,
        "welders": len([k for k in merged_manifest if not k.startswith("__")]),
        "version": merged_manifest["__version__"],
    })


# ── ID-карты: манифест ────────────────────────────────────────────────────────

@APP.get("/api/idcards_manifest")
def idcards_manifest():
    if not IDCARDS_MANIFEST.exists():
        return jsonify({"__version__": "0"})
    try:
        data = json.loads(IDCARDS_MANIFEST.read_text(encoding="utf-8"))
        return jsonify(data)
    except Exception:
        return error("Манифест повреждён", 500)


# ── ID-карты: отдача PDF ──────────────────────────────────────────────────────

@APP.get("/api/idcards/<stamp>/<path:filename>")
def idcard_file(stamp, filename):
    safe_stamp = Path(stamp).name
    target = (IDCARDS_ROOT / safe_stamp / filename).resolve()
    if not str(target).startswith(str(IDCARDS_ROOT.resolve())):
        return error("Недопустимый путь", 400)
    if not target.exists() or not target.suffix.lower() == ".pdf":
        return error("Файл не найден", 404)
    return send_file(
        target,
        mimetype="application/pdf",
        as_attachment=False,
        max_age=86400 * 30,
    )


# ── Инженеры по сварке ────────────────────────────────────────────────────────

ENGINEERS_FILE = SITE_ROOT / "engineers.json"

@APP.get("/api/engineers")
def get_engineers():
    if not ENGINEERS_FILE.exists():
        return jsonify([])
    try:
        data = json.loads(ENGINEERS_FILE.read_text(encoding="utf-8"))
        return jsonify(data)
    except Exception:
        return jsonify([])

@APP.post("/api/engineers")
def save_engineers():
    if not authorized():
        return error("Нет доступа", 401)
    try:
        data = request.get_json(force=True)
        if not isinstance(data, list):
            return error("Ожидается список")
        ENGINEERS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        ENGINEERS_FILE.chmod(0o644)
        return jsonify({"ok": True, "count": len(data)})
    except Exception as exc:
        return error(f"Ошибка: {exc}", 500)
