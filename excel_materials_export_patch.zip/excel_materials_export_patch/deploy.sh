#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"

HTML_DST="/var/www/statv2/index_v2.html"
APP_DST="/opt/statv2-uploader/server_uploader/app.py"
TEMPLATE_DST="/var/www/statv2/templates/statistika_template_material.xlsm"

for src in \
  "$BASE_DIR/index_v2.html" \
  "$BASE_DIR/app.py" \
  "$BASE_DIR/statistika_template_material.xlsm"
do
  if [[ ! -f "$src" ]]; then
    echo "ОШИБКА: не найден файл $src" >&2
    exit 1
  fi
done

mkdir -p /var/www/statv2/templates

cp "$HTML_DST" "${HTML_DST}.bak_excel_materials_${STAMP}"
cp "$APP_DST" "${APP_DST}.bak_excel_materials_${STAMP}"
if [[ -f "$TEMPLATE_DST" ]]; then
  cp "$TEMPLATE_DST" "${TEMPLATE_DST}.bak_${STAMP}"
fi

install -m 0644 "$BASE_DIR/index_v2.html" "$HTML_DST"
install -m 0644 "$BASE_DIR/app.py" "$APP_DST"
install -m 0644 "$BASE_DIR/statistika_template_material.xlsm" "$TEMPLATE_DST"

python3 -m py_compile "$APP_DST"

python3 - <<'PYEOF'
from pathlib import Path
import re

html_path = Path('/var/www/statv2/index_v2.html')
html = html_path.read_text(encoding='utf-8')

checks = {
    'Кнопка обычной выгрузки': 'id="downloadExcelBtn">Обычная</button>' in html,
    'Кнопка выгрузки с материалами': 'id="downloadExcelMaterialsBtn">С материалами</button>' in html,
    'Передача настроек диапазонов': 'JSON.stringify(materialRangeConfig)' in html,
    'Режим materials': 'mode:withMaterials?"materials":"normal"' in html,
}

for name, ok in checks.items():
    print(('OK   ' if ok else 'ERROR'), name)
    if not ok:
        raise SystemExit(1)

scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, flags=re.S | re.I)
Path('/tmp/statv2_excel_materials_check.js').write_text('\n'.join(scripts), encoding='utf-8')
PYEOF

if command -v node >/dev/null 2>&1; then
  node --check /tmp/statv2_excel_materials_check.js
else
  echo "ВНИМАНИЕ: node не найден, проверка JavaScript пропущена"
fi

python3 - <<'PYEOF'
from pathlib import Path

app = Path('/opt/statv2-uploader/server_uploader/app.py').read_text(encoding='utf-8')
checks = {
    'Путь к шаблону с материалами': 'MATERIAL_TEMPLATE_PATH' in app,
    'Расчёт LTCS / SS / LOAS': 'MATERIAL_GROUPS = ("LTCS", "SS", "LOAS")' in app,
    'Заполнение листа Материалы': 'def write_materials_sheet' in app,
    'Данные с 7-й строки': 'data_start_row = 7' in app,
    'Обработка режима materials': 'include_materials = mode == "materials"' in app,
}
for name, ok in checks.items():
    print(('OK   ' if ok else 'ERROR'), name)
    if not ok:
        raise SystemExit(1)

for required in (
    Path('/var/www/statv2/templates/statistika_template.xlsm'),
    Path('/var/www/statv2/templates/statistika_template_material.xlsm'),
):
    if not required.is_file():
        raise SystemExit(f'ОШИБКА: не найден шаблон {required}')
    print('OK   Шаблон:', required)
PYEOF

systemctl restart statv2-uploader
systemctl is-active --quiet statv2-uploader

echo
echo "ГОТОВО. Резервные копии имеют метку: $STAMP"
echo "На компьютере обновите сайт через Ctrl+F5."
